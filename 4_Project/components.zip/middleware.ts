import { NextRequest, NextResponse } from 'next/server';
import { i18n } from './src/config/i18n';
import Negotiator from 'negotiator';

// Lista de idiomas suportados
const locales = i18n.locales;

// Função para obter o idioma preferido do navegador
function getLocale(request: NextRequest) {
  // Idioma padrão se nada for encontrado
  let locale = i18n.defaultLocale;

  // Tenta obter o idioma do cookie
  const cookieLocale = request.cookies.get('NEXT_LOCALE')?.value;
  if (cookieLocale && locales.includes(cookieLocale as any)) {
    return cookieLocale;
  }

  // Tenta detectar pelo Accept-Language header
  const acceptLanguage = request.headers.get('Accept-Language') || '';
  if (acceptLanguage) {
    const headers = { 'accept-language': acceptLanguage };
    const negotiator = new Negotiator({ headers });
    const languages = negotiator.languages();
    
    // Encontra o primeiro idioma compatível
    const detectedLocale = languages.find(
      (language) => locales.some(supportedLocale => 
        language.toLowerCase().startsWith(supportedLocale.toLowerCase())
      )
    );
    
    if (detectedLocale) {
      const matchedLocale = locales.find(l => 
        detectedLocale.toLowerCase().startsWith(l.toLowerCase())
      );
      if (matchedLocale) {
        locale = matchedLocale;
      }
    }
  }

  return locale;
}

export function middleware(request: NextRequest) {
  // Verifica se o caminho já contém um locale
  const pathname = request.nextUrl.pathname;
  
  // Verifica se o recurso é público (imagens, fontes, etc.)
  if (
    [
      '/images/',
      '/fonts/',
      '/api/',
      '/favicon.ico',
      '/_next/',
      '/locales/',
    ].some(prefix => pathname.startsWith(prefix))
  ) {
    return NextResponse.next();
  }

  // Verifica se já temos um locale no caminho
  const pathnameHasLocale = locales.some(
    locale => pathname.startsWith(`/${locale}/`) || pathname === `/${locale}`
  );

  if (pathnameHasLocale) return NextResponse.next();

  // Redireciona para o locale apropriado
  const locale = getLocale(request);
  const newUrl = new URL(`/${locale}${pathname === '/' ? '' : pathname}${request.nextUrl.search}`, request.url);
  
  return NextResponse.redirect(newUrl);
}

// Configuração de qual caminho deve acionar o middleware
export const config = {
  matcher: [
    // Ignora arquivos estáticos e API routes
    '/((?!api|_next/static|_next/image|favicon.ico).*)',
  ],
};
