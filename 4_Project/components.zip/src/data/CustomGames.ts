export default function CustomGames() {
    const customFeatures = [
      {
        icon: Palette,
        title: "Design Exclusivo",
        description: "Interface personalizada com sua identidade visual",
      },
      {
        icon: Cog,
        title: "Mecânicas Únicas",
        description: "Gameplay desenvolvido especificamente para seu público",
      },
      {
        icon: Sparkles,
        title: "Narrativa Própria",
        description: "Storytelling que conecta com seus jogadores",
      },
      {
        icon: Users,
        title: "Experiência Diferenciada",
        description: "Jogos que elevam o engajamento e retenção",
      },
    ]