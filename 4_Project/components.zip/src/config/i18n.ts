export const i18n = {
  defaultLocale: "pt",
  locales: ["en", "pt"] as const,
};

export type Locale = (typeof i18n.locales)[number];

// Função de utilidade para obter o idioma atual dos parâmetros de URL
export function getLocaleFromParams(params: { locale?: string }): Locale {
  return (params?.locale as Locale) || i18n.defaultLocale;
}
