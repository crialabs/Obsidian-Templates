"use client";

import { usePathname, useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { i18n, type Locale } from "@/config/i18n";
import { useState, useTransition } from "react";
import { Check, ChevronsUpDown, Globe } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";

export function LanguageToggle({ currentLocale }: { currentLocale: Locale }) {
  const router = useRouter();
  const pathname = usePathname();
  const [isPending, startTransition] = useTransition();
  const [isOpen, setIsOpen] = useState(false);

  // Get the current path without the locale
  const pathWithoutLocale = pathname.replace(`/${currentLocale}`, "") || "/";

  // Function to change the language
  const switchLanguage = (newLocale: Locale) => {
    if (newLocale === currentLocale) return;

    startTransition(() => {
      // Navigate to the same path but with the new locale
      router.push(`/${newLocale}${pathWithoutLocale}`);
      setIsOpen(false);
    });
  };

  return (
    <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
          className="flex items-center gap-1 h-8 px-2"
        >
          <Globe className="h-4 w-4" />
          <span className="uppercase">{currentLocale}</span>
          <ChevronsUpDown className="h-3 w-3 opacity-50" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-[120px]">
        {i18n.locales.map((l) => (
          <DropdownMenuItem
            key={l}
            onClick={() => switchLanguage(l)}
            className={cn(
              "cursor-pointer",
              isPending && "opacity-50 pointer-events-none"
            )}
          >
            <span className="uppercase mr-2">{l}</span>
            {l === currentLocale && <Check className="h-4 w-4 ml-auto" />}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
