"use client";
import { TiltedScroll } from "@/components/ui/tilted-scroll";

import { useTranslation } from "react-i18next";
import { useParams } from "next/navigation";
import { Locale } from "@/config/i18n";

export function TiltedScrollDemo() {
  // Obtém o parâmetro de idioma atual da URL
  const params = useParams();
  const currentLocale = (params?.locale as Locale) || "pt";
  const { t } = useTranslation("common", { lng: currentLocale });
  
  const customItems = [
    { id: "1", text: t("animation.items.0") },
    { id: "2", text: t("animation.items.1") },
    { id: "3", text: t("animation.items.2") },
  ];

  return (
    <div id="animation" className="space-y-8 py-16 md:py-24">
      <TiltedScroll items={customItems} className="mt-8" />
    </div>
  );
}
