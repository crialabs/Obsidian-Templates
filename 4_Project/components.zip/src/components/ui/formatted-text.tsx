"use client";

import React from 'react';
import DOMPurify from 'isomorphic-dompurify';
import { cn } from '@/lib/utils';

interface FormattedTextProps {
  text: string;
  className?: string;
}

export function FormattedText({ text, className }: FormattedTextProps) {
  // Sanitiza o HTML permitindo apenas tags básicas como <b>, <i>, <em>, <strong>
  const sanitizedHtml = DOMPurify.sanitize(text, {
    ALLOWED_TAGS: ['b', 'i', 'em', 'strong'],
    ALLOWED_ATTR: []
  });

  return (
    <span 
      className={cn("inline", className)}
      dangerouslySetInnerHTML={{ __html: sanitizedHtml }}
    />
  );
}
