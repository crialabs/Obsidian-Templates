"use client";

import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import React from "react";

interface AnimatedBadgeProps {
  children: React.ReactNode;
  className?: string;
  variant?: "default" | "outline" | "gradient";
  pulseEffect?: boolean;
}

export function AnimatedBadge({
  children,
  className,
  variant = "gradient",
  pulseEffect = true,
}: AnimatedBadgeProps) {
  const getVariantClasses = () => {
    switch (variant) {
      case "gradient":
        return "bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 text-white border-0";
      case "outline":
        return "bg-background border border-primary text-primary";
      default:
        return "";
    }
  };

  return (
    <Badge
      className={cn(
        "relative overflow-hidden transition-all duration-300 hover:scale-105",
        pulseEffect && "animate-pulse-subtle",
        getVariantClasses(),
        className
      )}
    >
      {children}
    </Badge>
  );
}

// Adicionar a animação ao Tailwind (usada com animate-pulse-subtle)
if (typeof document !== "undefined") {
  const style = document.createElement("style");
  style.textContent = `
    @keyframes pulse-subtle {
      0%, 100% {
        opacity: 1;
      }
      50% {
        opacity: 0.85;
      }
    }
    .animate-pulse-subtle {
      animation: pulse-subtle 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
    }
  `;
  document.head.appendChild(style);
}
