"use client";

import React from 'react';
import { cn } from '@/lib/utils';

type HighlightedTextProps = {
  text: string;
  highlightWords?: string[];
  highlightClass?: string;
  className?: string;
};

/**
 * Componente para destacar palavras específicas em um texto
 * Uso: <HighlightedText text="Sua plataforma para apostas online" highlightWords={["apostas"]} />
 */
export function HighlightedText({ 
  text, 
  highlightWords = [], 
  highlightClass = "bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-indigo-600 font-semibold",
  className = "" 
}: HighlightedTextProps) {
  if (!highlightWords.length) return <span className={className}>{text}</span>;

  // Escape caracteres especiais nas palavras a serem destacadas
  const escapedHighlightWords = highlightWords.map(word => 
    word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  );
  
  // Criar um regex que corresponde a qualquer uma das palavras a serem destacadas
  const regex = new RegExp(`(${escapedHighlightWords.join('|')})`, 'gi');
  
  // Dividir o texto em partes destacadas e não destacadas
  const parts = text.split(regex);

  return (
    <span className={className}>
      {parts.map((part, i) => {
        // Verificar se esta parte corresponde a uma palavra a ser destacada
        const isHighlighted = highlightWords.some(word => 
          part.toLowerCase() === word.toLowerCase()
        );
        
        return isHighlighted ? (
          <span key={i} className={cn(highlightClass)}>
            {part}
          </span>
        ) : (
          <React.Fragment key={i}>{part}</React.Fragment>
        );
      })}
    </span>
  );
}
