import React from "react";
import { cn } from "@/lib/utils";

interface SectionProps extends React.HTMLAttributes<HTMLElement> {
  children: React.ReactNode;
  className?: string;
  containsBlur?: boolean;
}

export function Section({
  children,
  className,
  containsBlur = false,
  ...props
}: SectionProps) {
  return (
    <section
      className={cn(
        "w-full relative",
        // Padding padrão mais confortável
        "py-12 lg:py-24",
        // Se contém efeito de blur, adiciona overflow hidden
        containsBlur && "overflow-hidden",
        className
      )}
      {...props}
    >
      {children}
    </section>
  );
}
