"use client";

import { cn } from "@/lib/utils";
import React, { useEffect, useState } from "react";
import '@/styles/glowing-border.css';

interface GlowingBorderCardProps {
  children: React.ReactNode;
  className?: string;
  glowColor?: string;
  borderWidth?: number;
  animationDuration?: number;
}

export function GlowingBorderCard({
  children,
  className,
  glowColor = "rgba(147, 51, 234, 0.7)", // Purple by default
  borderWidth = 2,
  animationDuration = 6000,
}: GlowingBorderCardProps) {  const [animate, setAnimate] = useState(false);

  // Iniciar a animação quando o componente montar
  useEffect(() => {
    const timeout = setTimeout(() => setAnimate(true), 100);
    return () => clearTimeout(timeout);
  }, []);

  // Gerenciar a posição do mouse para o efeito de brilho
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    e.currentTarget.style.setProperty('--x', `${x}px`);
    e.currentTarget.style.setProperty('--y', `${y}px`);
  };
  
  return (
    <div
      className={cn(
        "relative rounded-xl p-px overflow-hidden",
        "glowing-border",
        animate && "glowing-border-animate",
        className
      )}
      onMouseMove={handleMouseMove}
      style={{
        "--glow-color": glowColor,
        "--duration": `${animationDuration}ms`,
        boxShadow: `0 0 15px 1px ${glowColor}`,
      } as React.CSSProperties}
    >
      <div 
        className="relative z-10 bg-background rounded-lg h-full"
        style={{ padding: borderWidth }}
      >
        {children}
      </div>
    </div>
  );
}
