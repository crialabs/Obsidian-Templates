"use client";

import { I18nextProvider } from 'react-i18next';
import i18next from 'i18next';
import { useEffect, useState } from 'react';
import { initReactI18next } from 'react-i18next';
import { Locale } from '@/config/i18n';
import resourcesToBackend from 'i18next-resources-to-backend';

// Inicializa i18next com as configurações básicas
i18next
  .use(initReactI18next)
  .use(
    resourcesToBackend((language: string, namespace: string) => 
      import(`../../public/locales/${language}/${namespace}.json`)
    )
  )
  .init({
    lng: 'pt', // valor padrão, será substituído pelo valor da prop
    fallbackLng: 'pt',
    interpolation: {
      escapeValue: false, // não é necessário para React
    },
    defaultNS: 'common',
    react: {
      useSuspense: false,
    },
  });

export function I18nProvider({ 
  children, 
  locale 
}: { 
  children: React.ReactNode; 
  locale: Locale;
}) {
  const [isClient, setIsClient] = useState(false);
  
  useEffect(() => {
    setIsClient(true);
    
    // Altera o idioma quando o componente monta ou a prop locale muda
    if (locale) {
      i18next.changeLanguage(locale);
    }
  }, [locale]);

  // Durante o SSR ou quando o idioma está mudando, renderize os filhos sem o provider
  if (!isClient) {
    return <>{children}</>;
  }

  return (
    <I18nextProvider i18n={i18next}>
      {children}
    </I18nextProvider>
  );
}
