"use client";

import React from "react";
import { useTranslation } from "react-i18next";
import { useParams } from "next/navigation";
import { Locale } from "@/config/i18n";
import { AnimatedBadge } from "./ui/animated-badge";
import { HighlightedText } from "./ui/highlighted-text";

export default function GamesShowcase() {
  // Obtém o parâmetro de idioma atual da URL
  const params = useParams();
  const currentLocale = (params?.locale as Locale) || "pt";
  const { t } = useTranslation("common", { lng: currentLocale });
  
  const games = [
    {
      name: "Money Train 3",
      provider: "Relax Gaming",
      image: "/assets/Mask group-1.png",
      trending: true
    },
    {
      name: "Sweet Bonanza",
      provider: "Pragmatic Play",
      image: "/assets/Mask group-2.png",
      popular: true
    },
    {
      name: "Gates of Olympus",
      provider: "Pragmatic Play",
      image: "/assets/Mask group.png",
      trending: true
    },
    {
      name: "Spaceman",
      provider: "Pragmatic Play",
      image: "/assets/Mask group-1.png",
      popular: true
    }
  ];
  
  return (    <section id="games" className="py-16 md:py-32 bg-zinc-50 dark:bg-zinc-900 relative overflow-hidden">
      {/* Efeito de fundo */}
      <div className="absolute inset-0">
        <div className="absolute w-[500px] h-[500px] -top-32 -left-32 bg-indigo-500/5 rotate-45 rounded-full blur-3xl"></div>
        <div className="absolute w-[400px] h-[400px] bottom-0 right-0 bg-fuchsia-500/5 rotate-12 rounded-full blur-3xl"></div>
      </div>
      
      <div className="mx-auto max-w-6xl px-6 relative z-10">
        <div className="text-center">
          <div className="flex justify-center mb-4">
            <AnimatedBadge variant="gradient" className="mb-4">
              {t("games_showcase.badge")}
            </AnimatedBadge>
          </div>
          <h2 className="text-balance text-4xl font-semibold lg:text-5xl">
            <HighlightedText 
              text={t("games_showcase.title")} 
              highlightWords={["Dashboard"]} 
              highlightClass="bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-violet-600 font-semibold"
            />
          </h2>
          <p className="mt-4 mx-auto max-w-3xl text-lg text-muted-foreground">
            {t("games_showcase.subtitle")}
          </p>
        </div>
          <div className="mt-16 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {games.map((game, index) => (
            <div key={index} className="group relative overflow-hidden rounded-xl bg-white shadow-lg transition-all duration-300 hover:shadow-2xl dark:bg-zinc-800 hover:shadow-violet-500/20">
              <div className="relative h-[320px] w-full overflow-hidden">
                <div className="absolute w-full h-full bg-gradient-to-b from-transparent via-transparent to-black/50 z-10"></div>
                <img
                  src={game.image}
                  alt={game.name}
                  className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                {game.trending && (
                  <div className="absolute left-3 top-3 z-20 rounded-full bg-gradient-to-r from-amber-500 to-orange-500 px-3 py-1 text-xs font-medium text-white shadow-md shadow-orange-500/20">
                    {t("games_showcase.trending_badge")}
                  </div>
                )}
                {game.popular && (
                  <div className="absolute left-3 top-3 z-20 rounded-full bg-gradient-to-r from-blue-500 to-indigo-500 px-3 py-1 text-xs font-medium text-white shadow-md shadow-blue-500/20">
                    {t("games_showcase.popular_badge")}
                  </div>
                )}                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100 z-10"></div>
                <div className="absolute bottom-0 left-0 right-0 translate-y-full p-4 text-white transition-transform duration-300 group-hover:translate-y-0 z-20">
                  <button className="w-full rounded bg-gradient-to-r from-violet-600 to-indigo-600 py-2 font-medium shadow-lg shadow-violet-800/30 hover:shadow-violet-800/50 transition-all duration-300 hover:-translate-y-1">
                    {t("games_showcase.demo_button")}
                  </button>
                </div>
              </div>              <div className="p-4">
                <h3 className="font-semibold text-lg">{game.name}</h3>
                <p className="text-sm text-violet-500 dark:text-violet-400">{game.provider}</p>
              </div>
            </div>
          ))}
        </div>        <div className="mt-12 text-center">
          <button className="inline-flex items-center gap-2 rounded-lg px-5 py-3 font-medium text-white transition-all duration-300 bg-gradient-to-r from-blue-600 to-violet-600 hover:shadow-lg hover:shadow-violet-500/30 transform hover:scale-105">
            {t("games_showcase.view_all_button")}
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              width="18" 
              height="18" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round"
            >
              <path d="M5 12h14"></path>
              <path d="m12 5 7 7-7 7"></path>
            </svg>
          </button>
        </div>
      </div>
    </section>
  );
}
