"use client";

import React from "react";
import Link from "next/link";
import Image from "next/image";
import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { HeroHeader } from "@/components/hero8-header";
import { InfiniteSlider } from "@/components/ui/infinite-slider";
import { ProgressiveBlur } from "@/components/ui/progressive-blur";
import { Locale } from "@/config/i18n";
import { Section } from "./ui/section";

export default function HeroSection({ locale = "pt" }: { locale?: Locale }) {
  const { t } = useTranslation("common", { lng: locale });

  return (
    <>
      <HeroHeader />
      <main>
        <Section className="bg-background min-h-[90vh] relative overflow-hidden">
          {/* Background Image */}
          <div className="absolute inset-0 z-0">
            <Image
              src="/assets/heero.jpg"
              alt="Hero background"
              fill
              priority
              className="object-cover object-center"
            />
          </div>

          {/* Radial glows */}
          <div
            className="absolute -right-32 top-32 w-[600px] h-[600px] rounded-full bg-violet-600/20 blur-[120px] opacity-50 z-10"
            style={{
              animation:
                "radialPulse 8s infinite ease-in-out, radialFloat 15s infinite ease-in-out",
            }}
          />
          <div
            className="absolute left-32 -bottom-32 w-[600px] h-[600px] rounded-full bg-indigo-600/20 blur-[120px] opacity-50 z-10"
            style={{
              animation:
                "radialPulse 12s infinite ease-in-out reverse, radialFloat 20s infinite ease-in-out reverse",
              animationDelay: "2s",
            }}
          />

          {/* Content */}
          <div className="flex items-center min-h-[90vh] z-20 w-full">
            <div className="relative mx-auto flex max-w-7xl flex-col px-6 lg:block py-20">
              <div className="mx-auto max-w-4xl text-center lg:text-left">
                <div className="mb-4 inline-flex">
                  <div className="bg-gradient-to-r from-violet-600 to-indigo-600 rounded-full px-3 py-1 t-sm font-medium text-white inline-flex items-center gap-1">
                    <span className="inline-block w-2 h-2 rounded-full bg-white animate-pulse"></span>
                    {t("hero.badge")}
                  </div>
                </div>
                <h1 className="t-8xl tracking-tight max-w-3xl text-white font-ibm font-semibold leading-[1.1]">
                  {t("hero.title_part1")}{" "}
                  <span className="bg-clip-text text-transparent bg-gradient-to-r from-violet-500 via-fuchsia-400 to-indigo-500">
                    {t("hero.title_highlight")}
                  </span>{" "}
                  {t("hero.title_part2")}
                </h1>
                <p className="mt-8 max-w-2xl text-pretty text-gray-300 t-xl font-ibm">
                  {t("hero.subtitle")}
                </p>

                <div className="mt-12 flex flex-col items-center justify-center gap-2 sm:flex-row lg:justify-start">
                  <Button
                    asChild
                    size="lg"
                    className="px-5 t-lg font-ibm bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 shadow-md shadow-indigo-900/20"
                  >
                    <Link href="#contact">
                      <span className="text-nowrap">{t("hero.cta")}</span>
                    </Link>
                  </Button>
                  <Button
                    key={2}
                    asChild
                    size="lg"
                    variant="ghost"
                    className="px-5 t-lg font-ibm text-white bg-opacity-20 hover:bg-opacity-30 hover:text-white"
                  >
                    <Link href="#contact">
                      <span className="text-nowrap">
                        {t("hero.secondary_cta")}
                      </span>
                    </Link>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </Section>

        <Section className="bg-background pb-16 md:pb-32">
          <div className="group relative m-auto max-w-6xl px-6">
            <div className="flex flex-col items-center md:flex-row">
              <div className="md:max-w-44 md:border-r md:pr-6">
                <p className="text-end text-sm">{t("partners.title")}</p>
              </div>
              <div className="relative py-6 md:w-[calc(100%-11rem)]">
                <InfiniteSlider speedOnHover={20} speed={40} gap={112}>
                  <div className="flex">
                    <img
                      className="mx-auto h-5 w-fit dark:invert"
                      src="https://html.tailus.io/blocks/customers/nvidia.svg"
                      alt="Nvidia Logo"
                      height="20"
                      width="auto"
                    />
                  </div>

                  <div className="flex">
                    <img
                      className="mx-auto h-4 w-fit dark:invert"
                      src="https://html.tailus.io/blocks/customers/column.svg"
                      alt="Column Logo"
                      height="16"
                      width="auto"
                    />
                  </div>
                  <div className="flex">
                    <img
                      className="mx-auto h-4 w-fit dark:invert"
                      src="https://html.tailus.io/blocks/customers/github.svg"
                      alt="GitHub Logo"
                      height="16"
                      width="auto"
                    />
                  </div>
                  <div className="flex">
                    <img
                      className="mx-auto h-5 w-fit dark:invert"
                      src="https://html.tailus.io/blocks/customers/nike.svg"
                      alt="Nike Logo"
                      height="20"
                      width="auto"
                    />
                  </div>
                  <div className="flex">
                    <img
                      className="mx-auto h-5 w-fit dark:invert"
                      src="https://html.tailus.io/blocks/customers/lemonsqueezy.svg"
                      alt="Lemon Squeezy Logo"
                      height="20"
                      width="auto"
                    />
                  </div>
                  <div className="flex">
                    <img
                      className="mx-auto h-4 w-fit dark:invert"
                      src="https://html.tailus.io/blocks/customers/laravel.svg"
                      alt="Laravel Logo"
                      height="16"
                      width="auto"
                    />
                  </div>
                  <div className="flex">
                    <img
                      className="mx-auto h-7 w-fit dark:invert"
                      src="https://html.tailus.io/blocks/customers/lilly.svg"
                      alt="Lilly Logo"
                      height="28"
                      width="auto"
                    />
                  </div>

                  <div className="flex">
                    <img
                      className="mx-auto h-6 w-fit dark:invert"
                      src="https://html.tailus.io/blocks/customers/openai.svg"
                      alt="OpenAI Logo"
                      height="24"
                      width="auto"
                    />
                  </div>
                </InfiniteSlider>

                <div className="bg-linear-to-r from-background absolute inset-y-0 left-0 w-20"></div>
                <div className="bg-linear-to-l from-background absolute inset-y-0 right-0 w-20"></div>
                <ProgressiveBlur
                  className="pointer-events-none absolute left-0 top-0 h-full w-20"
                  direction="left"
                  blurIntensity={1}
                />
                <ProgressiveBlur
                  className="pointer-events-none absolute right-0 top-0 h-full w-20"
                  direction="right"
                  blurIntensity={1}
                />
              </div>
            </div>
          </div>
        </Section>
      </main>
    </>
  );
}
