"use client";

import React from "react";
import { useTranslation } from "react-i18next";
import { useParams } from "next/navigation";
import { Locale } from "@/config/i18n";
import { Button } from "@/components/ui/button";
import { AnimatedBadge } from "./ui/animated-badge";
import { HighlightedText } from "./ui/highlighted-text";
import { Section } from "./ui/section";

export default function PortfolioSection() {
  // Obtém o parâmetro de idioma atual da URL
  const params = useParams();
  const currentLocale = (params?.locale as Locale) || "pt";
  const { t } = useTranslation("common", { lng: currentLocale });

  return (
    <Section id="games" className="bg-zinc-50 relative dark:bg-transparent" containsBlur>
      {/* Background effects */}
      <div className="absolute inset-0 overflow-hidden">
        <div 
          className="absolute w-[600px] h-[600px] rounded-full bg-amber-500/10 blur-[120px] -bottom-32 -left-32 opacity-40 dark:opacity-20"
          style={{animation: 'radialPulse 10s infinite ease-in-out'}}
        />
        <div 
          className="absolute w-[400px] h-[400px] rounded-full bg-amber-400/10 blur-[80px] top-0 right-0 opacity-30 dark:opacity-15"
          style={{animation: 'radialFloat 15s infinite ease-in-out'}}
        />
      </div>
      
      <div className="mx-auto max-w-6xl px-6 relative z-10">
        <div className="text-center">
          <div className="flex justify-center mb-4">
            <AnimatedBadge 
              variant="gradient" 
              className="from-amber-500 to-orange-500"
            >
              Premium Games
            </AnimatedBadge>
          </div>
          
          <h2 className="text-balance text-4xl font-semibold lg:text-5xl">
            <HighlightedText 
              text={t("portfolio.title")} 
              highlightWords={["+3.000"]} 
              highlightClass="bg-clip-text text-transparent bg-gradient-to-r from-amber-500 to-orange-500 font-semibold"
            />
          </h2>
          <p className="mt-4 mx-auto max-w-3xl text-lg text-muted-foreground">
            {t("portfolio.subtitle")}
          </p>
        </div>
        
        <div className="mt-16 grid grid-cols-1 gap-x-8 gap-y-16 md:grid-cols-3">          <div className="group">
            <div className="overflow-hidden rounded-xl shadow-xl shadow-amber-500/10 transition-all duration-300 group-hover:shadow-amber-500/20 group-hover:-translate-y-1">
              <div className="aspect-w-16 aspect-h-9 bg-gradient-to-br from-amber-500 to-orange-500 p-6 text-white relative">
                {/* Animated gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-br from-transparent to-amber-700/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                
                {/* Background pattern */}
                <div className="absolute inset-0 bg-grid-amber opacity-20"></div>
                
                <div className="flex h-full flex-col justify-center relative z-10">
                  <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-white/30 shadow-lg shadow-amber-700/20 group-hover:shadow-amber-700/40 group-hover:scale-110 transition-all duration-300">
                    <svg 
                      xmlns="http://www.w3.org/2000/svg" 
                      width="24" 
                      height="24" 
                      viewBox="0 0 24 24" 
                      fill="none" 
                      stroke="currentColor" 
                      strokeWidth="2" 
                      strokeLinecap="round" 
                      strokeLinejoin="round"
                    >
                      <path d="M4 4a2 2 0 0 1 2-2h8.5a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2Z"></path>
                      <path d="M12.5 2v16"></path>
                      <path d="M7.5 16a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z"></path>
                      <path d="M11.5 7.5h-5"></path>
                      <path d="M11.5 10.5h-5"></path>
                      <path d="m17 10.5 3 3"></path>
                      <path d="m20 10.5-3 3"></path>
                      <path d="M21.5 12a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z"></path>
                      <path d="M20 17a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z"></path>
                      <path d="M16 14a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z"></path>
                      <path d="M20.5 13.5h-5"></path>
                    </svg>
                  </div>
                  <h3 className="text-2xl font-medium group-hover:scale-105 transition-transform duration-300">{t("portfolio.items.casino.title")}</h3>
                </div>
              </div>
            </div>
            <p className="mt-6 text-muted-foreground">
              {t("portfolio.items.casino.description")}
            </p>
            <div className="mt-6 flex flex-wrap items-center gap-2">
              <span className="rounded-full bg-gradient-to-r from-amber-100 to-amber-50 px-3 py-1 text-xs font-medium text-amber-800 shadow-sm shadow-amber-500/5 dark:from-amber-900/30 dark:to-amber-800/30 dark:text-amber-300">Slots</span>
              <span className="rounded-full bg-gradient-to-r from-amber-100 to-amber-50 px-3 py-1 text-xs font-medium text-amber-800 shadow-sm shadow-amber-500/5 dark:from-amber-900/30 dark:to-amber-800/30 dark:text-amber-300">Crash Games</span>
              <span className="rounded-full bg-gradient-to-r from-amber-100 to-amber-50 px-3 py-1 text-xs font-medium text-amber-800 shadow-sm shadow-amber-500/5 dark:from-amber-900/30 dark:to-amber-800/30 dark:text-amber-300">Live Casino</span>
              <span className="rounded-full bg-gradient-to-r from-amber-100 to-amber-50 px-3 py-1 text-xs font-medium text-amber-800 shadow-sm shadow-amber-500/5 dark:from-amber-900/30 dark:to-amber-800/30 dark:text-amber-300">Table Games</span>
            </div>
          </div>
            <div className="group">
            <div className="overflow-hidden rounded-xl shadow-xl shadow-blue-500/10 transition-all duration-300 group-hover:shadow-blue-500/20 group-hover:-translate-y-1">
              <div className="aspect-w-16 aspect-h-9 bg-gradient-to-br from-blue-600 to-cyan-500 p-6 text-white relative">
                {/* Animated gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-br from-transparent to-blue-700/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                
                {/* Background pattern */}
                <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA0MCA0MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0wIDBoNDB2NDBoLTQweiIvPjxjaXJjbGUgc3Ryb2tlPSIjZmZmIiBzdHJva2Utb3BhY2l0eT0iLjEiIGN4PSIyMCIgY3k9IjIwIiByPSI0Ii8+PC9nPjwvc3ZnPg==')]"></div>
                
                <div className="flex h-full flex-col justify-center relative z-10">
                  <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-white/30 shadow-lg shadow-blue-700/20 group-hover:shadow-blue-700/40 group-hover:scale-110 transition-all duration-300">
                    <svg 
                      xmlns="http://www.w3.org/2000/svg" 
                      width="24" 
                      height="24" 
                      viewBox="0 0 24 24" 
                      fill="none" 
                      stroke="currentColor" 
                      strokeWidth="2" 
                      strokeLinecap="round" 
                      strokeLinejoin="round"
                    >
                      <circle cx="12" cy="12" r="10"></circle>
                      <path d="m10 8 4 8"></path>
                      <path d="m10 16 4-8"></path>
                      <path d="M15 12H9"></path>
                    </svg>
                  </div>
                  <h3 className="text-2xl font-medium group-hover:scale-105 transition-transform duration-300">{t("portfolio.items.sports.title")}</h3>
                  
                  <div className="absolute top-3 right-3">
                    <AnimatedBadge 
                      variant="gradient" 
                      className="from-white/40 to-white/10 text-white text-xs"
                    >
                      Live Stream
                    </AnimatedBadge>
                  </div>
                </div>
              </div>
            </div>
            <p className="mt-6 text-muted-foreground">
              {t("portfolio.items.sports.description")}
            </p>
            <div className="mt-6 flex flex-wrap items-center gap-2">
              <span className="rounded-full bg-gradient-to-r from-blue-100 to-blue-50 px-3 py-1 text-xs font-medium text-blue-800 shadow-sm shadow-blue-500/5 dark:from-blue-900/30 dark:to-blue-800/30 dark:text-blue-300">Football</span>
              <span className="rounded-full bg-gradient-to-r from-blue-100 to-blue-50 px-3 py-1 text-xs font-medium text-blue-800 shadow-sm shadow-blue-500/5 dark:from-blue-900/30 dark:to-blue-800/30 dark:text-blue-300">Basketball</span>
              <span className="rounded-full bg-gradient-to-r from-blue-100 to-blue-50 px-3 py-1 text-xs font-medium text-blue-800 shadow-sm shadow-blue-500/5 dark:from-blue-900/30 dark:to-blue-800/30 dark:text-blue-300">Tennis</span>
              <span className="rounded-full bg-gradient-to-r from-blue-100 to-blue-50 px-3 py-1 text-xs font-medium text-blue-800 shadow-sm shadow-blue-500/5 dark:from-blue-900/30 dark:to-blue-800/30 dark:text-blue-300">MMA</span>
            </div>
          </div>
            <div className="group">
            <div className="overflow-hidden rounded-xl shadow-xl shadow-green-500/10 transition-all duration-300 group-hover:shadow-green-500/20 group-hover:-translate-y-1">
              <div className="aspect-w-16 aspect-h-9 bg-gradient-to-br from-green-500 to-emerald-500 p-6 text-white relative">
                {/* Animated gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-br from-transparent to-green-700/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                
                {/* Background pattern - diamond pattern */}
                <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAiIGhlaWdodD0iMzAiIHZpZXdCb3g9IjAgMCAzMCAzMCIgeG1zbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMTUgMTVMMCAwaDMwTDE1IDE1em0wIDBMMzAgMzBIMEwxNSAxNXptMCAwTDAgMzBoMzBMMTUgMTV6bTAgMEwxNSAwSDB2MzBsMTUtMTV6IiBmaWxsPSIjZmZmIiBmaWxsLW9wYWNpdHk9Ii4xIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=')]"></div>
                
                <div className="flex h-full flex-col justify-center relative z-10">
                  <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-white/30 shadow-lg shadow-green-700/20 group-hover:shadow-green-700/40 group-hover:scale-110 transition-all duration-300">
                    <svg 
                      xmlns="http://www.w3.org/2000/svg" 
                      width="24" 
                      height="24" 
                      viewBox="0 0 24 24" 
                      fill="none" 
                      stroke="currentColor" 
                      strokeWidth="2" 
                      strokeLinecap="round" 
                      strokeLinejoin="round"
                    >
                      <path d="M21 12V7H5a2 2 0 0 1 0-4h14v4"></path>
                      <path d="M3 5v14a2 2 0 0 0 2 2h16v-5"></path>
                      <path d="M18 12a2 2 0 0 0 0 4h4v-4Z"></path>
                    </svg>
                  </div>
                  <h3 className="text-2xl font-medium group-hover:scale-105 transition-transform duration-300">{t("portfolio.items.localized.title")}</h3>
                  
                  <div className="absolute top-3 right-3">
                    <AnimatedBadge 
                      variant="gradient" 
                      className="from-white/40 to-white/10 text-white text-xs"
                    >
                      Popular
                    </AnimatedBadge>
                  </div>
                </div>
              </div>
            </div>
            <p className="mt-6 text-muted-foreground">
              {t("portfolio.items.localized.description")}
            </p>
            <div className="mt-6 flex flex-wrap items-center gap-2">
              <span className="rounded-full bg-gradient-to-r from-green-100 to-green-50 px-3 py-1 text-xs font-medium text-green-800 shadow-sm shadow-green-500/5 dark:from-green-900/30 dark:to-green-800/30 dark:text-green-300">Jogo do Tigrinho</span>
              <span className="rounded-full bg-gradient-to-r from-green-100 to-green-50 px-3 py-1 text-xs font-medium text-green-800 shadow-sm shadow-green-500/5 dark:from-green-900/30 dark:to-green-800/30 dark:text-green-300">Fortune Tiger</span>
              <span className="rounded-full bg-gradient-to-r from-green-100 to-green-50 px-3 py-1 text-xs font-medium text-green-800 shadow-sm shadow-green-500/5 dark:from-green-900/30 dark:to-green-800/30 dark:text-green-300">Fortune Ox</span>
              <span className="rounded-full bg-gradient-to-r from-green-100 to-green-50 px-3 py-1 text-xs font-medium text-green-800 shadow-sm shadow-green-500/5 dark:from-green-900/30 dark:to-green-800/30 dark:text-green-300">Fortune Mouse</span>
            </div>
          </div>
        </div>
        
        {/* Call to action button */}
        <div className="mt-16 text-center">
          <Button 
            className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white shadow-lg shadow-amber-500/20 hover:shadow-amber-600/30 transition-all duration-300 hover:-translate-y-1 px-6 py-6 text-base font-medium"
          >
            {t("portfolio.cta")}
          </Button>
          
          {/* Decorative element */}
          <div className="mt-12 max-w-md mx-auto h-1 bg-gradient-to-r from-transparent via-amber-500/30 to-transparent rounded-full"></div>
        </div>
      </div>
    </Section>
  );
}
