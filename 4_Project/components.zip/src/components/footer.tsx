"use client";

import { Logo } from "@/components/logo";
import Link from "next/link";
import { useTranslation } from "react-i18next";
import { useParams } from "next/navigation";
import { Locale } from "@/config/i18n";
import { Button } from "@/components/ui/button";
import { Instagram, Youtube } from "lucide-react";

export default function FooterSection() {
  // Obtém o parâmetro de idioma atual da URL
  const params = useParams();
  const currentLocale = (params?.locale as Locale) || "pt";
  const { t } = useTranslation("common", { lng: currentLocale });
  
  const footerLinks = [
    { title: t("footer.links.items.about"), href: "#about" },
    { title: t("footer.links.items.solutions"), href: "#solutions" },
    { title: t("footer.links.items.products"), href: "#games" },
    { title: t("footer.links.items.setup"), href: "#setup" },
    { title: t("footer.links.items.clients"), href: "#clients" },
    { title: t("footer.links.items.contact"), href: "#contact" },
    { title: t("footer.links.items.blog"), href: "#blog" },
  ];
  
  return (
    <footer className="w-full py-12 mt-20">
      <div className="container px-4">
        <div className="glass glass-hover rounded-xl p-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="space-y-4">
              <h3 className="font-medium text-lg">Orbit Gaming</h3>
              <p className="text-sm text-muted-foreground">
                Transformando o mercado de apostas online com soluções tecnológicas rápidas e lucrativas.
              </p>
              <div className="flex space-x-4">
                <Button variant="ghost" size="icon">
                  <Instagram className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon">
                  <Youtube className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="font-medium">Soluções</h4>
              <ul className="space-y-2">
                <li>
                  <a href="#features" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                    Setup Completo
                  </a>
                </li>
                <li>
                  <a href="#pricing" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                    Portfólio de Jogos
                  </a>
                </li>
                <li>
                  <a href="#" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                    Jogos Personalizados
                  </a>
                </li>
              </ul>
            </div>

            <div className="space-y-4">
              <h4 className="font-medium">Suporte</h4>
              <ul className="space-y-2">
                <li>
                  <a href="#" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                    Consultoria Estratégica
                  </a>
                </li>
                <li>
                  <a href="#" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                    Documentação Técnica
                  </a>
                </li>
                <li>
                  <a href="#" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                    FAQ
                  </a>
                </li>
              </ul>
            </div>

            <div className="space-y-4">
              <h4 className="font-medium">Contato</h4>
              <ul className="space-y-2">
                <li>
                  <a href="mailto:contato@orbitgaming.com.br" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                    contato@orbitgaming.com.br
                  </a>
                </li>
                <li>
                  <a href="#" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                    WhatsApp
                  </a>
                </li>
                <li>
                  <span className="text-sm text-muted-foreground">
                    Brasil e América Latina
                  </span>
                </li>
              </ul>
            </div>
          </div>

          <div className="mt-8 pt-8 border-t border-white/10">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
              <p className="text-sm text-muted-foreground">
                © {new Date().getFullYear()} Orbit Gaming Tecnologia S.A. Todos os direitos reservados.
              </p>
              <div className="flex gap-4">
                <a href="#" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Política de Privacidade
                </a>
                <a href="#" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Termos de Uso
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};


