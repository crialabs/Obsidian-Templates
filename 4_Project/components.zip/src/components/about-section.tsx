"use client";

import React from "react";
import { useTranslation } from "react-i18next";
import { useParams } from "next/navigation";
import { Locale } from "@/config/i18n";
import { Check } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Sparkles } from "./ui/sparkles";
import { AnimatedBadge } from "./ui/animated-badge";
import { HighlightedText } from "./ui/highlighted-text";
import { Section } from "./ui/section";

export default function AboutSection() {
  // Obtém o parâmetro de idioma atual da URL
  const params = useParams();
  const currentLocale = (params?.locale as Locale) || "pt";
  const { t } = useTranslation("common", { lng: currentLocale });
  
  return (
    <Section id="about" className="relative" containsBlur>
      {/* Background effects */}
      <div className="absolute inset-0 overflow-hidden">
        <div 
          className="absolute w-[600px] h-[600px] rounded-full bg-indigo-500/10 blur-[120px] -bottom-32 -left-32 opacity-60 dark:opacity-30" 
          style={{animation: 'radialPulse 10s infinite ease-in-out, radialFloat 20s infinite ease-in-out alternate'}}
        />
        <div 
          className="absolute w-[400px] h-[400px] rounded-full bg-purple-500/10 blur-[80px] top-0 right-0 opacity-50 dark:opacity-20" 
          style={{animation: 'radialPulse 15s infinite ease-in-out'}}
        />
      </div>
      
      <div className="container mx-auto relative z-10">
        <div className="grid border border-indigo-200/30 dark:border-indigo-500/20 rounded-xl shadow-xl shadow-indigo-500/5 backdrop-blur-sm container p-8 grid-cols-1 gap-8 items-center lg:grid-cols-2 bg-white/70 dark:bg-zinc-900/70">
          <div className="flex gap-10 flex-col">
            <div className="flex gap-4 flex-col">
              <div>
                <AnimatedBadge 
                  variant="gradient" 
                  className="from-indigo-500 to-purple-600"
                >
                  {t("about.badge")}
                </AnimatedBadge>
              </div>
              <div className="flex gap-2 flex-col">
                <h2 className="text-3xl lg:text-5xl tracking-tighter max-w-xl text-left font-regular">
                  <HighlightedText 
                    text={t("about.title")} 
                    highlightWords={["Orbit Gaming"]} 
                    highlightClass="bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-purple-600 font-semibold"
                  />
                </h2>
                <p className="text-lg leading-relaxed tracking-tight text-muted-foreground max-w-xl text-left">
                  {t("about.description")}
                </p>
              </div>
            </div>
            
            <div className="grid lg:pl-6 grid-cols-1 sm:grid-cols-2 items-start lg:grid-cols-2 gap-6">
              <div className="flex flex-row gap-6 items-start group hover:scale-105 transition-transform duration-300">
                <div className="h-8 w-8 flex items-center justify-center rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 text-white shadow-md shadow-indigo-500/30 group-hover:shadow-indigo-500/50 transition-all duration-300">
                  <Check className="w-4 h-4" />
                </div>
                <div className="flex flex-col gap-1">
                  <p className="font-medium">{t("about.features.speed.title")}</p>
                  <p className="text-muted-foreground text-sm">
                    {t("about.features.speed.description")}
                  </p>
                </div>
              </div>
              
              <div className="flex flex-row gap-6 items-start group hover:scale-105 transition-transform duration-300">
                <div className="h-8 w-8 flex items-center justify-center rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 text-white shadow-md shadow-indigo-500/30 group-hover:shadow-indigo-500/50 transition-all duration-300">
                  <Check className="w-4 h-4" />
                </div>
                <div className="flex flex-col gap-1">
                  <p className="font-medium">{t("about.features.stability.title")}</p>
                  <p className="text-muted-foreground text-sm">
                    {t("about.features.stability.description")}
                  </p>
                </div>
              </div>
              
              <div className="flex flex-row gap-6 items-start group hover:scale-105 transition-transform duration-300">
                <div className="h-8 w-8 flex items-center justify-center rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 text-white shadow-md shadow-indigo-500/30 group-hover:shadow-indigo-500/50 transition-all duration-300">
                  <Check className="w-4 h-4" />
                </div>
                <div className="flex flex-col gap-1">
                  <p className="font-medium">{t("about.features.security.title")}</p>
                  <p className="text-muted-foreground text-sm">
                    {t("about.features.security.description")}
                  </p>
                </div>
              </div>
              
              <div className="flex flex-row gap-6 items-start group hover:scale-105 transition-transform duration-300">
                <div className="h-8 w-8 flex items-center justify-center rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 text-white shadow-md shadow-indigo-500/30 group-hover:shadow-indigo-500/50 transition-all duration-300">
                  <Check className="w-4 h-4" />
                </div>
                <div className="flex flex-col gap-1">
                  <p className="font-medium">{t("about.features.scalability.title")}</p>
                  <p className="text-muted-foreground text-sm">
                    {t("about.features.scalability.description")}
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="relative overflow-hidden rounded-xl aspect-square bg-gradient-to-br from-indigo-100 to-white dark:from-indigo-950/30 dark:to-zinc-900/30 shadow-xl shadow-indigo-500/10 border border-indigo-200/30 dark:border-indigo-800/30">
            <div 
              className="absolute inset-0 rounded-xl bg-grid-indigo/20 [mask-image:radial-gradient(ellipse_at_center,transparent_20%,black)]"
            ></div>
            <div className="absolute inset-0 flex items-center justify-center">
              <img 
                src="/assets/Frame 127.png"
                alt="Orbit Gaming Platform"
                className="h-[80%] w-auto object-contain relative z-10 hover:scale-105 transition-transform duration-500 ease-out"
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-tr from-indigo-500/20 to-purple-500/10 opacity-60"></div>
            <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-white/80 to-transparent dark:from-zinc-900/80"></div>
          </div>
        </div>
        <div className="relative -mt-32 h-96 w-full overflow-hidden [mask-image:radial-gradient(50%_50%,white,transparent)]">
          <div className="absolute inset-0 before:absolute before:inset-0 before:bg-[radial-gradient(circle_at_bottom_center,#8350e8,transparent_70%)] before:opacity-40" />
          <div className="absolute -left-1/2 top-1/2 aspect-[1/0.7] z-10 w-[200%] rounded-[100%] border-t border-zinc-900/20 dark:border-white/20 bg-white dark:bg-zinc-900" />
          <Sparkles
            density={1200}
            className="absolute inset-x-0 bottom-0 h-full w-full [mask-image:radial-gradient(50%_50%,white,transparent_85%)]"
          />
        </div>
      </div>
    </Section>
  );
}
