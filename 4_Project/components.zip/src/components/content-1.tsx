"use client";

import Image from "next/image";
import { useTranslation } from "react-i18next";
import { useParams } from "next/navigation";
import { Locale } from "@/config/i18n";
import { Section } from "./ui/section";

export default function ContentSection() {
  // Obtém o parâmetro de idioma atual da URL
  const params = useParams();
  const currentLocale = (params?.locale as Locale) || "pt";
  const { t } = useTranslation("common", { lng: currentLocale });

  return (
    <Section id="content" className="relative">
      <div className="mx-auto max-w-6xl px-6">
        <div className="grid gap-x-6 gap-y-12 lg:grid-cols-2 lg:gap-x-12 lg:gap-y-16">
          <div className="relative">
            <Image
              src="/payments-dark.png"
              className="hidden rounded-[15px] dark:block"
              alt="payments illustration dark"
              width={1207}
              height={929}
            />
            <Image
              src="/payments-light.png"
              className="rounded-[15px] shadow dark:hidden"
              alt="payments illustration light"
              width={1207}
              height={929}
            />
          </div>

          <div className="relative space-y-4">
            <p className="text-muted-foreground">
              <span className="text-accent-foreground font-bold">
                Orbit Gaming
              </span>{" "}
              evolui constantemente para oferecer mais que apenas jogos.{" "}
              <span className="text-accent-foreground font-bold">
                Suportamos um ecossistema completo
              </span>{" "}
              — de produtos a APIs e plataformas que ajudam operadores a inovar.
            </p>
            <p className="text-muted-foreground">
              Nossa plataforma integra jogos, sistemas de pagamento, ferramentas de marketing e suporte 24/7, tudo em um único lugar para maximizar seus resultados.
            </p>

            <div className="pt-6">
              <blockquote className="border-l-4 pl-4">
                <p>
                  {t("testimonials.testimonial")}
                </p>

                <div className="mt-6 space-y-3">
                  <cite className="block font-medium">Marcos Silva, COO 7K.BET</cite>
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-primary">{t("testimonials.results.revenue")}</span>
                    <span className="text-sm">•</span>
                    <span className="font-semibold text-primary">{t("testimonials.results.players")}</span>
                  </div>
                </div>
              </blockquote>
            </div>
          </div>
        </div>
      </div>
    </Section>
  );
}
