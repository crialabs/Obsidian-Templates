"use client";

import React from "react";
import { useTranslation } from "react-i18next";
import { useParams } from "next/navigation";
import { Locale } from "@/config/i18n";
import { Button } from "@/components/ui/button";
import { AnimatedBadge } from "./ui/animated-badge";
import { HighlightedText } from "./ui/highlighted-text";
import { GlowingBorderCard } from "./ui/glowing-border-card";
import { Section } from "./ui/section";

export default function SetupSection() {
  // Obtém o parâmetro de idioma atual da URL
  const params = useParams();
  const currentLocale = (params?.locale as Locale) || "pt";
  const { t } = useTranslation("common", { lng: currentLocale });
  
  return (
    <Section id="setup" className="relative" containsBlur>
      {/* Background effect */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-primary/20 dark:from-primary/10 dark:to-primary/20" />
      
      {/* Animated grid background */}
      <div className="absolute inset-0 bg-grid-indigo opacity-30" />
      
      {/* Radial glows */}
      <div className="absolute bottom-0 right-0 w-[600px] h-[600px] rounded-full bg-purple-500/20 blur-[100px] opacity-40 dark:opacity-20" />
      
      <div className="absolute top-20 left-20 w-[400px] h-[400px] rounded-full bg-blue-500/20 blur-[80px] opacity-30 dark:opacity-15"
           style={{animation: 'radialPulse 12s infinite ease-in-out'}} />
      
      <div className="mx-auto max-w-5xl px-6 relative z-10">
        <div className="text-center">
          <div className="flex justify-center mb-4">
            <AnimatedBadge 
              variant="gradient" 
              className="from-purple-500 to-blue-600"
            >
              48h Setup
            </AnimatedBadge>
          </div>
          
          <h2 className="text-balance text-4xl font-semibold lg:text-5xl">
            <HighlightedText 
              text={t("setup.title")} 
              highlightWords={["48h"]} 
              highlightClass="bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-blue-600 font-semibold"
            />
          </h2>
          <p className="mt-4 mx-auto max-w-3xl text-lg text-muted-foreground">
            {t("setup.subtitle")}
          </p>
        </div>
        
        <div className="mt-16 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
          <div className="flex flex-col rounded-xl bg-white/80 dark:bg-zinc-800/80 backdrop-blur-sm p-6 shadow-lg border border-white/50 dark:border-zinc-700/50 group hover:shadow-xl hover:shadow-purple-500/10 transition-all duration-300 hover:-translate-y-1">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-to-br from-purple-500 to-blue-600 text-white shadow-md shadow-purple-500/20 group-hover:shadow-purple-500/40 transition-all duration-300">
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                width="24" 
                height="24" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round"
              >
                <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"></path>
              </svg>
            </div>
            <h3 className="mt-4 text-lg font-medium bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-blue-600 group-hover:from-purple-500 group-hover:to-blue-500 transition-all duration-300">
              {t("setup.items.speed.title")}
            </h3>
            <p className="mt-2 flex-1 text-sm text-muted-foreground">
              {t("setup.items.speed.description")}
            </p>
          </div>
            <div className="flex flex-col rounded-xl bg-white/80 dark:bg-zinc-800/80 backdrop-blur-sm p-6 shadow-lg border border-white/50 dark:border-zinc-700/50 group hover:shadow-xl hover:shadow-blue-500/10 transition-all duration-300 hover:-translate-y-1">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-to-br from-blue-600 to-cyan-500 text-white shadow-md shadow-blue-500/20 group-hover:shadow-blue-500/40 transition-all duration-300">
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                width="24" 
                height="24" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round"
              >
                <rect width="18" height="18" x="3" y="3" rx="2"></rect>
                <path d="M7 7h.01"></path>
                <path d="M17 7h.01"></path>
                <path d="M7 17h.01"></path>
                <path d="M17 17h.01"></path>
              </svg>
            </div>
            <h3 className="mt-4 text-lg font-medium bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-cyan-500 group-hover:from-blue-500 group-hover:to-cyan-400 transition-all duration-300">
              {t("setup.items.integrations.title")}
            </h3>
            <p className="mt-2 flex-1 text-sm text-muted-foreground">
              {t("setup.items.integrations.description")}
            </p>
          </div>
          
          <div className="flex flex-col rounded-xl bg-white/80 dark:bg-zinc-800/80 backdrop-blur-sm p-6 shadow-lg border border-white/50 dark:border-zinc-700/50 group hover:shadow-xl hover:shadow-indigo-500/10 transition-all duration-300 hover:-translate-y-1">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-to-br from-indigo-600 to-violet-500 text-white shadow-md shadow-indigo-500/20 group-hover:shadow-indigo-500/40 transition-all duration-300">
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                width="24" 
                height="24" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round"
              >
                <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"></path>
                <circle cx="12" cy="12" r="3"></circle>
              </svg>
            </div>
            <h3 className="mt-4 text-lg font-medium bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-violet-500 group-hover:from-indigo-500 group-hover:to-violet-400 transition-all duration-300">
              {t("setup.items.support.title")}
            </h3>
            <p className="mt-2 flex-1 text-sm text-muted-foreground">
              {t("setup.items.support.description")}
            </p>
          </div>
          
          <div className="flex flex-col rounded-xl bg-white/80 dark:bg-zinc-800/80 backdrop-blur-sm p-6 shadow-lg border border-white/50 dark:border-zinc-700/50 group hover:shadow-xl hover:shadow-fuchsia-500/10 transition-all duration-300 hover:-translate-y-1">            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-to-br from-fuchsia-600 to-purple-500 text-white shadow-md shadow-fuchsia-500/20 group-hover:shadow-fuchsia-500/40 transition-all duration-300">
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                width="24" 
                height="24" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round"
              >
                <path d="M18 8V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h8"></path>
                <path d="M10 19v-3.96l1.05-.63"></path>
                <path d="M15.23 19h4.27a2.5 2.5 0 1 0-4.5-2"></path>
              </svg>
            </div>
            <h3 className="mt-4 text-lg font-medium bg-clip-text text-transparent bg-gradient-to-r from-fuchsia-600 to-purple-500 group-hover:from-fuchsia-500 group-hover:to-purple-400 transition-all duration-300">
              {t("setup.items.consulting.title")}
            </h3>
            <p className="mt-2 flex-1 text-sm text-muted-foreground">
              {t("setup.items.consulting.description")}
            </p>
          </div>
        </div>
        
        <div className="mt-16 text-center relative">
          <GlowingBorderCard
            className="inline-block"
            glowColor="rgba(147, 51, 234, 0.5)" // Purple glow
            borderWidth={2}
            animationDuration={8000}
          >
            <Button 
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 px-8 py-6 text-base text-white shadow-lg shadow-purple-500/20 hover:shadow-purple-600/30 transition-all duration-300 hover:-translate-y-1"
            >
              {t("setup.cta")}
            </Button>
          </GlowingBorderCard>
          
          <div className="absolute inset-0 blur-3xl bg-purple-500/10 rounded-full -z-10"></div>
        </div>
      </div>
    </Section>
  );
}
