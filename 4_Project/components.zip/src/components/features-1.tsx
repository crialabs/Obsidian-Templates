"use client";

import { useTranslation } from "react-i18next";
import { useParams } from "next/navigation";
import { Locale } from "@/config/i18n";
import { FeatureSteps } from "./feature-section";
import { AnimatedBadge } from "./ui/animated-badge";
import { HighlightedText } from "./ui/highlighted-text";
import { Section } from "./ui/section";

export default function Features() {
  // Obtém o parâmetro de idioma atual da URL
  const params = useParams();
  const currentLocale = (params?.locale as Locale) || "pt";
  const { t } = useTranslation("common", { lng: currentLocale });

  const features = [
    { 
      step: '01', 
      title: t("features.items.games.title"),
      content: t("features.items.games.description"), 
      image: '/assets/Mask group-1.png'
    },
    { 
      step: '02',
      title: t("features.items.rtp.title"),
      content: t("features.items.rtp.description"),
      image: '/assets/Mask group-2.png'
    },
    { 
      step: '03',
      title: t("features.items.jackpots.title"),
      content: t("features.items.jackpots.description"),
      image: '/assets/Mask group.png'
    },
  ];

  return (
    <Section id="features" className="bg-zinc-50 relative dark:bg-transparent" containsBlur>
      {/* Efeito radial animado */}
      <div className="absolute top-0 z-[0] h-screen w-screen bg-purple-950/10 dark:bg-purple-950/10 bg-[radial-gradient(ellipse_20%_80%_at_50%_-20%,rgba(120,119,198,0.15),rgba(255,255,255,0))] dark:bg-[radial-gradient(ellipse_20%_80%_at_50%_-20%,rgba(120,119,198,0.3),rgba(255,255,255,0))]" />
      <div className="absolute inset-0 overflow-hidden">
        <div 
          className="absolute w-[600px] h-[600px] rounded-full bg-purple-500/10 blur-[120px] -top-32 -right-32 opacity-60 dark:opacity-30" 
          style={{animation: 'radialPulse 8s infinite ease-in-out, radialFloat 15s infinite ease-in-out'}}
        ></div>
        <div 
          className="absolute w-[700px] h-[700px] rounded-full bg-violet-600/10 blur-[150px] -bottom-64 -left-32 opacity-60 dark:opacity-30" 
          style={{animation: 'radialPulse 12s infinite ease-in-out reverse, radialFloat 20s infinite ease-in-out reverse', animationDelay: '3s'}}
        ></div>
        <div 
          className="absolute w-[300px] h-[300px] rounded-full bg-fuchsia-400/10 blur-[80px] top-1/3 left-2/3 opacity-40 dark:opacity-20" 
          style={{animation: 'radialPulse 10s infinite ease-in-out, radialFloat 25s infinite ease-in-out', animationDelay: '1s'}}
        ></div>
      </div>
      
      <div className="mx-auto max-w-6xl px-6 relative z-10">
        <div className="text-center mb-12">
          <div className="flex justify-center mb-4">
            <AnimatedBadge variant="gradient" className="mb-4">
              {t("features.badge")}
            </AnimatedBadge>
          </div>
          <h2 className="text-balance text-4xl font-semibold lg:text-5xl">
            <HighlightedText 
              text={t("features.title")} 
              highlightWords={["+3.000"]} 
              highlightClass="bg-clip-text text-transparent bg-gradient-to-r from-violet-600 to-indigo-600 font-semibold"
            />
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            {t("features.subtitle")}
          </p>
        </div>
        
        <FeatureSteps 
          features={features}
          autoPlayInterval={4000}
          imageHeight="h-[500px]"
        />
      </div>
    </Section>
  )
}