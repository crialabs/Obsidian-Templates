import { redirect } from 'next/navigation';
import { i18n } from '@/config/i18n';

export default function Home() {
  // Redireciona para a versão localizada padrão
  redirect(`/${i18n.defaultLocale}`);
}
