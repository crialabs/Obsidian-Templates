import HeroSection from "@/components/hero-section";
import AboutSection from "@/components/about-section";
import Features from "@/components/features-1";
import GamesShowcase from "@/components/games-showcase";
import SetupSection from "@/components/setup-section";
import PortfolioSection from "@/components/portfolio-section";
import ContentSection from "@/components/content-1";
import CallToAction from "@/components/call-to-action";
import FooterSection from "@/components/footer";
import { TiltedScrollDemo } from '@/components/features-animation';
import { i18n, Locale } from "@/config/i18n";

// Gera rotas estáticas para cada idioma suportado
export function generateStaticParams() {
  return i18n.locales.map((locale) => ({ locale }));
}

export default function Home({ params }: { params: { locale: Locale } }) {
  return (
    <>
      <HeroSection locale={params.locale} />
      <AboutSection />
      <Features />
      <GamesShowcase />
      <SetupSection />
      <PortfolioSection />
      <TiltedScrollDemo />
      <ContentSection />
      <CallToAction />
      <FooterSection />
    </>
  );
}
