# Orbit Gaming - Landing Page

Este é um projeto [Next.js](https://nextjs.org) que utiliza App Router e i18n para internacionalização.

## Começando

Primeiro, instale as dependências:

```bash
pnpm install
```

Depois, execute o servidor de desenvolvimento:

```bash
pnpm dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

Acesse [http://localhost:3000](http://localhost:3000) no navegador para ver o resultado. Você será redirecionado automaticamente para a versão localizada do site.

## Configuração de i18n

Este projeto utiliza uma configuração personalizada para suporte a múltiplos idiomas com Next.js App Router e i18next. As características incluem:

- Detecção automática do idioma do navegador
- Rotas localizadas com o formato `/[locale]/rota`
- Suporte para múltiplos namespaces de tradução
- Alternador de idioma integrado
- SSR e CSR funcionando perfeitamente

### Estrutura de arquivos

```
public/
  locales/            # Arquivos de tradução
    en/
      common.json     # Traduções em inglês
    pt/
      common.json     # Traduções em português
src/
  app/
    [locale]/         # Rotas localizadas
      page.tsx        # Página principal
  components/
    i18n-provider.tsx # Provedor de i18n para o App Router
  config/
    i18n.ts           # Configuração de i18n
```

### Adicionando novas traduções

Para adicionar novos textos, adicione as chaves nos arquivos JSON em `public/locales/[idioma]/common.json`.

## Saiba mais

Para saber mais sobre Next.js e i18next, consulte os seguintes recursos:

- [Documentação do Next.js](https://nextjs.org/docs)
- [Documentação do React-i18next](https://react.i18next.com/)

## Deploy on Vercel

The easiest way to deploy your Next.js app is to use the [Vercel Platform](https://vercel.com/new?utm_medium=default-template&filter=next.js&utm_source=create-next-app&utm_campaign=create-next-app-readme) from the creators of Next.js.

Check out our [Next.js deployment documentation](https://nextjs.org/docs/app/building-your-application/deploying) for more details.
