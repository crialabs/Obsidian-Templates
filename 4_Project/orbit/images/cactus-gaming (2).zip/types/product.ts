export interface Product {
  id: string
  name: string
  description: string
  price: string
  category: string
  image?: string
  isNew?: boolean
  rating?: number
  stock?: number
}
