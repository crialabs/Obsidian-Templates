import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowRight, Code, BarChart, Zap, Shield, Users, Globe } from "lucide-react"

export default function SolutionsPage() {
  return (
    <div className="container mx-auto py-12 px-4">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold mb-4">Nossas Soluções</h1>
        <p className="text-xl text-gray-400 max-w-3xl mx-auto">
          Soluções inovadoras para impulsionar seu negócio de apostas online e maximizar seus resultados.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <div className="bg-purple-600/20 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
              <Code className="h-6 w-6 text-purple-400" />
            </div>
            <CardTitle>Plataforma White Label</CardTitle>
            <CardDescription>Solução completa e personalizada para seu negócio</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-gray-300 mb-6">
              Nossa plataforma white label oferece uma solução completa para iniciar seu negócio de apostas online com
              rapidez e eficiência. Personalize sua marca, escolha seus jogos e comece a operar em poucos dias.
            </p>
            <Button variant="outline" className="w-full" asChild>
              <Link href="/contato" className="flex items-center justify-center">
                Saiba mais <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <div className="bg-purple-600/20 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
              <Globe className="h-6 w-6 text-purple-400" />
            </div>
            <CardTitle>Integração de API</CardTitle>
            <CardDescription>Solução robusta para operadores existentes</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-gray-300 mb-6">
              Oferecemos uma solução de API robusta projetada para operadores online existentes que desejam integrar
              nossas soluções de jogos e apostas, bem como Odds Feed, em suas plataformas existentes.
            </p>
            <Button variant="outline" className="w-full" asChild>
              <Link href="/contato" className="flex items-center justify-center">
                Saiba mais <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <div className="bg-purple-600/20 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
              <BarChart className="h-6 w-6 text-purple-400" />
            </div>
            <CardTitle>Gestão de Risco</CardTitle>
            <CardDescription>Controle total sobre suas operações</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-gray-300 mb-6">
              Nossa solução de gestão de risco oferece ferramentas avançadas para monitorar e controlar suas operações,
              garantindo a segurança e a rentabilidade do seu negócio de apostas online.
            </p>
            <Button variant="outline" className="w-full" asChild>
              <Link href="/contato" className="flex items-center justify-center">
                Saiba mais <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <div className="bg-purple-600/20 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
              <Zap className="h-6 w-6 text-purple-400" />
            </div>
            <CardTitle>Otimização de Conversão</CardTitle>
            <CardDescription>Aumente suas taxas de conversão em até 50%</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-gray-300 mb-6">
              Nossa equipe de especialistas em otimização trabalha para maximizar suas taxas de conversão, aplicando
              estratégias comprovadas que podem aumentar seus resultados em até 50% comparado a outros sistemas.
            </p>
            <Button variant="outline" className="w-full" asChild>
              <Link href="/contato" className="flex items-center justify-center">
                Saiba mais <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <div className="bg-purple-600/20 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
              <Shield className="h-6 w-6 text-purple-400" />
            </div>
            <CardTitle>Segurança e Compliance</CardTitle>
            <CardDescription>Operações seguras e em conformidade</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-gray-300 mb-6">
              Garantimos que sua plataforma opere com os mais altos padrões de segurança e em conformidade com as
              regulamentações do setor, protegendo seu negócio e seus usuários.
            </p>
            <Button variant="outline" className="w-full" asChild>
              <Link href="/contato" className="flex items-center justify-center">
                Saiba mais <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <div className="bg-purple-600/20 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
              <Users className="h-6 w-6 text-purple-400" />
            </div>
            <CardTitle>Suporte 24/7</CardTitle>
            <CardDescription>Assistência contínua para seu negócio</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-gray-300 mb-6">
              Nossa equipe de suporte está disponível 24 horas por dia, 7 dias por semana, para resolver qualquer
              problema e garantir que sua plataforma funcione sem interrupções.
            </p>
            <Button variant="outline" className="w-full" asChild>
              <Link href="/contato" className="flex items-center justify-center">
                Saiba mais <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>

      <div className="bg-gradient-to-r from-purple-900/20 to-blue-900/20 rounded-xl p-8 md:p-12 text-center">
        <h2 className="text-3xl font-bold mb-4">Pronto para começar?</h2>
        <p className="text-gray-300 mb-8 max-w-3xl mx-auto">
          Entre em contato com nossa equipe e descubra como nossas soluções podem impulsionar seu negócio de apostas
          online.
        </p>
        <Button size="lg" asChild>
          <Link href="/contato">Fale com um Especialista</Link>
        </Button>
      </div>
    </div>
  )
}
