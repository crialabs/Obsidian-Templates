import { Button } from "@/components/ui/button"
import Link from "next/link"
import Image from "next/image"

export default function AboutPage() {
  return (
    <div className="container mx-auto py-12 px-4">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold mb-4">Sobre Nós</h1>
        <p className="text-xl text-gray-400 max-w-3xl mx-auto">
          Conheça a Orbit Games e nossa missão de transformar o mercado de apostas online.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
        <div>
          <h2 className="text-3xl font-bold mb-6">Nossa História</h2>
          <p className="text-gray-300 mb-4">
            A Orbit Games tem como sua missão, entregar a melhor experiência para seu usuário final, bem como um modelo
            simples e dinâmico de gestão para operadores, para que seu negócio tenha escala.
          </p>
          <p className="text-gray-300 mb-4">
            Fundada por especialistas com mais de 10 anos de experiência no mercado digital, a Orbit Games se
            estabeleceu como líder em soluções para apostas online no Brasil, combinando tecnologia de ponta com
            estratégias de conversão comprovadas.
          </p>
          <p className="text-gray-300 mb-6">
            Nossa equipe é composta por profissionais apaixonados por inovação e comprometidos em oferecer as melhores
            soluções para nossos parceiros, garantindo resultados excepcionais e suporte contínuo.
          </p>
          <Button asChild>
            <Link href="/contato">Entre em Contato</Link>
          </Button>
        </div>
        <div className="relative h-[400px] rounded-lg overflow-hidden">
          <Image src="/placeholder.svg?height=800&width=600" alt="Equipe Orbit Games" fill className="object-cover" />
        </div>
      </div>

      <div className="bg-gray-900 rounded-lg p-8 mb-16">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold mb-4">Nossa Missão e Valores</h2>
          <p className="text-gray-400 max-w-3xl mx-auto">
            Guiamos nossas ações e decisões com base em princípios sólidos que garantem a excelência em tudo o que
            fazemos.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-gray-800 p-6 rounded-lg">
            <h3 className="text-xl font-bold mb-3 text-purple-400">Missão</h3>
            <p className="text-gray-300">
              Entregar a melhor experiência para o usuário final e um modelo simples e dinâmico de gestão para
              operadores, garantindo o crescimento sustentável do negócio.
            </p>
          </div>
          <div className="bg-gray-800 p-6 rounded-lg">
            <h3 className="text-xl font-bold mb-3 text-purple-400">Visão</h3>
            <p className="text-gray-300">
              Ser reconhecida como a principal referência em soluções para apostas online no Brasil, impulsionando a
              inovação e estabelecendo novos padrões de excelência no setor.
            </p>
          </div>
          <div className="bg-gray-800 p-6 rounded-lg">
            <h3 className="text-xl font-bold mb-3 text-purple-400">Valores</h3>
            <ul className="text-gray-300 space-y-2">
              <li>• Inovação constante</li>
              <li>• Compromisso com resultados</li>
              <li>• Parceria genuína</li>
              <li>• Excelência no atendimento</li>
              <li>• Transparência em todas as relações</li>
            </ul>
          </div>
        </div>
      </div>

      <div className="text-center">
        <h2 className="text-3xl font-bold mb-6">Junte-se a Nós</h2>
        <p className="text-gray-300 max-w-3xl mx-auto mb-8">
          Estamos sempre em busca de talentos que compartilham nossa paixão por inovação e excelência. Conheça nossas
          oportunidades e faça parte do time Orbit Games.
        </p>
        <Button asChild>
          <Link href="/trabalhe-conosco">Trabalhe Conosco</Link>
        </Button>
      </div>
    </div>
  )
}
