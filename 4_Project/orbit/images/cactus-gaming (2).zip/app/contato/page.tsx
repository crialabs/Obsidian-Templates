"use client"

import type React from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { contactInfo } from "@/data/contact-info"
import { Mail, Phone, CheckCircle } from "lucide-react"
import Image from "next/image"

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    website: "",
    message: "",
  })

  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitStatus, setSubmitStatus] = useState<"idle" | "success" | "error">("idle")
  const [errorMessage, setErrorMessage] = useState("")

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    setErrorMessage("")

    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ ...formData, type: "contact" }),
      })

      const result = await response.json()

      if (result.success) {
        setSubmitStatus("success")
        setFormData({
          name: "",
          email: "",
          phone: "",
          website: "",
          message: "",
        })
      } else {
        setSubmitStatus("error")
        setErrorMessage(result.message || "Erro ao enviar mensagem")
      }
    } catch (error) {
      setSubmitStatus("error")
      setErrorMessage("Erro de conexão. Tente novamente.")
    } finally {
      setIsSubmitting(false)
    }
  }

  if (submitStatus === "success") {
    return (
      <div className="min-h-screen flex items-center justify-center py-12 px-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="max-w-md w-full text-center"
        >
          <div className="bg-blue-950/20 border border-blue-500/20 backdrop-blur-sm rounded-lg p-8">
            <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8 text-green-400" />
            </div>
            <h2 className="text-2xl font-bold text-blue-100 mb-4">Mensagem Enviada!</h2>
            <p className="text-blue-200/70 mb-6">
              Sua mensagem foi enviada com sucesso. Nossa equipe entrará em contato em breve.
            </p>
            <Button variant="glow" onClick={() => setSubmitStatus("idle")}>
              Enviar Nova Mensagem
            </Button>
          </div>
        </motion.div>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-12 px-4">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold mb-4">Entre em Contato</h1>
        <p className="text-xl text-gray-400 max-w-3xl mx-auto">
          Sinta-se à vontade para fazer perguntas sobre suas necessidades, seus negócios ou qualquer coisa relacionada a
          jogos
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
          className="bg-blue-950/20 border border-blue-500/20 backdrop-blur-sm p-8 rounded-lg"
        >
          <h2 className="text-2xl font-bold mb-6">Envie uma Mensagem</h2>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="name" className="text-sm font-medium">
                Seu nome completo
              </Label>
              <Input
                id="name"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                placeholder="Digite seu nome completo"
                required
                className="bg-blue-900/30 border-blue-500/30 focus:border-blue-400/50"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email" className="text-sm font-medium">
                Email
              </Label>
              <Input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleInputChange}
                placeholder="seu@email.com"
                required
                className="bg-blue-900/30 border-blue-500/30 focus:border-blue-400/50"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone" className="text-sm font-medium">
                Telefone
              </Label>
              <Input
                id="phone"
                name="phone"
                value={formData.phone}
                onChange={handleInputChange}
                placeholder="(00) 00000-0000"
                className="bg-blue-900/30 border-blue-500/30 focus:border-blue-400/50"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="website" className="text-sm font-medium">
                Site atual
              </Label>
              <Input
                id="website"
                name="website"
                value={formData.website}
                onChange={handleInputChange}
                placeholder="https://seusite.com"
                className="bg-blue-900/30 border-blue-500/30 focus:border-blue-400/50"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="message" className="text-sm font-medium">
                Mensagem
              </Label>
              <Textarea
                id="message"
                name="message"
                value={formData.message}
                onChange={handleInputChange}
                placeholder="Sua mensagem..."
                rows={5}
                required
                className="bg-blue-900/30 border-blue-500/30 focus:border-blue-400/50"
              />
            </div>

            {submitStatus === "error" && (
              <div className="bg-red-500/20 border border-red-500/30 rounded-lg p-4">
                <p className="text-red-300">{errorMessage}</p>
              </div>
            )}

            <Button type="submit" variant="glow" className="w-full" disabled={isSubmitting}>
              {isSubmitting ? "Enviando..." : "Enviar Mensagem"}
            </Button>
          </form>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="bg-blue-950/20 border border-blue-500/20 backdrop-blur-sm p-8 rounded-lg"
        >
          <h2 className="text-2xl font-bold mb-6">Informações de Contato</h2>
          <div className="space-y-6">
            <div className="flex items-start gap-4">
              <div className="bg-purple-600 p-3 rounded-full">
                <Mail className="h-6 w-6" />
              </div>
              <div>
                <h3 className="font-medium text-lg">Email</h3>
                <p className="text-gray-400 mt-1">{contactInfo.email}</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="bg-purple-600 p-3 rounded-full">
                <Phone className="h-6 w-6" />
              </div>
              <div>
                <h3 className="font-medium text-lg">WhatsApp</h3>
                <p className="text-gray-400 mt-1">{contactInfo.whatsapp}</p>
              </div>
            </div>
          </div>

          <div className="mt-12">
            <h3 className="font-medium text-lg mb-4">Nossos Parceiros</h3>
            <div className="grid grid-cols-3 gap-4">
              {Array.from({ length: 6 }).map((_, index) => (
                <div key={index} className="bg-gray-800 p-4 rounded-lg flex items-center justify-center">
                  <Image
                    src={`/placeholder.svg?height=60&width=120&text=Partner${index + 1}`}
                    alt={`Partner ${index + 1}`}
                    width={120}
                    height={60}
                  />
                </div>
              ))}
            </div>
          </div>

          <div className="mt-12">
            <h3 className="font-medium text-lg mb-4">Horário de Atendimento</h3>
            <div className="space-y-2 text-gray-400">
              <p>Atendimento 24/7 via email e WhatsApp</p>
              <p>Suporte técnico disponível todos os dias</p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  )
}
