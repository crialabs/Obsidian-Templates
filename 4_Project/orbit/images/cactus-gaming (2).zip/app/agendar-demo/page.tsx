"use client"

import type React from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar, Clock, CheckCircle, User, Building, Globe, Phone, Mail } from "lucide-react"
import Link from "next/link"

export default function ScheduleDemoPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
    website: "",
    message: "",
    preferred_date: "",
    preferred_time: "",
  })

  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitStatus, setSubmitStatus] = useState<"idle" | "success" | "error">("idle")
  const [errorMessage, setErrorMessage] = useState("")

  const timeSlots = [
    "09:00",
    "09:30",
    "10:00",
    "10:30",
    "11:00",
    "11:30",
    "14:00",
    "14:30",
    "15:00",
    "15:30",
    "16:00",
    "16:30",
    "17:00",
  ]

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    setErrorMessage("")

    try {
      const response = await fetch("/api/demo", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      })

      const result = await response.json()

      if (result.success) {
        setSubmitStatus("success")
        setFormData({
          name: "",
          email: "",
          phone: "",
          company: "",
          website: "",
          message: "",
          preferred_date: "",
          preferred_time: "",
        })
      } else {
        setSubmitStatus("error")
        setErrorMessage(result.message || "Erro ao enviar solicitação")
      }
    } catch (error) {
      setSubmitStatus("error")
      setErrorMessage("Erro de conexão. Tente novamente.")
    } finally {
      setIsSubmitting(false)
    }
  }

  if (submitStatus === "success") {
    return (
      <div className="min-h-screen flex items-center justify-center py-12 px-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="max-w-md w-full"
        >
          <Card className="bg-blue-950/20 border-blue-500/20 backdrop-blur-sm text-center">
            <CardContent className="pt-6">
              <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-green-400" />
              </div>
              <h2 className="text-2xl font-bold text-blue-100 mb-4">Demo Agendada!</h2>
              <p className="text-blue-200/70 mb-6">
                Sua solicitação foi enviada com sucesso. Nossa equipe entrará em contato em breve para confirmar o
                agendamento.
              </p>
              <div className="space-y-3">
                <Button variant="glow" asChild className="w-full">
                  <Link href="/">Voltar ao Início</Link>
                </Button>
                <Button variant="outline" asChild className="w-full">
                  <Link href="/contato">Falar com Especialista</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    )
  }

  return (
    <div className="min-h-screen py-12 px-4 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 bg-gradient-to-b from-blue-950/10 to-transparent"></div>
      <div className="absolute top-1/4 right-1/4 w-[500px] h-[500px] rounded-full bg-blue-500/5 blur-[100px] animate-pulse-slow"></div>
      <div
        className="absolute bottom-1/4 left-1/4 w-[400px] h-[400px] rounded-full bg-blue-500/5 blur-[80px] animate-pulse-slow"
        style={{ animationDelay: "-2s" }}
      ></div>

      <div className="container mx-auto max-w-4xl relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            <span className="bg-gradient-to-r from-blue-400 to-blue-600 bg-clip-text text-transparent">
              Agende uma Demo
            </span>
          </h1>
          <p className="text-xl text-blue-100/80 max-w-2xl mx-auto">
            Veja como nossa plataforma pode aumentar suas conversões em até 50%. Agende uma demonstração personalizada
            com nossos especialistas.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="lg:col-span-2"
          >
            <Card className="bg-blue-950/20 border-blue-500/20 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-2xl text-blue-100">Informações da Demo</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name" className="text-blue-100 flex items-center gap-2">
                        <User className="w-4 h-4" />
                        Nome Completo *
                      </Label>
                      <Input
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        required
                        className="bg-blue-900/30 border-blue-500/30 focus:border-blue-400/50"
                        placeholder="Seu nome completo"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email" className="text-blue-100 flex items-center gap-2">
                        <Mail className="w-4 h-4" />
                        Email *
                      </Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        required
                        className="bg-blue-900/30 border-blue-500/30 focus:border-blue-400/50"
                        placeholder="seu@email.com"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="phone" className="text-blue-100 flex items-center gap-2">
                        <Phone className="w-4 h-4" />
                        Telefone
                      </Label>
                      <Input
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        className="bg-blue-900/30 border-blue-500/30 focus:border-blue-400/50"
                        placeholder="(00) 00000-0000"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="company" className="text-blue-100 flex items-center gap-2">
                        <Building className="w-4 h-4" />
                        Empresa
                      </Label>
                      <Input
                        id="company"
                        name="company"
                        value={formData.company}
                        onChange={handleInputChange}
                        className="bg-blue-900/30 border-blue-500/30 focus:border-blue-400/50"
                        placeholder="Nome da empresa"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="website" className="text-blue-100 flex items-center gap-2">
                      <Globe className="w-4 h-4" />
                      Website Atual
                    </Label>
                    <Input
                      id="website"
                      name="website"
                      value={formData.website}
                      onChange={handleInputChange}
                      className="bg-blue-900/30 border-blue-500/30 focus:border-blue-400/50"
                      placeholder="https://seusite.com"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="preferred_date" className="text-blue-100 flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        Data Preferida *
                      </Label>
                      <Input
                        id="preferred_date"
                        name="preferred_date"
                        type="date"
                        value={formData.preferred_date}
                        onChange={handleInputChange}
                        required
                        min={new Date().toISOString().split("T")[0]}
                        className="bg-blue-900/30 border-blue-500/30 focus:border-blue-400/50"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="preferred_time" className="text-blue-100 flex items-center gap-2">
                        <Clock className="w-4 h-4" />
                        Horário Preferido *
                      </Label>
                      <select
                        id="preferred_time"
                        name="preferred_time"
                        value={formData.preferred_time}
                        onChange={handleInputChange}
                        required
                        className="w-full px-3 py-2 bg-blue-900/30 border border-blue-500/30 rounded-md focus:border-blue-400/50 focus:outline-none text-white"
                      >
                        <option value="">Selecione um horário</option>
                        {timeSlots.map((time) => (
                          <option key={time} value={time}>
                            {time}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="message" className="text-blue-100">
                      Mensagem Adicional
                    </Label>
                    <Textarea
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={handleInputChange}
                      rows={4}
                      className="bg-blue-900/30 border-blue-500/30 focus:border-blue-400/50"
                      placeholder="Conte-nos mais sobre suas necessidades..."
                    />
                  </div>

                  {submitStatus === "error" && (
                    <div className="bg-red-500/20 border border-red-500/30 rounded-lg p-4">
                      <p className="text-red-300">{errorMessage}</p>
                    </div>
                  )}

                  <Button type="submit" variant="glow" className="w-full" disabled={isSubmitting}>
                    {isSubmitting ? "Enviando..." : "Agendar Demo"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="space-y-6"
          >
            <Card className="bg-blue-950/20 border-blue-500/20 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-xl text-blue-100">O que você verá na demo</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-blue-500 mt-2 flex-shrink-0"></div>
                  <div>
                    <h4 className="font-semibold text-blue-100">Plataforma Completa</h4>
                    <p className="text-blue-200/70 text-sm">Demonstração completa da nossa plataforma white label</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-blue-500 mt-2 flex-shrink-0"></div>
                  <div>
                    <h4 className="font-semibold text-blue-100">Jogos Disponíveis</h4>
                    <p className="text-blue-200/70 text-sm">Mais de 3.000 jogos dos melhores provedores</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-blue-500 mt-2 flex-shrink-0"></div>
                  <div>
                    <h4 className="font-semibold text-blue-100">Integração de API</h4>
                    <p className="text-blue-200/70 text-sm">Como integrar nossa API em sua plataforma existente</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-blue-500 mt-2 flex-shrink-0"></div>
                  <div>
                    <h4 className="font-semibold text-blue-100">Resultados Reais</h4>
                    <p className="text-blue-200/70 text-sm">Cases de sucesso e métricas de conversão</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-blue-950/20 border-blue-500/20 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-xl text-blue-100">Informações da Demo</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-blue-400" />
                  <span className="text-blue-200/70">Duração: 30-45 minutos</span>
                </div>
                <div className="flex items-center gap-3">
                  <Calendar className="w-5 h-5 text-blue-400" />
                  <span className="text-blue-200/70">Disponível: Segunda a Sexta</span>
                </div>
                <div className="flex items-center gap-3">
                  <User className="w-5 h-5 text-blue-400" />
                  <span className="text-blue-200/70">Especialista dedicado</span>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-blue-950/20 border-blue-500/20 backdrop-blur-sm">
              <CardContent className="pt-6">
                <div className="text-center">
                  <h3 className="font-bold text-blue-100 mb-2">Precisa de ajuda?</h3>
                  <p className="text-blue-200/70 text-sm mb-4">Entre em contato diretamente com nossa equipe</p>
                  <Button variant="outline" asChild className="w-full">
                    <Link href="/contato">Falar Agora</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  )
}
