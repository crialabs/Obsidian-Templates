import Hero from "@/components/hero"
import Partners from "@/components/partners"
import AboutUs from "@/components/about-us"
import ValuePropositions from "@/components/value-propositions"
import InnovativeSolutions from "@/components/innovative-solutions"
import ConversionCharts from "@/components/conversion-charts"
import Products from "@/components/products"
import Clients from "@/components/clients"
import Testimonials from "@/components/testimonials"
import ContactCta from "@/components/contact-cta"

export default function Home() {
  return (
    <div className="flex flex-col">
      <Hero />
      <Partners />
      <AboutUs />
      <ValuePropositions />
      <ConversionCharts />
      <InnovativeSolutions />
      <Products />
      <Clients />
      <Testimonials />
      <ContactCta />
    </div>
  )
}
