import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import MobileStickyCtA from "@/components/mobile-sticky-cta"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Orbit Games - Soluções para Apostas Online",
  description: "Comece seu sistema de apostas online com poucos cliques. Tenha até 50% mais conversão em seu site.",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="pt-BR">
      <body className={`${inter.className} bg-black text-white`}>
        <ThemeProvider attribute="class" defaultTheme="dark">
          <div className="flex min-h-screen flex-col">
            <Navbar />
            <main className="flex-1">{children}</main>
            <Footer />
            <MobileStickyCtA />
          </div>
        </ThemeProvider>
      </body>
    </html>
  )
}
