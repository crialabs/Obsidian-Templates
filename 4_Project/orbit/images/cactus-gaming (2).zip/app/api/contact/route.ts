import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

// Initialize Supabase client with proper error handling
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL?.replace(/['"]/g, "") || ""
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY?.replace(/['"]/g, "") || ""

if (!supabaseUrl || !supabaseKey) {
  throw new Error("Missing Supabase environment variables")
}

// Validate URL format
if (!supabaseUrl.startsWith("https://") || !supabaseUrl.includes(".supabase.co")) {
  throw new Error("Invalid Supabase URL format")
}

const supabase = createClient(supabaseUrl, supabaseKey)

// Validation schema
interface ContactFormData {
  name: string
  email: string
  phone?: string
  website?: string
  message: string
  type: "contact" | "demo"
}

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}

function validateFormData(data: any): { isValid: boolean; errors: string[] } {
  const errors: string[] = []

  if (!data.name || data.name.trim().length < 2) {
    errors.push("Nome deve ter pelo menos 2 caracteres")
  }

  if (!data.email || !validateEmail(data.email)) {
    errors.push("Email inválido")
  }

  if (!data.message || data.message.trim().length < 10) {
    errors.push("Mensagem deve ter pelo menos 10 caracteres")
  }

  if (data.phone && data.phone.length > 0 && data.phone.length < 10) {
    errors.push("Telefone deve ter pelo menos 10 dígitos")
  }

  return {
    isValid: errors.length === 0,
    errors,
  }
}

export async function POST(request: NextRequest) {
  try {
    // Log environment variables for debugging (remove in production)
    console.log("Supabase URL:", supabaseUrl)
    console.log("Supabase Key exists:", !!supabaseKey)

    const body = await request.json()

    // Validate the form data
    const validation = validateFormData(body)
    if (!validation.isValid) {
      return NextResponse.json(
        {
          success: false,
          message: "Dados inválidos",
          errors: validation.errors,
        },
        { status: 400 },
      )
    }

    // Prepare data for database
    const formData: ContactFormData = {
      name: body.name.trim(),
      email: body.email.trim().toLowerCase(),
      phone: body.phone?.trim() || null,
      website: body.website?.trim() || null,
      message: body.message.trim(),
      type: body.type || "contact",
    }

    // Insert into Supabase
    const { data, error } = await supabase
      .from("contact_submissions")
      .insert([
        {
          ...formData,
          created_at: new Date().toISOString(),
          ip_address: request.headers.get("x-forwarded-for") || "unknown",
          user_agent: request.headers.get("user-agent") || "unknown",
        },
      ])
      .select()

    if (error) {
      console.error("Supabase error:", error)
      return NextResponse.json(
        {
          success: false,
          message: "Erro interno do servidor",
        },
        { status: 500 },
      )
    }

    // Send notification email (optional - you can implement this later)
    // await sendNotificationEmail(formData)

    return NextResponse.json({
      success: true,
      message: "Mensagem enviada com sucesso! Entraremos em contato em breve.",
      data: data[0],
    })
  } catch (error) {
    console.error("API error:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Erro interno do servidor",
      },
      { status: 500 },
    )
  }
}

export async function GET() {
  return NextResponse.json({ message: "Contact API endpoint is working" }, { status: 200 })
}
