import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

// Initialize Supabase client with proper error handling
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL?.replace(/['"]/g, "") || ""
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY?.replace(/['"]/g, "") || ""

if (!supabaseUrl || !supabaseKey) {
  throw new Error("Missing Supabase environment variables")
}

// Validate URL format
if (!supabaseUrl.startsWith("https://") || !supabaseUrl.includes(".supabase.co")) {
  throw new Error("Invalid Supabase URL format")
}

const supabase = createClient(supabaseUrl, supabaseKey)

interface DemoFormData {
  name: string
  email: string
  phone?: string
  company?: string
  website?: string
  message?: string
  preferred_date: string
  preferred_time: string
}

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}

function validateDemoData(data: any): { isValid: boolean; errors: string[] } {
  const errors: string[] = []

  if (!data.name || data.name.trim().length < 2) {
    errors.push("Nome deve ter pelo menos 2 caracteres")
  }

  if (!data.email || !validateEmail(data.email)) {
    errors.push("Email inválido")
  }

  if (!data.preferred_date) {
    errors.push("Data preferida é obrigatória")
  }

  if (!data.preferred_time) {
    errors.push("Horário preferido é obrigatório")
  }

  return {
    isValid: errors.length === 0,
    errors,
  }
}

export async function POST(request: NextRequest) {
  try {
    // Log environment variables for debugging (remove in production)
    console.log("Supabase URL:", supabaseUrl)
    console.log("Supabase Key exists:", !!supabaseKey)

    const body = await request.json()

    const validation = validateDemoData(body)
    if (!validation.isValid) {
      return NextResponse.json(
        {
          success: false,
          message: "Dados inválidos",
          errors: validation.errors,
        },
        { status: 400 },
      )
    }

    const demoData: DemoFormData = {
      name: body.name.trim(),
      email: body.email.trim().toLowerCase(),
      phone: body.phone?.trim() || null,
      company: body.company?.trim() || null,
      website: body.website?.trim() || null,
      message: body.message?.trim() || null,
      preferred_date: body.preferred_date,
      preferred_time: body.preferred_time,
    }

    const { data, error } = await supabase
      .from("demo_requests")
      .insert([
        {
          ...demoData,
          status: "pending",
          created_at: new Date().toISOString(),
          ip_address: request.headers.get("x-forwarded-for") || "unknown",
          user_agent: request.headers.get("user-agent") || "unknown",
        },
      ])
      .select()

    if (error) {
      console.error("Supabase error:", error)
      return NextResponse.json(
        {
          success: false,
          message: "Erro interno do servidor",
        },
        { status: 500 },
      )
    }

    return NextResponse.json({
      success: true,
      message: "Solicitação de demo enviada com sucesso! Entraremos em contato para confirmar o agendamento.",
      data: data[0],
    })
  } catch (error) {
    console.error("API error:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Erro interno do servidor",
      },
      { status: 500 },
    )
  }
}
