import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import Image from "next/image"
import { games } from "@/data/games"

export default function ProductsPage() {
  return (
    <div className="container mx-auto py-12 px-4">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold mb-4">Nossos Produtos</h1>
        <p className="text-xl text-gray-400 max-w-3xl mx-auto">
          Os melhores produtos e serviços iGaming possíveis para garantir sua vantagem competitiva.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
        {games.map((game, index) => (
          <Card key={index} className="bg-gray-900 border-gray-800 overflow-hidden">
            <CardHeader className="p-0">
              <div className="relative h-48 w-full overflow-hidden">
                <Image
                  src={game.image || "/placeholder.svg?height=400&width=600"}
                  alt={game.name}
                  fill
                  className="object-cover transition-transform hover:scale-105"
                />
              </div>
            </CardHeader>
            <CardContent className="p-6">
              <h3 className="text-xl font-bold mb-3">{game.name}</h3>
              <p className="text-gray-400">{game.description}</p>
            </CardContent>
            <CardFooter className="p-6 pt-0">
              <Button variant="outline" className="w-full" asChild>
                <Link href={`/produtos/${game.slug}`}>Saiba mais</Link>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      <div className="bg-gray-900 rounded-lg p-8 mb-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-3xl font-bold mb-4">Integração de API</h2>
            <p className="text-gray-300 mb-6">
              Oferecemos uma solução de API robusta projetada para operadores online existentes que desejam integrar
              nossas soluções de jogos e apostas, bem como Odds Feed, em suas plataformas existentes. Para
              desenvolvimento de design personalizado, os operadores podem usar nossa solução Swarm API ou recorrer aos
              nossos códigos front-end de código aberto, disponíveis no GitHub.
            </p>
            <Button asChild>
              <Link href="/contato">Solicitar Documentação</Link>
            </Button>
          </div>
          <div className="bg-gray-800 p-6 rounded-lg">
            <pre className="text-sm text-gray-300 overflow-x-auto">
              <code>
                {`// Exemplo de integração da API
fetch('https://api.orbitgames.com/v1/games', {
  method: 'GET',
  headers: {
    'Authorization': 'Bearer YOUR_API_KEY',
    'Content-Type': 'application/json'
  }
})
.then(response => response.json())
.then(data => console.log(data))
.catch(error => console.error('Error:', error));`}
              </code>
            </pre>
          </div>
        </div>
      </div>

      <div className="text-center">
        <h2 className="text-3xl font-bold mb-6">Soluções Personalizadas</h2>
        <p className="text-gray-300 max-w-3xl mx-auto mb-8">
          Não encontrou o que procura? Entre em contato conosco para discutir soluções personalizadas para seu negócio.
        </p>
        <Button asChild>
          <Link href="/contato">Entre em Contato</Link>
        </Button>
      </div>
    </div>
  )
}
