import { BlogCard } from "@/components/blog-card"
import { blogPosts } from "@/data/blog-posts"

export default function BlogPage() {
  return (
    <div className="container mx-auto py-12 px-4">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold mb-4">Blog</h1>
        <p className="text-xl text-gray-400 max-w-3xl mx-auto">
          Fique por dentro das últimas notícias, dicas e análises do mundo dos games.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {blogPosts.map((post) => (
          <BlogCard key={post.id} post={post} />
        ))}
      </div>
    </div>
  )
}
