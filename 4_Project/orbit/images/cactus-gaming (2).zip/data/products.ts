import type { Product } from "@/types/product"

export const products: Product[] = [
  {
    id: "1",
    name: "Cyberpunk 2077",
    description:
      "Um RPG de ação e aventura em mundo aberto que se passa em Night City, uma megalópole obcecada por poder, glamour e modificações corporais.",
    price: "R$ 199,90",
    category: "Jogos",
    isNew: true,
    rating: 4.5,
    stock: 50,
  },
  {
    id: "2",
    name: "Headset Gamer RGB",
    description:
      "Headset gamer com iluminação RGB, som surround 7.1 e microfone com cancelamento de ruído para uma experiência imersiva.",
    price: "R$ 299,90",
    category: "Acessórios",
    rating: 4.8,
    stock: 30,
  },
  {
    id: "3",
    name: "PlayStation 5",
    description:
      "Console de última geração com gráficos impressionantes, carregamento ultra-rápido e controle DualSense com feedback háptico.",
    price: "R$ 4.499,90",
    category: "Consoles",
    rating: 5.0,
    stock: 10,
  },
  {
    id: "4",
    name: "The Legend of Zelda: Tears of the Kingdom",
    description:
      "A sequência de Breath of the Wild leva você a uma jornada épica através de Hyrule e além, com novas habilidades e mistérios para desvendar.",
    price: "R$ 349,90",
    category: "Jogos",
    rating: 4.9,
    stock: 25,
  },
  {
    id: "5",
    name: "Mouse Gamer 16000 DPI",
    description:
      "Mouse gamer de alta precisão com 8 botões programáveis, iluminação RGB personalizável e sensor óptico avançado.",
    price: "R$ 249,90",
    category: "Acessórios",
    isNew: true,
    rating: 4.7,
    stock: 40,
  },
  {
    id: "6",
    name: "Xbox Series X",
    description:
      "O console Xbox mais rápido e poderoso de todos os tempos, com gráficos em 4K e taxas de quadros de até 120 FPS.",
    price: "R$ 4.349,90",
    category: "Consoles",
    rating: 4.8,
    stock: 15,
  },
]
