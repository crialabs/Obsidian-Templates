import { Instagram, Twitter, Youtube } from "lucide-react"

export const socialLinks = [
  {
    name: "Instagram",
    href: "https://instagram.com",
    icon: Instagram,
  },
  {
    name: "Twitter",
    href: "https://twitter.com",
    icon: Twitter,
  },
  {
    name: "Youtube",
    href: "https://youtube.com",
    icon: Youtube,
  },
]
