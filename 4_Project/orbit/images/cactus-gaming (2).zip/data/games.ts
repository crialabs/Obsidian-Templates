export const games = [
  {
    name: "Mines",
    slug: "mines",
    description: "Jogo de estratégia onde os jogadores devem evitar as minas escondidas para ganhar prêmios.",
    image: "",
  },
  {
    name: "Aviator",
    slug: "aviator",
    description: "Jogo de crash onde um avião decola e os jogadores devem sacar antes que ele voe para longe.",
    image: "",
  },
  {
    name: "Boom City",
    slug: "boom-city",
    description: "Jogo de dados com multiplicadores e bônus emocionantes para grandes ganhos.",
    image: "",
  },
  {
    name: "Fan Tan",
    slug: "fan-tan",
    description: "Jogo de mesa tradicional asiático com apostas simples e emocionantes.",
    image: "",
  },
  {
    name: "Fortune Tiger",
    slug: "fortune-tiger",
    description: "Caça-níquel temático com símbolos de tigre e sorte inspirados na cultura asiática.",
    image: "",
  },
  {
    name: "Infinite Blackjack",
    slug: "infinite-blackjack",
    description: "Versão do blackjack clássico que permite um número ilimitado de jogadores na mesma mesa.",
    image: "",
  },
  {
    name: "Mega Wheel",
    slug: "mega-wheel",
    description: "Jogo de roda da fortuna com grandes multiplicadores e prêmios.",
    image: "",
  },
  {
    name: "Spaceman",
    slug: "spaceman",
    description:
      "Jogo de crash onde um astronauta voa pelo espaço e os jogadores devem sacar antes que ele desapareça.",
    image: "",
  },
  {
    name: "Super Rainbow Megaways",
    slug: "super-rainbow-megaways",
    description: "Caça-níquel com mecânica Megaways e tema colorido de arco-íris para ganhos massivos.",
    image: "",
  },
]
