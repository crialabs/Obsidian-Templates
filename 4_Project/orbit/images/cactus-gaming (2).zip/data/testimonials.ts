export const testimonials = [
  {
    name: "Talita Lacerda",
    title: "COO 7K.BET",
    text: "A parceria entre a 7K.BET e a Orbit Games tem sido fundamental para o sucesso do negócio, evidenciando a importância de escolher parceiros adequados no mercado brasileiro de apostas esportivas e cassinos online. A Orbit Games se destaca por suas soluções práticas, suporte eficaz e excelente atendimento. Como COO da 7K.BET, posso afirmar com convicção que a Orbit Games é uma empresa de confiança e altamente recomendável.",
    avatar: "",
  },
]
