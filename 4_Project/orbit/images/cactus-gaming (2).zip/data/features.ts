import { Gamepad2, ShieldCheck, Zap, Users, Gift, HeadsetIcon } from "lucide-react"

export const features = [
  {
    title: "Produtos Premium",
    description: "Oferecemos apenas produtos de alta qualidade das melhores marcas do mercado, com garantia estendida.",
    icon: Gamepad2,
  },
  {
    title: "Entrega Rápida",
    description: "Receba seus produtos em tempo recorde com nossa logística otimizada para todo o Brasil.",
    icon: Zap,
  },
  {
    title: "Suporte 24/7",
    description: "Nossa equipe de suporte está disponível 24 horas por dia, 7 dias por semana para ajudar você.",
    icon: HeadsetIcon,
  },
  {
    title: "Comunidade Ativa",
    description: "Faça parte de uma comunidade de gamers apaixonados, com eventos e torneios exclusivos.",
    icon: Users,
  },
  {
    title: "Programa de Fidelidade",
    description: "Acumule pontos em suas compras e troque por descontos e produtos exclusivos.",
    icon: Gift,
  },
  {
    title: "Compra Segura",
    description: "Transações protegidas e garantia de satisfação em todas as suas compras.",
    icon: ShieldCheck,
  },
]
