export const contactInfo = {
  email: "business@orbitgames.net",
  whatsapp: "(031) 99134-3862",
}
