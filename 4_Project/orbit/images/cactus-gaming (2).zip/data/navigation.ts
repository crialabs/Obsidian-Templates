export const navigationLinks = [
  {
    label: "Início",
    href: "/",
  },
  {
    label: "Sobre Nós",
    href: "/sobre",
  },
  {
    label: "Soluções",
    href: "/solucoes",
  },
  {
    label: "Produtos",
    href: "/produtos",
  },
  {
    label: "Calculadora ROI",
    href: "/calculadora-roi",
  },
  {
    label: "Agendar Demo",
    href: "/agendar-demo",
  },
  {
    label: "Contato",
    href: "/contato",
  },
]
