import type { BlogPost } from "@/types/blog-post"

export const blogPosts: BlogPost[] = [
  {
    id: "1",
    title: "Os 10 jogos mais aguardados de 2025",
    slug: "jogos-mais-aguardados-2025",
    excerpt:
      "Confira nossa lista com os lançamentos mais esperados para o próximo ano, incluindo sequências de franquias amadas e novas IPs promissoras.",
    content:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nisl vel ultricies lacinia, nisl nisl aliquam nisl, eu aliquam nisl nisl eu nisl. Sed euismod, nisl vel ultricies lacinia, nisl nisl aliquam nisl, eu aliquam nisl nisl eu nisl.",
    date: "10 Mai 2025",
    author: "Carlos Silva",
    category: "Lançamentos",
    readTime: 8,
    featured: true,
  },
  {
    id: "2",
    title: "Guia completo: Como montar seu PC Gamer em 2025",
    slug: "guia-montar-pc-gamer-2025",
    excerpt:
      "Aprenda a escolher os melhores componentes para montar um PC gamer de alto desempenho sem gastar uma fortuna.",
    content:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nisl vel ultricies lacinia, nisl nisl aliquam nisl, eu aliquam nisl nisl eu nisl. Sed euismod, nisl vel ultricies lacinia, nisl nisl aliquam nisl, eu aliquam nisl nisl eu nisl.",
    date: "05 Mai 2025",
    author: "Ana Rodrigues",
    category: "Hardware",
    readTime: 12,
  },
  {
    id: "3",
    title: "Análise: O impacto da IA nos jogos modernos",
    slug: "impacto-ia-jogos-modernos",
    excerpt:
      "Como a inteligência artificial está revolucionando a indústria de jogos, desde NPCs mais realistas até experiências personalizadas.",
    content:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nisl vel ultricies lacinia, nisl nisl aliquam nisl, eu aliquam nisl nisl eu nisl. Sed euismod, nisl vel ultricies lacinia, nisl nisl aliquam nisl, eu aliquam nisl nisl eu nisl.",
    date: "28 Abr 2025",
    author: "Marcos Oliveira",
    category: "Tecnologia",
    readTime: 10,
  },
  {
    id: "4",
    title: "E-sports: Os maiores campeonatos de 2025",
    slug: "maiores-campeonatos-esports-2025",
    excerpt:
      "Calendário completo com os principais torneios de e-sports do ano, premiações e como assistir às transmissões ao vivo.",
    content:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nisl vel ultricies lacinia, nisl nisl aliquam nisl, eu aliquam nisl nisl eu nisl. Sed euismod, nisl vel ultricies lacinia, nisl nisl aliquam nisl, eu aliquam nisl nisl eu nisl.",
    date: "20 Abr 2025",
    author: "Juliana Costa",
    category: "E-sports",
    readTime: 7,
  },
  {
    id: "5",
    title: "Retrospectiva: Os jogos que definiram a última década",
    slug: "jogos-que-definiram-ultima-decada",
    excerpt:
      "Uma análise dos títulos que revolucionaram a indústria de games nos últimos dez anos e seu legado para as novas gerações.",
    content:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nisl vel ultricies lacinia, nisl nisl aliquam nisl, eu aliquam nisl nisl eu nisl. Sed euismod, nisl vel ultricies lacinia, nisl nisl aliquam nisl, eu aliquam nisl nisl eu nisl.",
    date: "15 Abr 2025",
    author: "Ricardo Mendes",
    category: "História",
    readTime: 15,
    featured: true,
  },
  {
    id: "6",
    title: "Realidade Virtual: O futuro dos jogos imersivos",
    slug: "realidade-virtual-futuro-jogos-imersivos",
    excerpt:
      "Como a tecnologia VR está evoluindo e quais são as tendências para os próximos anos no mundo dos jogos de realidade virtual.",
    content:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nisl vel ultricies lacinia, nisl nisl aliquam nisl, eu aliquam nisl nisl eu nisl. Sed euismod, nisl vel ultricies lacinia, nisl nisl aliquam nisl, eu aliquam nisl nisl eu nisl.",
    date: "10 Abr 2025",
    author: "Fernanda Lima",
    category: "Tecnologia",
    readTime: 9,
  },
]
