const AboutUs = () => {
  return (
    <section className="py-12 bg-gray-100">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-semibold text-gray-800 text-center mb-8">
          Orbit Gaming: Sua Vantagem Competitiva no Mercado de Apostas
        </h2>
        <div className="max-w-3xl mx-auto text-lg text-gray-700 leading-relaxed">
          <p className="mb-6">
            Nossa missão é impulsionar o mercado de apostas online com soluções tecnológicas rápidas, estáveis e
            altamente lucrativas. Acreditamos que a agilidade é sua maior vantagem competitiva e que a performance é o
            nosso padrão.
          </p>
          <ul className="list-disc list-inside mb-6">
            <li>
              <strong>Soluções tecnológicas rápidas</strong>
            </li>
            <li>
              <strong>Estabilidade garantida</strong>
            </li>
            <li>
              <strong>Alta lucratividade</strong>
            </li>
            <li>
              <strong>Agilidade como vantagem competitiva</strong>
            </li>
          </ul>
        </div>
      </div>
    </section>
  )
}

export default AboutUs
