"use client"

import { useState, useEffect, useRef } from "react"
import { motion, useScroll, useTransform, AnimatePresence } from "framer-motion"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowRight, HelpCircle, DollarSign, Users, TrendingUp, BarChart3 } from "lucide-react"
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  type ChartData,
} from "chart.js"
import { Bar, Doughnut } from "react-chartjs-2"
import Link from "next/link"

// Register ChartJS components
ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ArcElement)

export default function RoiCalculator() {
  const sectionRef = useRef<HTMLElement>(null)
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start end", "end start"],
  })

  const y = useTransform(scrollYProgress, [0, 1], [50, -50])

  // Calculator state
  const [monthlyVisitors, setMonthlyVisitors] = useState(10000)
  const [currentConversionRate, setCurrentConversionRate] = useState(2)
  const [averageOrderValue, setAverageOrderValue] = useState(100)
  const [marketingCost, setMarketingCost] = useState(5000)
  const [timeframe, setTimeframe] = useState("monthly")
  const [activeTab, setActiveTab] = useState("calculator")

  // Calculated values
  const [currentResults, setCurrentResults] = useState({
    conversions: 0,
    revenue: 0,
    roi: 0,
  })

  const [orbitResults, setOrbitResults] = useState({
    conversions: 0,
    revenue: 0,
    roi: 0,
    additionalRevenue: 0,
    additionalConversions: 0,
    improvementPercentage: 0,
  })

  // Calculate results
  useEffect(() => {
    // Current setup calculations
    const currentConversions = (monthlyVisitors * currentConversionRate) / 100
    const currentRevenue = currentConversions * averageOrderValue
    const currentRoi = ((currentRevenue - marketingCost) / marketingCost) * 100

    setCurrentResults({
      conversions: currentConversions,
      revenue: currentRevenue,
      roi: currentRoi,
    })

    // Orbit Games calculations (50% better conversion rate)
    const orbitConversionRate = currentConversionRate * 1.5
    const orbitConversions = (monthlyVisitors * orbitConversionRate) / 100
    const orbitRevenue = orbitConversions * averageOrderValue
    const orbitRoi = ((orbitRevenue - marketingCost) / marketingCost) * 100

    setOrbitResults({
      conversions: orbitConversions,
      revenue: orbitRevenue,
      roi: orbitRoi,
      additionalRevenue: orbitRevenue - currentRevenue,
      additionalConversions: orbitConversions - currentConversions,
      improvementPercentage: ((orbitRevenue - currentRevenue) / currentRevenue) * 100,
    })
  }, [monthlyVisitors, currentConversionRate, averageOrderValue, marketingCost])

  // Time multiplier for annual view
  const timeMultiplier = timeframe === "annual" ? 12 : 1

  // Chart data
  const barChartData: ChartData<"bar"> = {
    labels: ["Conversões", "Receita (R$)", "ROI (%)"],
    datasets: [
      {
        label: "Sistema Atual",
        data: [
          currentResults.conversions * timeMultiplier,
          currentResults.revenue * timeMultiplier,
          currentResults.roi,
        ],
        backgroundColor: "rgba(99, 102, 241, 0.4)",
        borderColor: "rgba(99, 102, 241, 0.6)",
        borderWidth: 1,
        borderRadius: 5,
      },
      {
        label: "Com Orbit Games",
        data: [orbitResults.conversions * timeMultiplier, orbitResults.revenue * timeMultiplier, orbitResults.roi],
        backgroundColor: "rgba(59, 130, 246, 0.8)",
        borderColor: "rgba(59, 130, 246, 1)",
        borderWidth: 1,
        borderRadius: 5,
      },
    ],
  }

  const doughnutData: ChartData<"doughnut"> = {
    labels: ["Sistema Atual", "Ganho Adicional com Orbit Games"],
    datasets: [
      {
        data: [currentResults.revenue * timeMultiplier, orbitResults.additionalRevenue * timeMultiplier],
        backgroundColor: ["rgba(99, 102, 241, 0.4)", "rgba(59, 130, 246, 0.8)"],
        borderColor: ["rgba(99, 102, 241, 0.6)", "rgba(59, 130, 246, 1)"],
        borderWidth: 1,
        hoverOffset: 4,
      },
    ],
  }

  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
      maximumFractionDigits: 0,
    }).format(value)
  }

  return (
    <section ref={sectionRef} className="py-24 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 bg-gradient-to-b from-blue-950/10 to-transparent"></div>
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-blue-500/20 to-transparent"></div>
      <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-blue-500/20 to-transparent"></div>

      <motion.div
        style={{ y }}
        className="absolute -left-64 top-1/3 w-[600px] h-[600px] rounded-full border border-blue-500/10 opacity-30"
      ></motion.div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <div className="inline-block">
            <div className="relative">
              <div className="absolute -inset-1 bg-blue-500/10 rounded-lg blur-xl"></div>
              <h2 className="text-4xl font-bold mb-4 relative">
                <span className="bg-gradient-to-r from-blue-400 to-blue-600 bg-clip-text text-transparent">
                  Calcule seu ROI
                </span>
              </h2>
            </div>
          </div>
          <p className="text-blue-100/80 max-w-2xl mx-auto mt-4">
            Descubra quanto sua empresa pode ganhar ao utilizar as soluções da Orbit Games. Nossa tecnologia proporciona
            até 50% mais conversão comparado aos sistemas convencionais.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="relative"
        >
          <div className="absolute -inset-4 bg-blue-500/5 rounded-3xl blur-xl"></div>
          <Card className="bg-blue-950/20 border-blue-500/20 backdrop-blur-sm overflow-hidden relative">
            <div className="absolute inset-0 bg-gradient-to-br from-blue-600/5 to-blue-900/5 rounded-lg"></div>

            <CardHeader className="relative">
              <Tabs defaultValue="calculator" className="w-full" onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-2 bg-blue-900/30">
                  <TabsTrigger value="calculator" className="data-[state=active]:bg-blue-800/50">
                    Calculadora
                  </TabsTrigger>
                  <TabsTrigger value="results" className="data-[state=active]:bg-blue-800/50">
                    Resultados
                  </TabsTrigger>
                </TabsList>
              </Tabs>
            </CardHeader>

            <CardContent className="relative">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <AnimatePresence mode="wait">
                  {activeTab === "calculator" ? (
                    <motion.div
                      key="calculator"
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      transition={{ duration: 0.3 }}
                      className="space-y-6"
                    >
                      <div className="space-y-4">
                        <div className="flex justify-between items-center">
                          <div className="flex items-center gap-2">
                            <Users className="h-5 w-5 text-blue-400" />
                            <Label htmlFor="visitors" className="text-blue-100">
                              Visitantes Mensais
                            </Label>
                          </div>
                          <div className="w-24">
                            <Input
                              id="visitors"
                              type="number"
                              value={monthlyVisitors}
                              onChange={(e) => setMonthlyVisitors(Number.parseInt(e.target.value) || 0)}
                              className="bg-blue-900/30 border-blue-500/30 text-right"
                            />
                          </div>
                        </div>
                        <Slider
                          value={[monthlyVisitors]}
                          min={1000}
                          max={100000}
                          step={1000}
                          onValueChange={(value) => setMonthlyVisitors(value[0])}
                          className="py-4"
                        />
                      </div>

                      <div className="space-y-4">
                        <div className="flex justify-between items-center">
                          <div className="flex items-center gap-2">
                            <TrendingUp className="h-5 w-5 text-blue-400" />
                            <Label htmlFor="conversion" className="text-blue-100">
                              Taxa de Conversão Atual (%)
                            </Label>
                          </div>
                          <div className="w-24">
                            <Input
                              id="conversion"
                              type="number"
                              value={currentConversionRate}
                              onChange={(e) => setCurrentConversionRate(Number.parseFloat(e.target.value) || 0)}
                              className="bg-blue-900/30 border-blue-500/30 text-right"
                              step={0.1}
                            />
                          </div>
                        </div>
                        <Slider
                          value={[currentConversionRate]}
                          min={0.1}
                          max={10}
                          step={0.1}
                          onValueChange={(value) => setCurrentConversionRate(value[0])}
                          className="py-4"
                        />
                      </div>

                      <div className="space-y-4">
                        <div className="flex justify-between items-center">
                          <div className="flex items-center gap-2">
                            <DollarSign className="h-5 w-5 text-blue-400" />
                            <Label htmlFor="aov" className="text-blue-100">
                              Valor Médio por Cliente (R$)
                            </Label>
                          </div>
                          <div className="w-24">
                            <Input
                              id="aov"
                              type="number"
                              value={averageOrderValue}
                              onChange={(e) => setAverageOrderValue(Number.parseInt(e.target.value) || 0)}
                              className="bg-blue-900/30 border-blue-500/30 text-right"
                            />
                          </div>
                        </div>
                        <Slider
                          value={[averageOrderValue]}
                          min={10}
                          max={1000}
                          step={10}
                          onValueChange={(value) => setAverageOrderValue(value[0])}
                          className="py-4"
                        />
                      </div>

                      <div className="space-y-4">
                        <div className="flex justify-between items-center">
                          <div className="flex items-center gap-2">
                            <BarChart3 className="h-5 w-5 text-blue-400" />
                            <Label htmlFor="marketing" className="text-blue-100">
                              Custo de Marketing Mensal (R$)
                            </Label>
                          </div>
                          <div className="w-24">
                            <Input
                              id="marketing"
                              type="number"
                              value={marketingCost}
                              onChange={(e) => setMarketingCost(Number.parseInt(e.target.value) || 0)}
                              className="bg-blue-900/30 border-blue-500/30 text-right"
                            />
                          </div>
                        </div>
                        <Slider
                          value={[marketingCost]}
                          min={1000}
                          max={50000}
                          step={1000}
                          onValueChange={(value) => setMarketingCost(value[0])}
                          className="py-4"
                        />
                      </div>

                      <div className="pt-4">
                        <div className="flex justify-between items-center">
                          <Label className="text-blue-100">Período de Análise</Label>
                          <div className="flex bg-blue-900/30 rounded-md p-1">
                            <button
                              className={`px-3 py-1 rounded-md text-sm ${
                                timeframe === "monthly" ? "bg-blue-600 text-white" : "text-blue-200 hover:text-white"
                              }`}
                              onClick={() => setTimeframe("monthly")}
                            >
                              Mensal
                            </button>
                            <button
                              className={`px-3 py-1 rounded-md text-sm ${
                                timeframe === "annual" ? "bg-blue-600 text-white" : "text-blue-200 hover:text-white"
                              }`}
                              onClick={() => setTimeframe("annual")}
                            >
                              Anual
                            </button>
                          </div>
                        </div>
                      </div>

                      <div className="pt-4">
                        <Button variant="glow" className="w-full" onClick={() => setActiveTab("results")}>
                          Calcular ROI <ArrowRight className="ml-2 h-4 w-4" />
                        </Button>
                      </div>
                    </motion.div>
                  ) : (
                    <motion.div
                      key="results"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 20 }}
                      transition={{ duration: 0.3 }}
                      className="space-y-6"
                    >
                      <div className="bg-blue-900/30 rounded-lg p-4 border border-blue-500/20">
                        <h3 className="text-lg font-bold text-blue-100 mb-4">Resumo dos Resultados</h3>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div className="bg-blue-800/30 p-4 rounded-lg text-center">
                            <p className="text-blue-200 text-sm mb-1">Conversões Adicionais</p>
                            <p className="text-2xl font-bold text-blue-100">
                              {Math.round(orbitResults.additionalConversions * timeMultiplier)}
                            </p>
                          </div>
                          <div className="bg-blue-800/30 p-4 rounded-lg text-center">
                            <p className="text-blue-200 text-sm mb-1">Receita Adicional</p>
                            <p className="text-2xl font-bold text-blue-100">
                              {formatCurrency(orbitResults.additionalRevenue * timeMultiplier)}
                            </p>
                          </div>
                          <div className="bg-blue-800/30 p-4 rounded-lg text-center">
                            <p className="text-blue-200 text-sm mb-1">Melhoria no ROI</p>
                            <p className="text-2xl font-bold text-blue-100">
                              {Math.round(orbitResults.roi - currentResults.roi)}%
                            </p>
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="bg-blue-900/30 rounded-lg p-4 border border-blue-500/20">
                          <h4 className="text-md font-bold text-blue-100 mb-4">Comparativo de Desempenho</h4>
                          <div className="h-[250px]">
                            <Bar
                              data={barChartData}
                              options={{
                                responsive: true,
                                maintainAspectRatio: false,
                                scales: {
                                  y: {
                                    beginAtZero: true,
                                    grid: {
                                      color: "rgba(71, 85, 105, 0.1)",
                                    },
                                    ticks: {
                                      color: "rgba(148, 163, 184, 0.8)",
                                    },
                                  },
                                  x: {
                                    grid: {
                                      color: "rgba(71, 85, 105, 0.1)",
                                    },
                                    ticks: {
                                      color: "rgba(148, 163, 184, 0.8)",
                                    },
                                  },
                                },
                                plugins: {
                                  legend: {
                                    position: "top",
                                    labels: {
                                      color: "rgba(148, 163, 184, 1)",
                                      font: {
                                        size: 11,
                                      },
                                    },
                                  },
                                  tooltip: {
                                    backgroundColor: "rgba(15, 23, 42, 0.8)",
                                    titleColor: "rgba(255, 255, 255, 1)",
                                    bodyColor: "rgba(203, 213, 225, 1)",
                                    borderColor: "rgba(59, 130, 246, 0.3)",
                                    borderWidth: 1,
                                  },
                                },
                              }}
                            />
                          </div>
                        </div>

                        <div className="bg-blue-900/30 rounded-lg p-4 border border-blue-500/20">
                          <h4 className="text-md font-bold text-blue-100 mb-4">Distribuição de Receita</h4>
                          <div className="h-[250px] flex items-center justify-center">
                            <Doughnut
                              data={doughnutData}
                              options={{
                                responsive: true,
                                maintainAspectRatio: false,
                                plugins: {
                                  legend: {
                                    position: "bottom",
                                    labels: {
                                      color: "rgba(148, 163, 184, 1)",
                                      font: {
                                        size: 11,
                                      },
                                    },
                                  },
                                  tooltip: {
                                    backgroundColor: "rgba(15, 23, 42, 0.8)",
                                    titleColor: "rgba(255, 255, 255, 1)",
                                    bodyColor: "rgba(203, 213, 225, 1)",
                                    borderColor: "rgba(59, 130, 246, 0.3)",
                                    borderWidth: 1,
                                    callbacks: {
                                      label: (context) => {
                                        const value = context.raw as number
                                        return `${context.label}: ${formatCurrency(value)}`
                                      },
                                    },
                                  },
                                },
                              }}
                            />
                          </div>
                        </div>
                      </div>

                      <div className="bg-blue-900/30 rounded-lg p-4 border border-blue-500/20">
                        <h3 className="text-lg font-bold text-blue-100 mb-4">Análise Detalhada</h3>
                        <div className="space-y-3">
                          <div className="flex justify-between">
                            <span className="text-blue-200">
                              Visitantes {timeframe === "annual" ? "Anuais" : "Mensais"}
                            </span>
                            <span className="text-blue-100 font-medium">
                              {monthlyVisitors * (timeframe === "annual" ? 12 : 1).toLocaleString()}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-blue-200">Taxa de Conversão Atual</span>
                            <span className="text-blue-100 font-medium">{currentConversionRate}%</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-blue-200">Taxa de Conversão com Orbit Games</span>
                            <span className="text-blue-100 font-medium">
                              {(currentConversionRate * 1.5).toFixed(1)}%
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-blue-200">Valor Médio por Cliente</span>
                            <span className="text-blue-100 font-medium">{formatCurrency(averageOrderValue)}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-blue-200">
                              Custo de Marketing {timeframe === "annual" ? "Anual" : "Mensal"}
                            </span>
                            <span className="text-blue-100 font-medium">
                              {formatCurrency(marketingCost * (timeframe === "annual" ? 12 : 1))}
                            </span>
                          </div>
                          <div className="border-t border-blue-500/20 my-2 pt-2"></div>
                          <div className="flex justify-between">
                            <span className="text-blue-200">Conversões Atuais</span>
                            <span className="text-blue-100 font-medium">
                              {Math.round(currentResults.conversions * timeMultiplier)}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-blue-200">Conversões com Orbit Games</span>
                            <span className="text-blue-100 font-medium">
                              {Math.round(orbitResults.conversions * timeMultiplier)}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-blue-200">Receita Atual</span>
                            <span className="text-blue-100 font-medium">
                              {formatCurrency(currentResults.revenue * timeMultiplier)}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-blue-200">Receita com Orbit Games</span>
                            <span className="text-blue-100 font-medium">
                              {formatCurrency(orbitResults.revenue * timeMultiplier)}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-blue-200">ROI Atual</span>
                            <span className="text-blue-100 font-medium">{Math.round(currentResults.roi)}%</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-blue-200">ROI com Orbit Games</span>
                            <span className="text-blue-100 font-medium">{Math.round(orbitResults.roi)}%</span>
                          </div>
                        </div>
                      </div>

                      <div className="pt-4 flex flex-col sm:flex-row gap-4">
                        <Button variant="outline" className="flex-1" onClick={() => setActiveTab("calculator")}>
                          Voltar à Calculadora
                        </Button>
                        <Button variant="glow" className="flex-1" asChild>
                          <Link href="/contato">Fale com um Especialista</Link>
                        </Button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                <div className="hidden lg:block">
                  <div className="bg-blue-900/30 rounded-lg p-6 border border-blue-500/20 h-full">
                    <div className="flex items-start gap-2 mb-6">
                      <HelpCircle className="h-5 w-5 text-blue-400 mt-0.5 flex-shrink-0" />
                      <div>
                        <h3 className="text-lg font-bold text-blue-100 mb-2">Como funciona?</h3>
                        <p className="text-blue-200/70 text-sm">
                          Esta calculadora demonstra o impacto financeiro que as soluções da Orbit Games podem ter em
                          seu negócio de apostas online.
                        </p>
                      </div>
                    </div>

                    <div className="space-y-6">
                      <div>
                        <h4 className="text-md font-bold text-blue-100 mb-2">Aumento de Conversão</h4>
                        <p className="text-blue-200/70 text-sm">
                          Nosso sistema proporciona até 50% mais conversão comparado aos sistemas convencionais, o que
                          significa mais clientes e mais receita para o seu negócio.
                        </p>
                      </div>

                      <div>
                        <h4 className="text-md font-bold text-blue-100 mb-2">Retorno sobre Investimento</h4>
                        <p className="text-blue-200/70 text-sm">
                          Com taxas de conversão mais altas, seu ROI aumenta significativamente, maximizando o retorno
                          de cada real investido em marketing.
                        </p>
                      </div>

                      <div>
                        <h4 className="text-md font-bold text-blue-100 mb-2">Resultados Comprovados</h4>
                        <p className="text-blue-200/70 text-sm">
                          Nossos clientes experimentam um aumento médio de 50% nas taxas de conversão após implementar
                          nossas soluções, resultando em crescimento substancial de receita.
                        </p>
                      </div>

                      <div className="pt-4">
                        <div className="bg-blue-800/30 p-4 rounded-lg">
                          <p className="text-blue-100 text-sm italic">
                            "A parceria com a Orbit Games aumentou nossa taxa de conversão em mais de 50%, resultando em
                            um crescimento significativo de receita."
                          </p>
                          <p className="text-blue-300/70 text-xs mt-2">— Talita Lacerda, COO 7K.BET</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>

            {/* Glowing dots */}
            <div className="absolute top-4 right-4 w-2 h-2 rounded-full bg-blue-500 glow-sm"></div>
            <div className="absolute bottom-4 left-4 w-2 h-2 rounded-full bg-blue-500 glow-sm"></div>
          </Card>
        </motion.div>
      </div>
    </section>
  )
}
