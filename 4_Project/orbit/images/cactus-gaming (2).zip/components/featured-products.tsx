const FeaturedProducts = () => {
  return (
    <div className="bg-gray-100 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            Orbit Gaming Dashboard: Seus Jogos Mais Quentes em um Só Lugar
          </h2>
          <p className="mt-3 max-w-2xl mx-auto text-xl text-gray-500 sm:mt-4">
            Descubra os slots que estão bombando na nossa plataforma. Experiência premium com os melhores provedores do
            mercado, turbinando o engajamento dos seus jogadores.
          </p>
        </div>

        <div className="mt-6 grid grid-cols-1 gap-y-10 gap-x-6 sm:grid-cols-2 lg:grid-cols-4 xl:gap-x-8">
          {/* Sample Product Card - Repeat for each product */}
          <div className="group relative">
            <div className="w-full min-h-80 bg-gray-200 aspect-w-1 aspect-h-1 rounded-md overflow-hidden group-hover:opacity-75 lg:h-80 lg:aspect-none">
              <img
                src="https://via.placeholder.com/400x300"
                alt="Sample Game"
                className="w-full h-full object-center object-cover lg:w-full lg:h-full"
              />
            </div>
            <div className="mt-4 flex justify-between">
              <div>
                <h3 className="text-sm text-gray-700">
                  <a href="#">
                    <span aria-hidden="true" className="absolute inset-0" />
                    Sample Game Title
                  </a>
                </h3>
                <p className="mt-1 text-sm text-gray-500">Provider Name</p>
              </div>
              <div className="flex flex-col items-end">
                <span className="bg-green-500 text-white text-xs font-semibold py-0.5 px-2 rounded-full mb-1">
                  TRENDING
                </span>
                <span className="bg-purple-500 text-white text-xs font-semibold py-0.5 px-2 rounded-full">POPULAR</span>
              </div>
            </div>
          </div>
          {/* End Sample Product Card */}

          {/* Repeat the above card structure for other featured products */}
          <div className="group relative">
            <div className="w-full min-h-80 bg-gray-200 aspect-w-1 aspect-h-1 rounded-md overflow-hidden group-hover:opacity-75 lg:h-80 lg:aspect-none">
              <img
                src="https://via.placeholder.com/400x300"
                alt="Sample Game"
                className="w-full h-full object-center object-cover lg:w-full lg:h-full"
              />
            </div>
            <div className="mt-4 flex justify-between">
              <div>
                <h3 className="text-sm text-gray-700">
                  <a href="#">
                    <span aria-hidden="true" className="absolute inset-0" />
                    Sample Game Title
                  </a>
                </h3>
                <p className="mt-1 text-sm text-gray-500">Provider Name</p>
              </div>
              <div className="flex flex-col items-end">
                <span className="bg-green-500 text-white text-xs font-semibold py-0.5 px-2 rounded-full mb-1">
                  TRENDING
                </span>
                <span className="bg-purple-500 text-white text-xs font-semibold py-0.5 px-2 rounded-full">POPULAR</span>
              </div>
            </div>
          </div>

          <div className="group relative">
            <div className="w-full min-h-80 bg-gray-200 aspect-w-1 aspect-h-1 rounded-md overflow-hidden group-hover:opacity-75 lg:h-80 lg:aspect-none">
              <img
                src="https://via.placeholder.com/400x300"
                alt="Sample Game"
                className="w-full h-full object-center object-cover lg:w-full lg:h-full"
              />
            </div>
            <div className="mt-4 flex justify-between">
              <div>
                <h3 className="text-sm text-gray-700">
                  <a href="#">
                    <span aria-hidden="true" className="absolute inset-0" />
                    Sample Game Title
                  </a>
                </h3>
                <p className="mt-1 text-sm text-gray-500">Provider Name</p>
              </div>
              <div className="flex flex-col items-end">
                <span className="bg-green-500 text-white text-xs font-semibold py-0.5 px-2 rounded-full mb-1">
                  TRENDING
                </span>
                <span className="bg-purple-500 text-white text-xs font-semibold py-0.5 px-2 rounded-full">POPULAR</span>
              </div>
            </div>
          </div>

          <div className="group relative">
            <div className="w-full min-h-80 bg-gray-200 aspect-w-1 aspect-h-1 rounded-md overflow-hidden group-hover:opacity-75 lg:h-80 lg:aspect-none">
              <img
                src="https://via.placeholder.com/400x300"
                alt="Sample Game"
                className="w-full h-full object-center object-cover lg:w-full lg:h-full"
              />
            </div>
            <div className="mt-4 flex justify-between">
              <div>
                <h3 className="text-sm text-gray-700">
                  <a href="#">
                    <span aria-hidden="true" className="absolute inset-0" />
                    Sample Game Title
                  </a>
                </h3>
                <p className="mt-1 text-sm text-gray-500">Provider Name</p>
              </div>
              <div className="flex flex-col items-end">
                <span className="bg-green-500 text-white text-xs font-semibold py-0.5 px-2 rounded-full mb-1">
                  TRENDING
                </span>
                <span className="bg-purple-500 text-white text-xs font-semibold py-0.5 px-2 rounded-full">POPULAR</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default FeaturedProducts
