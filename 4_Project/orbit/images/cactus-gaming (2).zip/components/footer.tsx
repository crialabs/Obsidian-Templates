"use client"

import Link from "next/link"
import Image from "next/image"
import { navigationLinks } from "@/data/navigation"
import { socialLinks } from "@/data/social-links"
import { motion } from "framer-motion"
import { Mail, Phone, MapPin } from "lucide-react"

export default function Footer() {
  return (
    <footer className="relative overflow-hidden border-t border-dark-800/50">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent to-purple-950/5"></div>

      {/* Glowing orb effects */}
      <div className="absolute -top-40 left-20 w-80 h-80 rounded-full bg-purple-500/5 blur-[80px]"></div>
      <div className="absolute -bottom-20 right-40 w-60 h-60 rounded-full bg-green-500/5 blur-[60px]"></div>

      <div className="container mx-auto px-4 py-16 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          <motion.div
            className="space-y-6"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            <Link href="/" className="flex items-center space-x-3">
              <div className="relative w-8 h-8">
                <div className="absolute inset-0 rounded-full bg-purple-500/20 blur-md"></div>
                <Image
                  src="/placeholder.svg?height=32&width=32"
                  alt="Orbit Games Logo"
                  width={32}
                  height={32}
                  className="relative z-10"
                />
              </div>
              <span className="text-xl font-bold text-gradient-purple">Orbit Games</span>
            </Link>
            <p className="text-neutral-400 leading-relaxed">
              Soluções inovadoras para apostas online com até 50% mais conversão. Transforme seu negócio com nossa
              tecnologia de ponta.
            </p>
            <div className="flex space-x-4">
              {socialLinks.map((link, index) => (
                <Link
                  key={link.name}
                  href={link.href}
                  className="text-neutral-500 hover:text-purple-400 transition-colors duration-300 p-2 rounded-lg hover:bg-purple-500/10"
                  aria-label={link.name}
                >
                  <link.icon className="h-5 w-5" />
                </Link>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            viewport={{ once: true }}
          >
            <h3 className="font-bold text-lg mb-6 text-neutral-100">Links Rápidos</h3>
            <ul className="space-y-3">
              {navigationLinks.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-neutral-400 hover:text-purple-400 transition-colors duration-300 text-sm"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <h3 className="font-bold text-lg mb-6 text-neutral-100">Produtos</h3>
            <ul className="space-y-3">
              <li>
                <Link
                  href="/produtos/mines"
                  className="text-neutral-400 hover:text-purple-400 transition-colors duration-300 text-sm"
                >
                  Mines
                </Link>
              </li>
              <li>
                <Link
                  href="/produtos/aviator"
                  className="text-neutral-400 hover:text-purple-400 transition-colors duration-300 text-sm"
                >
                  Aviator
                </Link>
              </li>
              <li>
                <Link
                  href="/produtos/fortune-tiger"
                  className="text-neutral-400 hover:text-purple-400 transition-colors duration-300 text-sm"
                >
                  Fortune Tiger
                </Link>
              </li>
              <li>
                <Link
                  href="/produtos/spaceman"
                  className="text-neutral-400 hover:text-purple-400 transition-colors duration-300 text-sm"
                >
                  Spaceman
                </Link>
              </li>
            </ul>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            viewport={{ once: true }}
          >
            <h3 className="font-bold text-lg mb-6 text-neutral-100">Contato</h3>
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <Mail className="h-4 w-4 text-purple-400" />
                <span className="text-neutral-400 text-sm">business@orbitgames.net</span>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="h-4 w-4 text-green-400" />
                <span className="text-neutral-400 text-sm">(031) 99134-3862</span>
              </div>
              <div className="flex items-center gap-3">
                <MapPin className="h-4 w-4 text-neutral-400" />
                <span className="text-neutral-400 text-sm">Brasil</span>
              </div>
            </div>
          </motion.div>
        </div>

        <div className="border-t border-dark-800/50 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-center md:text-left">
              <p className="text-neutral-500 text-sm mb-2">
                Orbit Tecnologia Ltda, uma empresa registrada no Brasil, sob o número CNPJ 57.920.261/0001-47
              </p>
              <p className="text-neutral-500 text-sm">
                © {new Date().getFullYear()} Orbit Games. Todos os direitos reservados.
              </p>
            </div>
            <div className="flex items-center gap-4">
              <Link
                href="/politica-de-privacidade"
                className="text-neutral-500 hover:text-purple-400 transition-colors text-sm"
              >
                Política de Privacidade
              </Link>
              <Link href="/termos-de-uso" className="text-neutral-500 hover:text-purple-400 transition-colors text-sm">
                Termos de Uso
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
