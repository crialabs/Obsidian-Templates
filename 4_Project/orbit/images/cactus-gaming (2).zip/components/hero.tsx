"use client"

import { useEffect, useRef } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { motion } from "framer-motion"
import { ScrollAnimation } from "@/components/scroll-animations"
import { ArrowRight, Play } from "lucide-react"

export default function Hero() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    canvas.width = window.innerWidth
    canvas.height = window.innerHeight

    const particles: {
      x: number
      y: number
      size: number
      speedX: number
      speedY: number
      color: string
      alpha: number
    }[] = []

    const createParticles = () => {
      for (let i = 0; i < 80; i++) {
        particles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          size: Math.random() * 2 + 0.5,
          speedX: Math.random() * 0.3 - 0.15,
          speedY: Math.random() * 0.3 - 0.15,
          color: "#5B21B6",
          alpha: Math.random() * 0.4 + 0.1,
        })
      }
    }

    const animateParticles = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      for (let i = 0; i < particles.length; i++) {
        const p = particles[i]
        ctx.beginPath()
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(91, 33, 182, ${p.alpha})`
        ctx.fill()

        p.x += p.speedX
        p.y += p.speedY

        if (p.x > canvas.width) p.x = 0
        if (p.x < 0) p.x = canvas.width
        if (p.y > canvas.height) p.y = 0
        if (p.y < 0) p.y = canvas.height
      }

      // Connect particles with lines if they are close enough
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x
          const dy = particles[i].y - particles[j].y
          const distance = Math.sqrt(dx * dx + dy * dy)

          if (distance < 120) {
            ctx.beginPath()
            ctx.strokeStyle = `rgba(91, 33, 182, ${0.08 * (1 - distance / 120)})`
            ctx.lineWidth = 0.5
            ctx.moveTo(particles[i].x, particles[i].y)
            ctx.lineTo(particles[j].x, particles[j].y)
            ctx.stroke()
          }
        }
      }

      requestAnimationFrame(animateParticles)
    }

    const handleResize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
      particles.length = 0
      createParticles()
    }

    createParticles()
    animateParticles()

    window.addEventListener("resize", handleResize)

    return () => {
      window.removeEventListener("resize", handleResize)
    }
  }, [])

  return (
    <section className="relative overflow-hidden min-h-screen flex items-center">
      {/* Background gradient */}
      <div className="absolute inset-0">
        <Image
          src="/images/gradient-bg.jpeg"
          alt="Background gradient"
          fill
          className="object-cover opacity-40"
          priority
        />
      </div>

      <canvas ref={canvasRef} className="absolute inset-0 z-0" style={{ opacity: 0.3 }} />

      {/* Glowing orb effects */}
      <div className="absolute top-1/3 right-1/5 w-[400px] h-[400px] rounded-full bg-purple-500/6 blur-[100px] animate-pulse-glow"></div>
      <div
        className="absolute bottom-1/3 left-1/5 w-[300px] h-[300px] rounded-full bg-purple-600/4 blur-[80px] animate-pulse-glow"
        style={{ animationDelay: "-3s" }}
      ></div>

      <div className="container relative mx-auto px-4 z-10 py-20">
        <ScrollAnimation animation="fade-in">
          <div className="grid lg:grid-cols-2 gap-12 items-center min-h-[80vh]">
            {/* Left Column - Content */}
            <div className="space-y-8">
              <motion.div
                className="space-y-6"
                initial={{ opacity: 0, x: -30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: 0.1 }}
              >
                <span className="inline-flex items-center px-4 py-2 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-300 text-sm font-medium backdrop-blur-sm">
                  🚀 Lançamento Rápido e Resultados Imediatos
                </span>

                <h1 className="text-4xl md:text-5xl xl:text-6xl font-bold tracking-tight text-balance leading-[1.1]">
                  Domine o Mercado de Apostas:{" "}
                  <span className="text-gradient-purple glow-purple-text">Plataforma Orbit Gaming</span>, Ativa e
                  Rentável em 48 Horas
                </h1>

                <p className="text-lg md:text-xl text-neutral-300 leading-relaxed max-w-xl">
                  Seja parte da nova onda de entretenimento online. A Orbit Gaming é seu parceiro estratégico para
                  transformar sua visão em um negócio lucrativo em tempo recorde.
                </p>
              </motion.div>

              <motion.div
                className="flex flex-col sm:flex-row gap-4"
                initial={{ opacity: 0, x: -30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: 0.4 }}
              >
                <Button size="xl" variant="cta" asChild>
                  <Link href="/contato" className="group">
                    Quero Lançar Minha Operação em 48h!
                    <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
                  </Link>
                </Button>
                <Button size="xl" variant="outline" asChild>
                  <Link href="/agendar-demo" className="group">
                    <Play className="mr-2 h-5 w-5" />
                    Fale com Nossos Especialistas
                  </Link>
                </Button>
              </motion.div>

              {/* Trust indicators */}
              <motion.div
                className="flex flex-wrap items-center gap-6 pt-4"
                initial={{ opacity: 0, x: -30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: 0.6 }}
              >
                <div className="flex items-center gap-2 text-sm text-neutral-400">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                  Ativação em 48h
                </div>
                <div className="flex items-center gap-2 text-sm text-neutral-400">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                  Suporte 24/7
                </div>
                <div className="flex items-center gap-2 text-sm text-neutral-400">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                  Resultados Garantidos
                </div>
              </motion.div>
            </div>

            {/* Right Column - Stats & Visual Elements */}
            <div className="relative">
              <motion.div
                className="grid grid-cols-2 gap-6"
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: 0.8 }}
              >
                {[
                  {
                    number: "48h",
                    label: "Ativação Expressa",
                    description: "plataforma pronta",
                    icon: "⚡",
                  },
                  {
                    number: "3000+",
                    label: "Jogos Premium",
                    description: "portfólio completo",
                    icon: "🎮",
                  },
                  {
                    number: "24/7",
                    label: "Suporte Imbatível",
                    description: "equipe dedicada",
                    icon: "🛠️",
                  },
                  {
                    number: "98%",
                    label: "RTP Turbinado",
                    description: "máximo retorno",
                    icon: "💎",
                  },
                ].map((stat, index) => (
                  <motion.div
                    key={index}
                    className="bg-dark-800/50 backdrop-blur-sm border border-purple-500/10 rounded-2xl p-6 text-center hover:border-purple-500/20 transition-all duration-300"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: 1 + index * 0.1 }}
                  >
                    <div className="text-2xl mb-2">{stat.icon}</div>
                    <div className="text-2xl md:text-3xl font-bold text-gradient-green mb-1">{stat.number}</div>
                    <div className="text-sm font-semibold text-neutral-200 mb-1">{stat.label}</div>
                    <div className="text-xs text-neutral-400">{stat.description}</div>
                  </motion.div>
                ))}
              </motion.div>

              {/* Floating elements */}
              <div className="absolute -top-4 -right-4 w-20 h-20 bg-purple-500/10 rounded-full blur-xl animate-pulse-glow"></div>
              <div
                className="absolute -bottom-4 -left-4 w-16 h-16 bg-green-500/10 rounded-full blur-lg animate-pulse-glow"
                style={{ animationDelay: "-2s" }}
              ></div>
            </div>
          </div>
        </ScrollAnimation>

        {/* Scroll indicator */}
        <motion.div
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1.4 }}
        >
          <div className="w-6 h-10 border-2 border-purple-500/30 rounded-full flex justify-center">
            <div className="w-1 h-3 bg-purple-500 rounded-full mt-2 animate-bounce"></div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
