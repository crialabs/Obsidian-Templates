import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

const buttonVariants = cva(
  "inline-flex items-center justify-center whitespace-nowrap rounded-lg text-sm font-semibold ring-offset-background transition-all duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      variant: {
        default: "green-gradient text-white hover:brightness-110 hover:scale-105 glow-green-sm",
        destructive: "bg-red-600 text-white hover:bg-red-700",
        outline:
          "border border-dark-700/50 bg-dark-800/30 backdrop-blur-sm hover:bg-dark-700/50 hover:border-purple-500/50 text-neutral-200 hover:text-white",
        secondary: "bg-dark-800/50 text-neutral-200 hover:bg-dark-700/50 hover:text-white",
        ghost: "hover:bg-dark-800/50 hover:text-white",
        link: "text-purple-400 underline-offset-4 hover:underline hover:text-purple-300",
        cta: "green-gradient text-white glow-green hover:brightness-110 transform hover:scale-105 transition-all duration-300 font-semibold",
        purple: "purple-gradient text-white hover:brightness-110 hover:scale-105 glow-purple-sm",
      },
      size: {
        default: "h-11 px-6 py-2.5",
        sm: "h-9 rounded-md px-4 text-sm",
        lg: "h-12 rounded-lg px-8 text-base",
        xl: "h-14 rounded-lg px-10 text-lg",
        icon: "h-11 w-11",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
)

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button"
    return <Comp className={cn(buttonVariants({ variant, size, className }))} ref={ref} {...props} />
  },
)
Button.displayName = "Button"

export { Button, buttonVariants }
