"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Menu, X, Globe, ChevronDown } from "lucide-react"
import { navigationLinks } from "@/data/navigation"
import { motion, AnimatePresence } from "framer-motion"

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [language, setLanguage] = useState("pt")
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      const offset = window.scrollY
      if (offset > 50) {
        setScrolled(true)
      } else {
        setScrolled(false)
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => {
      window.removeEventListener("scroll", handleScroll)
    }
  }, [])

  return (
    <header
      className={`sticky top-0 z-50 w-full transition-all duration-300 ${
        scrolled ? "bg-dark-950/90 backdrop-blur-md border-b border-dark-800/50" : "bg-transparent"
      }`}
    >
      <div className="container flex h-16 items-center px-4 sm:px-6">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="flex items-center gap-3 mr-6"
        >
          <Link href="/" className="flex items-center space-x-3">
            <div className="relative w-8 h-8">
              <div
                className={`absolute inset-0 rounded-full bg-purple-500/20 blur-md transition-opacity duration-300 ${
                  scrolled ? "opacity-100" : "opacity-0"
                }`}
              ></div>
              <Image
                src="/placeholder.svg?height=32&width=32"
                alt="Orbit Games Logo"
                width={32}
                height={32}
                className="relative z-10"
              />
            </div>
            <span className="text-xl font-bold text-gradient-purple">Orbit Games</span>
          </Link>
        </motion.div>

        <nav className="hidden md:flex flex-1 items-center justify-between">
          <ul className="flex items-center gap-8">
            {navigationLinks.map((link, index) => (
              <motion.li
                key={link.href}
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
              >
                <Link
                  href={link.href}
                  className="text-sm font-medium transition-all duration-300 hover:text-purple-400 relative group py-2"
                >
                  {link.label}
                  <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-purple-500 to-green-500 transition-all duration-300 group-hover:w-full"></span>
                </Link>
              </motion.li>
            ))}
          </ul>

          <div className="flex items-center gap-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3, delay: 0.3 }}
            >
              <Button
                variant="outline"
                size="sm"
                className="flex items-center gap-2"
                onClick={() => setLanguage(language === "pt" ? "en" : "pt")}
              >
                <Globe className="h-4 w-4" />
                <span className="hidden sm:inline">{language === "pt" ? "Português" : "English"}</span>
                <ChevronDown className="h-3 w-3" />
              </Button>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3, delay: 0.4 }}
            >
              <Button size="sm" variant="cta" asChild>
                <Link href="/contato">Começar</Link>
              </Button>
            </motion.div>
          </div>
        </nav>

        <div className="flex flex-1 items-center justify-end md:hidden">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label="Toggle menu"
            className="text-neutral-300 hover:text-white"
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>
        </div>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <>
            <motion.div
              className="fixed inset-0 z-50 bg-dark-950/80 backdrop-blur-md md:hidden"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              onClick={() => setIsMenuOpen(false)}
            />
            <motion.div
              className="fixed top-16 inset-x-0 z-50 w-full p-6 bg-dark-900/95 backdrop-blur-xl border-b border-dark-800/50 shadow-2xl md:hidden"
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
            >
              <nav className="grid gap-6">
                <ul className="grid gap-4">
                  {navigationLinks.map((link, index) => (
                    <motion.li
                      key={link.href}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.2, delay: 0.1 + index * 0.05 }}
                    >
                      <Link
                        href={link.href}
                        className="text-base font-medium transition-colors hover:text-purple-400 block py-2"
                        onClick={() => setIsMenuOpen(false)}
                      >
                        {link.label}
                      </Link>
                    </motion.li>
                  ))}
                </ul>

                <div className="grid gap-4 pt-4 border-t border-dark-800/50">
                  <Button
                    variant="outline"
                    className="flex items-center justify-center gap-2"
                    onClick={() => setLanguage(language === "pt" ? "en" : "pt")}
                  >
                    <Globe className="h-4 w-4" />
                    <span>{language === "pt" ? "Português" : "English"}</span>
                  </Button>
                  <Button variant="cta" className="w-full" asChild>
                    <Link href="/contato" onClick={() => setIsMenuOpen(false)}>
                      Começar
                    </Link>
                  </Button>
                </div>
              </nav>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </header>
  )
}
