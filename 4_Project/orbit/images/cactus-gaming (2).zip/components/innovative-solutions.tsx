"use client"

import { useRef } from "react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import Image from "next/image"
import { Code } from "lucide-react"
import { motion, useScroll, useTransform } from "framer-motion"

export default function InnovativeSolutions() {
  const sectionRef = useRef<HTMLElement>(null)
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start end", "end start"],
  })

  const imageY = useTransform(scrollYProgress, [0, 1], [100, -100])
  const contentY = useTransform(scrollYProgress, [0, 1], [50, -50])

  return (
    <section ref={sectionRef} className="py-24 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 bg-gradient-to-b from-blue-950/10 to-transparent"></div>
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-blue-500/20 to-transparent"></div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div style={{ y: imageY }} className="order-2 lg:order-1 relative">
            <div className="absolute -inset-4 bg-blue-500/5 rounded-3xl blur-xl"></div>
            <div className="relative">
              <div className="relative h-[400px] rounded-lg overflow-hidden glass-effect border border-blue-500/20">
                <div className="absolute inset-0 bg-gradient-to-br from-blue-600/10 to-blue-900/10"></div>
                <Image
                  src="/placeholder.svg?height=800&width=600"
                  alt="API Integration"
                  fill
                  className="object-cover opacity-90 hover:opacity-100 transition-opacity duration-500"
                />

                {/* Glowing dots */}
                <div className="absolute top-1/4 left-1/4 w-2 h-2 rounded-full bg-blue-500 glow-sm animate-pulse-slow"></div>
                <div
                  className="absolute top-1/2 right-1/3 w-2 h-2 rounded-full bg-blue-500 glow-sm animate-pulse-slow"
                  style={{ animationDelay: "-1s" }}
                ></div>
                <div
                  className="absolute bottom-1/3 right-1/4 w-2 h-2 rounded-full bg-blue-500 glow-sm animate-pulse-slow"
                  style={{ animationDelay: "-2s" }}
                ></div>
              </div>

              {/* Code snippet overlay */}
              <div className="absolute -bottom-8 -right-8 w-2/3 p-4 glass-effect border border-blue-500/20 rounded-lg text-xs text-blue-300/80 font-mono">
                <pre className="opacity-70">
                  <code>
                    {`// API Integration
fetch('https://api.orbitgames.com/v1/games')
  .then(response => response.json())
  .then(data => console.log(data))`}
                  </code>
                </pre>
              </div>
            </div>
          </motion.div>

          <motion.div style={{ y: contentY }} className="order-1 lg:order-2">
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <div className="flex items-center gap-4 mb-6">
                <div className="blue-gradient p-3 rounded-lg glow-sm">
                  <Code className="h-6 w-6 text-white" />
                </div>
                <h2 className="text-4xl font-bold text-blue-100">Gerenciável e poderoso</h2>
              </div>
              <h3 className="text-2xl font-bold mb-4 bg-gradient-to-r from-blue-400 to-blue-600 bg-clip-text text-transparent">
                Integração de API
              </h3>
              <p className="text-blue-100/80 mb-8 leading-relaxed">
                Oferecemos uma solução de API robusta projetada para operadores online existentes que desejam integrar
                nossas soluções de jogos e apostas, bem como Odds Feed, em suas plataformas existentes. Para
                desenvolvimento de design personalizado, os operadores podem usar nossa solução Swarm API ou recorrer
                aos nossos códigos front-end de código aberto, disponíveis no GitHub.
              </p>
              <Button variant="glow" asChild>
                <Link href="/solucoes">Conheça Nossas Soluções</Link>
              </Button>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
