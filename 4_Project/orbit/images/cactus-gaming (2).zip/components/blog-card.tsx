import Image from "next/image"
import Link from "next/link"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CalendarIcon, Clock, User } from "lucide-react"
import type { BlogPost } from "@/types/blog-post"

interface BlogCardProps {
  post: BlogPost
}

export function BlogCard({ post }: BlogCardProps) {
  return (
    <Card className="overflow-hidden bg-gray-900 border-gray-800 transition-all hover:border-purple-500/50 hover:shadow-md hover:shadow-purple-500/10">
      <CardHeader className="p-0">
        <div className="relative h-48 w-full overflow-hidden">
          <Image
            src={post.coverImage || "/placeholder.svg?height=400&width=600"}
            alt={post.title}
            fill
            className="object-cover transition-transform hover:scale-105"
          />
          {post.featured && <Badge className="absolute top-2 right-2 bg-purple-600">Destaque</Badge>}
        </div>
      </CardHeader>
      <CardContent className="p-4">
        <div className="mb-2 flex items-center gap-2">
          <Badge variant="outline" className="text-xs">
            {post.category}
          </Badge>
        </div>
        <Link href={`/blog/${post.slug}`}>
          <h3 className="font-bold text-xl mb-2 hover:text-purple-400 transition-colors">{post.title}</h3>
        </Link>
        <p className="text-gray-400 text-sm line-clamp-3">{post.excerpt}</p>
      </CardContent>
      <CardFooter className="p-4 pt-0 text-xs text-gray-400">
        <div className="flex items-center justify-between w-full">
          <div className="flex items-center gap-1">
            <User className="h-3 w-3" />
            <span>{post.author}</span>
          </div>
          <div className="flex items-center gap-1">
            <CalendarIcon className="h-3 w-3" />
            <span>{post.date}</span>
          </div>
          <div className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            <span>{post.readTime} min</span>
          </div>
        </div>
      </CardFooter>
    </Card>
  )
}
