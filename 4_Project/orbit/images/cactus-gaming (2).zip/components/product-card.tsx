import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ShoppingCart, Sparkles, Star } from "lucide-react"
import type { Product } from "@/types/product"

interface ProductCardProps {
  product: Product
}

export function ProductCard({ product }: ProductCardProps) {
  return (
    <div className="group relative">
      {/* Animated gradient border */}
      <div className="absolute -inset-0.5 bg-gradient-to-r from-purple-600 via-purple-400 to-purple-600 rounded-xl opacity-0 group-hover:opacity-100 transition-all duration-500 animate-gradient-border blur-sm"></div>

      <Card className="relative overflow-hidden card-modern transition-all duration-500 group-hover:border-purple-500/50 group-hover:shadow-2xl group-hover:shadow-purple-500/10 card-hover-effect">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

        <CardHeader className="p-0 relative">
          <div className="relative h-48 w-full overflow-hidden rounded-t-xl">
            <Image
              src={product.image || "/placeholder.svg?height=400&width=600"}
              alt={product.name}
              fill
              className="object-cover transition-all duration-700 group-hover:scale-110"
            />

            {/* Overlay gradient */}
            <div className="absolute inset-0 bg-gradient-to-t from-dark-900/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

            {/* Floating sparkle effect */}
            <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
              <Sparkles className="w-5 h-5 text-purple-400 animate-pulse" />
            </div>

            {product.isNew && (
              <Badge className="absolute top-3 left-3 green-gradient text-white border-0 glow-green-sm font-semibold">
                Novo
              </Badge>
            )}

            {/* Rating display */}
            {product.rating && (
              <div className="absolute bottom-3 left-3 flex items-center gap-1 bg-dark-900/80 backdrop-blur-sm px-2 py-1 rounded-md">
                <Star className="w-4 h-4 text-yellow-400 fill-current" />
                <span className="text-sm font-medium text-white">{product.rating}</span>
              </div>
            )}
          </div>
        </CardHeader>

        <CardContent className="p-6 relative z-10">
          <div className="mb-3 flex items-center justify-between">
            <Badge variant="outline" className="text-xs border-purple-500/30 text-purple-300 bg-purple-500/10">
              {product.category}
            </Badge>
            <span className="font-bold text-xl text-gradient-green">{product.price}</span>
          </div>

          <Link href={`/produtos/${product.id}`}>
            <h3 className="font-bold text-xl mb-3 hover:text-purple-400 transition-colors duration-300 group-hover:text-gradient-purple line-clamp-1">
              {product.name}
            </h3>
          </Link>

          <p className="text-neutral-400 text-sm line-clamp-2 group-hover:text-neutral-300 transition-colors duration-300 leading-relaxed">
            {product.description}
          </p>

          {/* Stock indicator */}
          {product.stock !== undefined && (
            <div className="mt-3 flex items-center gap-2">
              <div
                className={`w-2 h-2 rounded-full ${product.stock > 10 ? "bg-green-500" : product.stock > 0 ? "bg-yellow-500" : "bg-red-500"}`}
              ></div>
              <span className="text-xs text-neutral-500">
                {product.stock > 10
                  ? "Em estoque"
                  : product.stock > 0
                    ? `Apenas ${product.stock} restantes`
                    : "Fora de estoque"}
              </span>
            </div>
          )}
        </CardContent>

        <CardFooter className="p-6 pt-0 relative z-10">
          <Button className="w-full" variant="cta" disabled={product.stock === 0}>
            <ShoppingCart className="mr-2 h-4 w-4" />
            {product.stock === 0 ? "Indisponível" : "Adicionar ao Carrinho"}
          </Button>
        </CardFooter>

        {/* Glowing dots */}
        <div className="absolute top-4 right-4 w-2 h-2 rounded-full bg-purple-500 opacity-0 group-hover:opacity-100 transition-opacity duration-500 glow-purple-sm"></div>
        <div className="absolute bottom-4 left-4 w-2 h-2 rounded-full bg-green-500 opacity-0 group-hover:opacity-100 transition-opacity duration-500 glow-green-sm"></div>
      </Card>
    </div>
  )
}
