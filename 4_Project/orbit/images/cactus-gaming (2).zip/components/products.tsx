const Products = () => {
  return (
    <section className="bg-gray-100 py-12">
      <div className="container mx-auto text-center">
        <h2 className="text-3xl font-semibold text-gray-800 mb-8">
          O Maior e Melhor Portfólio de Jogos: +3.000 Títulos para Turbinar Seu Negócio
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Product Card 1 */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-semibold text-gray-700 mb-2">+3.000 Jogos</h3>
            <p className="text-gray-600">Variedade Ilimitada: +3.000 Slots e Jogos de Cassino</p>
          </div>

          {/* Product Card 2 */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-semibold text-gray-700 mb-2">RTP Alto</h3>
            <p className="text-gray-600">RTP Turbinado: Até 98% de Retorno para Seus Jogadores</p>
          </div>

          {/* Product Card 3 */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-semibold text-gray-700 mb-2">Jackpots</h3>
            <p className="text-gray-600">Jackpots Milionários: Prêmios Progressivos Que Atraem e Retêm</p>
          </div>
        </div>

        {/* Featured Games Section */}
        <div className="mt-12">
          <h3 className="text-2xl font-semibold text-gray-800 mb-4">Jogos em Destaque</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Featured Game 1 */}
            <div className="bg-white rounded-lg shadow-md p-6 relative">
              <img src="https://via.placeholder.com/300x200" alt="Featured Game" className="mb-4 rounded-md" />
              <span className="absolute top-2 left-2 bg-green-500 text-white text-xs font-semibold py-1 px-2 rounded">
                TRENDING
              </span>
              <h4 className="text-lg font-semibold text-gray-700 mb-2">Jogo Exemplo 1</h4>
              <p className="text-gray-600">Descrição do jogo em destaque.</p>
            </div>

            {/* Featured Game 2 */}
            <div className="bg-white rounded-lg shadow-md p-6 relative">
              <img src="https://via.placeholder.com/300x200" alt="Featured Game" className="mb-4 rounded-md" />
              <span className="absolute top-2 left-2 bg-blue-500 text-white text-xs font-semibold py-1 px-2 rounded">
                POPULAR
              </span>
              <h4 className="text-lg font-semibold text-gray-700 mb-2">Jogo Exemplo 2</h4>
              <p className="text-gray-600">Descrição do jogo em destaque.</p>
            </div>

            {/* Featured Game 3 */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <img src="https://via.placeholder.com/300x200" alt="Featured Game" className="mb-4 rounded-md" />
              <h4 className="text-lg font-semibold text-gray-700 mb-2">Jogo Exemplo 3</h4>
              <p className="text-gray-600">Descrição do jogo em destaque.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Products
