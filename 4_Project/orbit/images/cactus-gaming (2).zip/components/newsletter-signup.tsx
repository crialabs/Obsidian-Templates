import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export default function NewsletterSignup() {
  return (
    <section className="py-16 bg-black">
      <div className="container mx-auto px-4">
        <div className="bg-gradient-to-r from-purple-900/20 to-blue-900/20 rounded-xl p-8 md:p-12">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-4">Fique por dentro das novidades</h2>
            <p className="text-gray-400 mb-8">
              Assine nossa newsletter e receba as últimas notícias, ofertas exclusivas e dicas de jogos diretamente na
              sua caixa de entrada.
            </p>
            <form className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <Input type="email" placeholder="Seu melhor email" className="bg-gray-900 border-gray-700" />
              <Button type="submit">Assinar</Button>
            </form>
            <p className="text-xs text-gray-500 mt-4">
              Ao assinar, você concorda com nossa Política de Privacidade. Você pode cancelar a qualquer momento.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
