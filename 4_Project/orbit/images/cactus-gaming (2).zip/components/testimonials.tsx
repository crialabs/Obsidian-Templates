const Testimonials = () => {
  return (
    <section className="bg-gray-100 py-12">
      <div className="container mx-auto text-center">
        <h2 className="text-3xl font-semibold text-gray-800 mb-4">
          Resultados Reais, Clientes Satisfeitos: Veja Quem Já Transformou Seus Negócios com a Orbit Gaming
        </h2>
        <p className="text-gray-600 mb-8">
          Empresários que já transformaram suas visões em negócios lucrativos confiam na Orbit Gaming para alcançar
          resultados extraordinários.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Testimonial 1 */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <p className="text-gray-700 italic mb-4">
              "Orbit Gaming has completely revolutionized our marketing strategy. We've seen a significant increase in
              customer engagement and sales."
            </p>
            <div className="flex items-center justify-center">
              <img
                src="https://via.placeholder.com/50" // Replace with actual image URL
                alt="Client 1"
                className="rounded-full w-12 h-12 mr-2"
              />
              <div>
                <p className="text-gray-800 font-semibold">John Doe</p>
                <p className="text-gray-500">CEO, Company A</p>
              </div>
            </div>
          </div>

          {/* Testimonial 2 */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <p className="text-gray-700 italic mb-4">
              "The team at Orbit Gaming is incredibly knowledgeable and responsive. They helped us navigate the complex
              world of esports and achieve our business goals."
            </p>
            <div className="flex items-center justify-center">
              <img
                src="https://via.placeholder.com/50" // Replace with actual image URL
                alt="Client 2"
                className="rounded-full w-12 h-12 mr-2"
              />
              <div>
                <p className="text-gray-800 font-semibold">Jane Smith</p>
                <p className="text-gray-500">Founder, Company B</p>
              </div>
            </div>
          </div>

          {/* Testimonial 3 */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <p className="text-gray-700 italic mb-4">
              "We were struggling to attract new players to our game. Orbit Gaming's strategies helped us reach a wider
              audience and increase our player base."
            </p>
            <div className="flex items-center justify-center">
              <img
                src="https://via.placeholder.com/50" // Replace with actual image URL
                alt="Client 3"
                className="rounded-full w-12 h-12 mr-2"
              />
              <div>
                <p className="text-gray-800 font-semibold">Peter Jones</p>
                <p className="text-gray-500">Marketing Manager, Company C</p>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8">
          <h3 className="text-2xl font-semibold text-gray-800 mb-4">Resultados Comprovados</h3>
          <ul className="list-disc list-inside text-gray-600">
            <li>+200% de receita em 6 meses</li>
            <li>ROI de 300% no primeiro ano</li>
            <li>Crescimento de 150% em jogadores ativos</li>
          </ul>
        </div>
      </div>
    </section>
  )
}

export default Testimonials
