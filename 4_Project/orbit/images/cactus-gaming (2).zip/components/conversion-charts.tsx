"use client"

import { useRef, useEffect, useState } from "react"
import { motion, useScroll, useTransform } from "framer-motion"
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  Filler,
  type ChartOptions,
} from "chart.js"
import { Line, Bar } from "react-chartjs-2"
import { Button } from "@/components/ui/button"
import Link from "next/link"

// Register ChartJS components
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, BarElement, Title, Tooltip, Legend, Filler)

export default function ConversionCharts() {
  const sectionRef = useRef<HTMLElement>(null)
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start end", "end start"],
  })

  const y = useTransform(scrollYProgress, [0, 1], [50, -50])
  const [animationComplete, setAnimationComplete] = useState(false)

  // Chart animation state
  const [chartData, setChartData] = useState({
    conversionRate: 0,
    growthRate: 0,
    retentionRate: 0,
  })

  useEffect(() => {
    const timer = setTimeout(() => {
      setAnimationComplete(true)
    }, 2000)

    return () => clearTimeout(timer)
  }, [])

  useEffect(() => {
    if (animationComplete) return

    const interval = setInterval(() => {
      setChartData((prev) => ({
        conversionRate: Math.min(prev.conversionRate + 1, 50),
        growthRate: Math.min(prev.growthRate + 0.8, 40),
        retentionRate: Math.min(prev.retentionRate + 0.6, 30),
      }))
    }, 20)

    return () => clearInterval(interval)
  }, [animationComplete])

  // Line chart data
  const lineChartData = {
    labels: ["Jan", "Feb", "Mar", "Apr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"],
    datasets: [
      {
        label: "Orbit Games",
        data: [10, 15, 20, 25, 30, 35, 40, 45, 48, 50, 52, 55],
        borderColor: "rgba(59, 130, 246, 1)",
        backgroundColor: "rgba(59, 130, 246, 0.1)",
        fill: true,
        tension: 0.4,
        borderWidth: 3,
        pointBackgroundColor: "rgba(59, 130, 246, 1)",
        pointBorderColor: "#fff",
        pointRadius: 4,
        pointHoverRadius: 6,
      },
      {
        label: "Concorrência",
        data: [10, 12, 15, 18, 20, 22, 25, 27, 28, 30, 31, 32],
        borderColor: "rgba(99, 102, 241, 0.5)",
        backgroundColor: "rgba(99, 102, 241, 0.05)",
        fill: true,
        tension: 0.4,
        borderWidth: 2,
        pointBackgroundColor: "rgba(99, 102, 241, 0.5)",
        pointBorderColor: "#fff",
        pointRadius: 3,
        pointHoverRadius: 5,
      },
    ],
  }

  // Bar chart data
  const barChartData = {
    labels: ["Taxa de Conversão", "Taxa de Crescimento", "Taxa de Retenção"],
    datasets: [
      {
        label: "Orbit Games",
        data: [chartData.conversionRate, chartData.growthRate, chartData.retentionRate],
        backgroundColor: ["rgba(59, 130, 246, 0.8)", "rgba(59, 130, 246, 0.8)", "rgba(59, 130, 246, 0.8)"],
        borderColor: ["rgba(59, 130, 246, 1)", "rgba(59, 130, 246, 1)", "rgba(59, 130, 246, 1)"],
        borderWidth: 1,
        borderRadius: 5,
      },
      {
        label: "Concorrência",
        data: [25, 20, 15],
        backgroundColor: ["rgba(99, 102, 241, 0.4)", "rgba(99, 102, 241, 0.4)", "rgba(99, 102, 241, 0.4)"],
        borderColor: ["rgba(99, 102, 241, 0.6)", "rgba(99, 102, 241, 0.6)", "rgba(99, 102, 241, 0.6)"],
        borderWidth: 1,
        borderRadius: 5,
      },
    ],
  }

  // Chart options
  const lineChartOptions: ChartOptions<"line"> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: "top" as const,
        labels: {
          color: "rgba(148, 163, 184, 1)",
          font: {
            family: "Inter, sans-serif",
            size: 12,
          },
          usePointStyle: true,
          pointStyle: "circle",
        },
      },
      tooltip: {
        backgroundColor: "rgba(15, 23, 42, 0.8)",
        titleColor: "rgba(255, 255, 255, 1)",
        bodyColor: "rgba(203, 213, 225, 1)",
        borderColor: "rgba(59, 130, 246, 0.3)",
        borderWidth: 1,
        padding: 12,
        boxPadding: 6,
        usePointStyle: true,
        callbacks: {
          label: (context) => `${context.dataset.label}: ${context.parsed.y}%`,
        },
      },
    },
    scales: {
      x: {
        grid: {
          color: "rgba(71, 85, 105, 0.1)",
        },
        ticks: {
          color: "rgba(148, 163, 184, 0.8)",
        },
      },
      y: {
        grid: {
          color: "rgba(71, 85, 105, 0.1)",
        },
        ticks: {
          color: "rgba(148, 163, 184, 0.8)",
          callback: (value) => value + "%",
        },
        min: 0,
        max: 60,
      },
    },
    animation: {
      duration: 2000,
      easing: "easeOutQuart",
    },
    elements: {
      line: {
        tension: 0.4,
      },
      point: {
        radius: 0,
        hoverRadius: 6,
      },
    },
  }

  const barChartOptions: ChartOptions<"bar"> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: "top" as const,
        labels: {
          color: "rgba(148, 163, 184, 1)",
          font: {
            family: "Inter, sans-serif",
            size: 12,
          },
          usePointStyle: true,
          pointStyle: "circle",
        },
      },
      tooltip: {
        backgroundColor: "rgba(15, 23, 42, 0.8)",
        titleColor: "rgba(255, 255, 255, 1)",
        bodyColor: "rgba(203, 213, 225, 1)",
        borderColor: "rgba(59, 130, 246, 0.3)",
        borderWidth: 1,
        padding: 12,
        boxPadding: 6,
        usePointStyle: true,
        callbacks: {
          label: (context) => `${context.dataset.label}: ${context.parsed.y}%`,
        },
      },
    },
    scales: {
      x: {
        grid: {
          color: "rgba(71, 85, 105, 0.1)",
        },
        ticks: {
          color: "rgba(148, 163, 184, 0.8)",
        },
      },
      y: {
        grid: {
          color: "rgba(71, 85, 105, 0.1)",
        },
        ticks: {
          color: "rgba(148, 163, 184, 0.8)",
          callback: (value) => value + "%",
        },
        min: 0,
        max: 60,
      },
    },
    animation: {
      duration: 2000,
      easing: "easeOutQuart",
    },
    barPercentage: 0.7,
    categoryPercentage: 0.7,
  }

  return (
    <section ref={sectionRef} className="py-24 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 bg-gradient-to-b from-blue-950/10 to-transparent"></div>
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-blue-500/20 to-transparent"></div>
      <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-blue-500/20 to-transparent"></div>

      <motion.div
        style={{ y }}
        className="absolute -right-64 top-1/3 w-[600px] h-[600px] rounded-full border border-blue-500/10 opacity-30"
      ></motion.div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <div className="inline-block">
            <div className="relative">
              <div className="absolute -inset-1 bg-blue-500/10 rounded-lg blur-xl"></div>
              <h2 className="text-4xl font-bold mb-4 relative">
                <span className="bg-gradient-to-r from-blue-400 to-blue-600 bg-clip-text text-transparent">
                  Resultados Comprovados
                </span>
              </h2>
            </div>
          </div>
          <p className="text-blue-100/80 max-w-2xl mx-auto mt-4">
            Nosso sistema proporciona até 50% mais conversão comparado à concorrência, garantindo resultados superiores
            para o seu negócio de apostas online.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="absolute -inset-4 bg-blue-500/5 rounded-3xl blur-xl"></div>
            <div className="bg-blue-950/20 border border-blue-500/20 backdrop-blur-sm rounded-lg p-6 relative h-[400px]">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-600/5 to-blue-900/5 rounded-lg"></div>
              <h3 className="text-xl font-bold mb-6 text-blue-100">Taxa de Conversão Anual</h3>
              <div className="h-[320px] relative">
                <Line data={lineChartData} options={lineChartOptions} />
              </div>

              {/* Glowing dots */}
              <div className="absolute top-4 right-4 w-2 h-2 rounded-full bg-blue-500 glow-sm"></div>
              <div className="absolute bottom-4 left-4 w-2 h-2 rounded-full bg-blue-500 glow-sm"></div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="absolute -inset-4 bg-blue-500/5 rounded-3xl blur-xl"></div>
            <div className="bg-blue-950/20 border border-blue-500/20 backdrop-blur-sm rounded-lg p-6 relative h-[400px]">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-600/5 to-blue-900/5 rounded-lg"></div>
              <h3 className="text-xl font-bold mb-6 text-blue-100">Comparativo de Performance</h3>
              <div className="h-[320px] relative">
                <Bar data={barChartData} options={barChartOptions} />
              </div>

              {/* Glowing dots */}
              <div className="absolute top-4 right-4 w-2 h-2 rounded-full bg-blue-500 glow-sm"></div>
              <div className="absolute bottom-4 left-4 w-2 h-2 rounded-full bg-blue-500 glow-sm"></div>
            </div>
          </motion.div>
        </div>

        <div className="max-w-3xl mx-auto">
          <div className="relative">
            <div className="absolute -inset-4 bg-blue-500/5 rounded-3xl blur-xl"></div>
            <div className="bg-blue-950/20 border border-blue-500/20 backdrop-blur-sm rounded-lg p-8 relative">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-600/5 to-blue-900/5 rounded-lg"></div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="text-center">
                  <div className="text-4xl font-bold text-blue-400 mb-2">+50%</div>
                  <p className="text-blue-200/70">Taxa de Conversão</p>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold text-blue-400 mb-2">+40%</div>
                  <p className="text-blue-200/70">Taxa de Crescimento</p>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold text-blue-400 mb-2">+30%</div>
                  <p className="text-blue-200/70">Taxa de Retenção</p>
                </div>
              </div>

              <div className="text-center">
                <p className="text-blue-100 mb-6">
                  Nossos dados mostram que plataformas que utilizam as soluções da Orbit Games têm resultados
                  consistentemente superiores em todos os indicadores-chave de performance.
                </p>
                <Button variant="glow" asChild>
                  <Link href="/contato">Impulsione Seus Resultados</Link>
                </Button>
              </div>

              {/* Glowing dots */}
              <div className="absolute top-4 right-4 w-2 h-2 rounded-full bg-blue-500 glow-sm"></div>
              <div className="absolute bottom-4 left-4 w-2 h-2 rounded-full bg-blue-500 glow-sm"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
