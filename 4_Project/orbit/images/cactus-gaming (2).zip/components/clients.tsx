"use client"

import { useRef } from "react"
import Image from "next/image"
import { motion, useScroll, useTransform } from "framer-motion"
import { clients } from "@/data/clients"

export default function Clients() {
  const sectionRef = useRef<HTMLElement>(null)
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start end", "end start"],
  })

  const y = useTransform(scrollYProgress, [0, 1], [50, -50])

  return (
    <section ref={sectionRef} className="py-24 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 bg-gradient-to-b from-blue-950/10 to-transparent"></div>
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-blue-500/20 to-transparent"></div>

      <motion.div
        style={{ y }}
        className="absolute -left-64 top-1/3 w-[600px] h-[600px] rounded-full border border-blue-500/10 opacity-30"
      ></motion.div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <div className="inline-block">
            <div className="relative">
              <div className="absolute -inset-1 bg-blue-500/10 rounded-lg blur-xl"></div>
              <h2 className="text-4xl font-bold mb-4 relative">
                <span className="bg-gradient-to-r from-blue-400 to-blue-600 bg-clip-text text-transparent">
                  Nossos Clientes
                </span>
              </h2>
            </div>
          </div>
          <p className="text-blue-100/80 max-w-2xl mx-auto mt-4">
            Nossa empresa é reflexo do trabalho realizado em cada projeto e dos resultados que colhem cada um de nossos
            clientes.
          </p>
        </motion.div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
          {clients.map((client, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: index * 0.05 }}
              viewport={{ once: true }}
              whileHover={{ y: -5, scale: 1.05 }}
              className="relative group"
            >
              <div className="absolute -inset-2 bg-blue-500/5 rounded-xl blur-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              <div className="bg-blue-950/30 p-4 rounded-lg backdrop-blur-sm border border-blue-500/10 group-hover:border-blue-500/30 transition-all duration-300 relative">
                <Image
                  src={client.logo || `/placeholder.svg?height=80&width=160&text=${client.name}`}
                  alt={client.name}
                  width={160}
                  height={80}
                  className="max-h-16 w-auto object-contain opacity-70 group-hover:opacity-100 transition-opacity"
                />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
