"use client"

import { useRef, useEffect } from "react"
import Image from "next/image"
import { motion } from "framer-motion"
import { partnerLogos } from "@/data/partner-logos"

export default function Partners() {
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const container = containerRef.current
    if (!container) return

    const handleMouseMove = (e: MouseEvent) => {
      const { left, top, width, height } = container.getBoundingClientRect()
      const x = (e.clientX - left) / width - 0.5
      const y = (e.clientY - top) / height - 0.5

      const logos = container.querySelectorAll(".partner-logo")
      logos.forEach((logo) => {
        const element = logo as HTMLElement
        const factor = Number.parseFloat(element.dataset.factor || "1")
        element.style.transform = `translate(${x * 10 * factor}px, ${y * 10 * factor}px)`
      })
    }

    container.addEventListener("mousemove", handleMouseMove)

    return () => {
      container.removeEventListener("mousemove", handleMouseMove)
    }
  }, [])

  return (
    <section className="py-16 bg-transparent relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-blue-950/20 to-transparent"></div>

      <div ref={containerRef} className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 1 }}
          viewport={{ once: true }}
          className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-8 items-center justify-items-center"
        >
          {partnerLogos.slice(0, 18).map((logo, index) => (
            <motion.div
              key={index}
              className="partner-logo grayscale hover:grayscale-0 transition-all duration-300 hover:scale-110"
              data-factor={Math.random() * 0.8 + 0.6}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.05 }}
              viewport={{ once: true }}
            >
              <div className="bg-blue-950/30 p-4 rounded-lg backdrop-blur-sm border border-blue-500/10 hover:border-blue-500/30 transition-all duration-300">
                <Image
                  src={logo.src || `/placeholder.svg?height=60&width=120&text=${logo.name}`}
                  alt={logo.name}
                  width={120}
                  height={60}
                  className="max-h-12 w-auto object-contain opacity-70 hover:opacity-100 transition-opacity"
                />
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
