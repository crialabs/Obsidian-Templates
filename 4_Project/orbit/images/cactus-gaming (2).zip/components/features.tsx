const Features = () => {
  return (
    <section className="py-12 bg-gray-100">
      <div className="container mx-auto text-center">
        <h2 className="text-3xl font-semibold text-gray-800 mb-8">
          Orbit Gaming: Lançamento Rápido e Resultados Imediatos
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-xl font-semibold text-gray-700 mb-2">
              Ativação Expressa: Plataforma Pronta para Faturar em 48h
            </h3>
            <p className="text-gray-600"></p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-xl font-semibold text-gray-700 mb-2">
              Integrações Premium: Conecte-se aos Maiores Provedores do Mercado
            </h3>
            <p className="text-gray-600"></p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-xl font-semibold text-gray-700 mb-2">
              Suporte Imbatível: Equipe Dedicada para Garantir Seu Sucesso
            </h3>
            <p className="text-gray-600"></p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h3 className="text-xl font-semibold text-gray-700 mb-2">
              Consultoria Personalizada: Estratégias Comprovadas para Impulsionar Seu Crescimento
            </h3>
            <p className="text-gray-600"></p>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Features
