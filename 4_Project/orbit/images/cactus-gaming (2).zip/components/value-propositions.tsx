"use client"

import { useRef } from "react"
import { motion, useScroll, useTransform } from "framer-motion"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Rocket, Users, BarChart } from "lucide-react"

export default function ValuePropositions() {
  const sectionRef = useRef<HTMLElement>(null)
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start end", "end start"],
  })

  const y = useTransform(scrollYProgress, [0, 1], [0, -100])

  const features = [
    {
      title: "Equipe preparada",
      description:
        "São mais de 10 anos de experiência no Digital e com resultados sólidos em diferentes segmentos, e toda essa expertise é colocada em prática em seu sistema.",
      icon: Users,
    },
    {
      title: "Performance",
      description:
        "Trabalho totalmente focado em otimização e aumento de experiência do usuário final, desencadeando em um maior nível de conversão e um site que entrega até o dobro de vendas.",
      icon: BarChart,
    },
    {
      title: "Máxima Otimização",
      description:
        "Equipe experiente que desenha toda a jornada do cliente e te dá todos os gatilhos possíveis para as etapas de conversão necessárias do seu negócio.",
      icon: Rocket,
    },
  ]

  return (
    <section ref={sectionRef} className="py-24 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-blue-950/10 to-transparent"></div>

      <motion.div
        style={{ y }}
        className="absolute -left-64 top-1/3 w-[600px] h-[600px] rounded-full border border-blue-500/10 opacity-30"
      ></motion.div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <div className="inline-block">
            <div className="relative">
              <div className="absolute -inset-1 bg-blue-500/10 rounded-lg blur-xl"></div>
              <h2 className="text-4xl font-bold mb-4 relative">
                <span className="bg-gradient-to-r from-blue-400 to-blue-600 bg-clip-text text-transparent">
                  Soluções inovadoras
                </span>
              </h2>
            </div>
          </div>
          <p className="text-blue-100/80 max-w-2xl mx-auto mt-4">
            Porque você precisa de uma equipe preparada e que entenda do mercado de apostas brasileiro. Estamos prontos
            para atender qualquer demanda e maximizar os seus resultados.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.2 }}
              viewport={{ once: true }}
            >
              <Card className="bg-blue-950/20 border-blue-500/20 backdrop-blur-sm overflow-hidden card-hover-effect relative">
                <div className="absolute inset-0 bg-gradient-to-br from-blue-600/5 to-blue-900/5"></div>
                <CardHeader className="pb-2 relative">
                  <div className="blue-gradient w-12 h-12 rounded-lg flex items-center justify-center mb-4 glow-sm">
                    <feature.icon className="h-6 w-6 text-white" />
                  </div>
                  <CardTitle className="text-xl text-blue-100">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent className="relative">
                  <p className="text-blue-200/70">{feature.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
