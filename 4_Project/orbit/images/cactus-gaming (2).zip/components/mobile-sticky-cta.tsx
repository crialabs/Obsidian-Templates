"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { X, Phone, Calendar, Sparkles } from "lucide-react"
import Link from "next/link"

export default function MobileStickyCtA() {
  const [isVisible, setIsVisible] = useState(false)
  const [isDismissed, setIsDismissed] = useState(false)

  useEffect(() => {
    let timeoutId: NodeJS.Timeout
    let scrollHandler: () => void

    const showSticker = () => {
      if (!isDismissed) {
        setIsVisible(true)
      }
    }

    // Show after 20 seconds
    timeoutId = setTimeout(showSticker, 20000)

    // Show when user scrolls 30% of the page
    scrollHandler = () => {
      const scrollPercent = (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100
      if (scrollPercent >= 30 && !isDismissed) {
        setIsVisible(true)
      }
    }

    window.addEventListener("scroll", scrollHandler)

    return () => {
      clearTimeout(timeoutId)
      window.removeEventListener("scroll", scrollHandler)
    }
  }, [isDismissed])

  const handleDismiss = () => {
    setIsDismissed(true)
    setIsVisible(false)
  }

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          transition={{ duration: 0.3, ease: "easeOut" }}
          className="fixed bottom-4 left-4 right-4 z-50 md:hidden"
        >
          <div className="glass-effect-purple rounded-xl p-4 shadow-2xl border border-purple-500/20">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-green-400 animate-pulse" />
                <h3 className="text-white font-semibold text-sm">Aumente suas conversões em 50%</h3>
              </div>
              <button
                onClick={handleDismiss}
                className="text-neutral-400 hover:text-white transition-colors p-1"
                aria-label="Fechar"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-neutral-300 text-xs mb-4 leading-relaxed">
              Descubra como nossa plataforma pode transformar seu negócio de apostas online
            </p>

            <div className="flex gap-2">
              <Button variant="cta" size="sm" className="flex-1 text-xs font-semibold" asChild>
                <Link href="/agendar-demo" className="flex items-center justify-center gap-1">
                  <Calendar className="w-3 h-3" />
                  Demo Grátis
                </Link>
              </Button>
              <Button variant="outline" size="sm" className="flex-1 text-xs" asChild>
                <Link href="/contato" className="flex items-center justify-center gap-1">
                  <Phone className="w-3 h-3" />
                  Contato
                </Link>
              </Button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
