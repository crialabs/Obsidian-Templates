const ContactCTA = () => {
  return (
    <div className="bg-gray-100 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:text-center">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            Quer Lançar Sua Operação de Apostas Agora e Começar a Faturar em 48 Horas?
          </h2>
          <p className="mt-3 max-w-2xl mx-auto text-xl text-gray-500 sm:mt-4">
            Faça parte da próxima explosão de entretenimento com a Orbit Gaming. Agende agora sua consultoria gratuita e
            descubra como podemos transformar sua visão em um negócio lucrativo.
          </p>
        </div>

        <div className="mt-10 flex justify-center space-x-4">
          <button
            type="button"
            className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            Agendar Consulta Gratuita
          </button>
          <button
            type="button"
            className="inline-flex items-center px-6 py-3 border border-gray-300 shadow-sm text-base font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            Ver Demonstração ao Vivo
          </button>
        </div>
      </div>
    </div>
  )
}

export default ContactCTA
