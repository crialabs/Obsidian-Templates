import Link from "next/link"
import { Button } from "@/components/ui/button"
import { BlogCard } from "@/components/blog-card"
import { blogPosts } from "@/data/blog-posts"

export default function BlogPreview() {
  // Get only the first 3 blog posts for the preview section
  const previewPosts = blogPosts.slice(0, 3)

  return (
    <section className="py-16 bg-black">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center mb-12">
          <div>
            <h2 className="text-3xl font-bold mb-2">Últimas do Blog</h2>
            <p className="text-gray-400">Fique por dentro das novidades do mundo dos games</p>
          </div>
          <Button variant="outline" asChild className="mt-4 md:mt-0">
            <Link href="/blog">Ver Todos</Link>
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {previewPosts.map((post) => (
            <BlogCard key={post.id} post={post} />
          ))}
        </div>
      </div>
    </section>
  )
}
