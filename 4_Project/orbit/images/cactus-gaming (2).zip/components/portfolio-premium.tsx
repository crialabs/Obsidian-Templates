"use client"

import { motion } from "framer-motion"
import { ScrollAnimation } from "@/components/scroll-animations"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { Gamepad2, Trophy, Globe, Zap, Target, TrendingUp, ArrowRight } from "lucide-react"

export default function PortfolioPremium() {
  const portfolioItems = [
    {
      icon: Gamepad2,
      title: "Cassino Completo",
      description: "Slots, Crash Games, Roleta, Cassino ao Vivo: A Emoção Que Seus Jogadores Buscam",
      features: ["3000+ Slots Premium", "Jogos ao Vivo", "Crash Games", "Roleta Brasileira"],
      color: "purple",
    },
    {
      icon: Trophy,
      title: "Apostas Esportivas",
      description: "Esportes Virtuais e Apostas Esportivas: Ação e Lucro em Cada Lance",
      features: ["Esportes Virtuais", "Apostas ao Vivo", "Odds Competitivas", "Múltiplas Modalidades"],
      color: "green",
    },
    {
      icon: Globe,
      title: "Conteúdo Local",
      description: "Conteúdo Exclusivo: Localizado para LATAM e Brasil, Maximizando o Engajamento",
      features: ["Jogos Brasileiros", "Provedores Locais", "Pagamentos PIX", "Suporte em Português"],
      color: "purple",
    },
  ]

  return (
    <section className="py-24 bg-dark-950 relative overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-[300px] h-[300px] rounded-full bg-purple-500/5 blur-[100px]"></div>
        <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] rounded-full bg-green-500/5 blur-[120px]"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <ScrollAnimation animation="fade-in">
          <div className="text-center mb-16">
            <motion.div
              className="mb-6"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              <Badge variant="outline" className="px-4 py-2 text-purple-300 border-purple-500/30">
                🎮 Portfólio Premium
              </Badge>
            </motion.div>

            <motion.h2
              className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 text-balance"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              viewport={{ once: true }}
            >
              Entretenimento Sem Limites, <span className="text-gradient-green">Lucro Garantido</span>: O Portfólio
              Premium da Orbit Gaming
            </motion.h2>

            <motion.p
              className="text-xl text-neutral-300 max-w-4xl mx-auto leading-relaxed"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              viewport={{ once: true }}
            >
              Oferecemos mais de 3.000 jogos integrados e prontos para operar, garantindo a melhor experiência para seus
              jogadores e máxima retenção.
            </motion.p>
          </div>
        </ScrollAnimation>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {portfolioItems.map((item, index) => (
            <ScrollAnimation key={index} animation="slide-up" delay={index * 0.1}>
              <Card className="bg-dark-800/50 border-purple-500/10 hover:border-purple-500/30 transition-all duration-300 group h-full">
                <CardContent className="p-8">
                  <div className="flex items-center gap-4 mb-6">
                    <div
                      className={`p-3 rounded-xl ${item.color === "green" ? "bg-green-500/10" : "bg-purple-500/10"} group-hover:scale-110 transition-transform duration-300`}
                    >
                      <item.icon
                        className={`h-6 w-6 ${item.color === "green" ? "text-green-400" : "text-purple-400"}`}
                      />
                    </div>
                    <h3 className="text-xl font-bold text-neutral-100">{item.title}</h3>
                  </div>

                  <p className="text-neutral-300 mb-6 leading-relaxed">{item.description}</p>

                  <div className="space-y-3">
                    {item.features.map((feature, featureIndex) => (
                      <div key={featureIndex} className="flex items-center gap-3">
                        <div
                          className={`w-2 h-2 rounded-full ${item.color === "green" ? "bg-green-500" : "bg-purple-500"}`}
                        ></div>
                        <span className="text-sm text-neutral-400">{feature}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </ScrollAnimation>
          ))}
        </div>

        {/* Stats section */}
        <ScrollAnimation animation="fade-in">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16">
            {[
              { number: "3000+", label: "Jogos Disponíveis", icon: Gamepad2 },
              { number: "98%", label: "RTP Médio", icon: TrendingUp },
              { number: "50+", label: "Provedores Premium", icon: Target },
              { number: "24/7", label: "Disponibilidade", icon: Zap },
            ].map((stat, index) => (
              <motion.div
                key={index}
                className="text-center"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <div className="mb-4 flex justify-center">
                  <div className="p-3 rounded-xl bg-purple-500/10">
                    <stat.icon className="h-6 w-6 text-purple-400" />
                  </div>
                </div>
                <div className="text-3xl md:text-4xl font-bold text-gradient-green mb-2">{stat.number}</div>
                <div className="text-sm text-neutral-400">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </ScrollAnimation>

        {/* CTA */}
        <ScrollAnimation animation="fade-in">
          <div className="text-center">
            <motion.div
              className="flex flex-col sm:flex-row gap-4 justify-center"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              <Button size="xl" variant="cta" asChild>
                <Link href="/contato" className="group">
                  Quero Faturar em 48h!
                  <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
                </Link>
              </Button>
              <Button size="xl" variant="outline" asChild>
                <Link href="/agendar-demo">Ver Portfólio Completo</Link>
              </Button>
            </motion.div>
          </div>
        </ScrollAnimation>
      </div>
    </section>
  )
}
