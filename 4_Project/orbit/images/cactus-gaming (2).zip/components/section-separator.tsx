"use client"

import { motion } from "framer-motion"
import Image from "next/image"

interface SectionSeparatorProps {
  variant?: "line" | "gradient" | "image" | "dots"
  className?: string
}

export function SectionSeparator({ variant = "gradient", className = "" }: SectionSeparatorProps) {
  if (variant === "image") {
    return (
      <div className={`w-full flex justify-center my-16 ${className}`}>
        <div className="relative w-full max-w-4xl h-1">
          <Image src="/images/linha-esquerda.png" alt="Section separator" fill className="object-contain" />
        </div>
      </div>
    )
  }

  if (variant === "line") {
    return (
      <div className={`w-full my-16 ${className}`}>
        <div className="separator-purple"></div>
      </div>
    )
  }

  if (variant === "dots") {
    return (
      <div className={`w-full flex justify-center my-16 ${className}`}>
        <div className="flex space-x-2">
          {[...Array(5)].map((_, i) => (
            <motion.div
              key={i}
              className="w-2 h-2 rounded-full bg-purple-600"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: i * 0.1, duration: 0.3 }}
            />
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className={`w-full my-16 ${className}`}>
      <motion.div
        className="h-px bg-gradient-to-r from-transparent via-purple-600 to-transparent"
        initial={{ scaleX: 0 }}
        whileInView={{ scaleX: 1 }}
        transition={{ duration: 1.5, ease: "easeInOut" }}
        viewport={{ once: true }}
      />
    </div>
  )
}
