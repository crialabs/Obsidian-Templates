"use client"

import { motion } from "framer-motion"
import { ScrollAnimation } from "@/components/scroll-animations"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { Palette, Cog, Sparkles, Users, TrendingUp, ArrowRight, Star } from "lucide-react"

export default function CustomGames() {
  const customFeatures = [
    {
      icon: Palette,
      title: "Design Exclusivo",
      description: "Interface personalizada com sua identidade visual",
    },
    {
      icon: Cog,
      title: "Mecânicas Únicas",
      description: "Gameplay desenvolvido especificamente para seu público",
    },
    {
      icon: Sparkles,
      title: "Narrativa Própria",
      description: "Storytelling que conecta com seus jogadores",
    },
    {
      icon: Users,
      title: "Experiência Diferenciada",
      description: "Jogos que elevam o engajamento e retenção",
    },
  ]

  return (
    <section className="py-24 bg-dark-900 relative overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0">
        <div className="absolute top-1/3 right-1/4 w-[500px] h-[500px] rounded-full bg-purple-500/3 blur-[120px]"></div>
        <div className="absolute bottom-1/3 left-1/4 w-[400px] h-[400px] rounded-full bg-green-500/3 blur-[100px]"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Column - Content */}
          <ScrollAnimation animation="slide-right">
            <div className="space-y-8">
              <motion.div
                className="space-y-6"
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8 }}
                viewport={{ once: true }}
              >
                <Badge variant="outline" className="px-4 py-2 text-purple-300 border-purple-500/30">
                  🎨 Jogos Personalizados
                </Badge>

                <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold text-balance leading-[1.1]">
                  Destaque-se da Concorrência: <span className="text-gradient-purple">Jogos Personalizados</span> com a
                  Sua Marca
                </h2>

                <p className="text-xl text-neutral-300 leading-relaxed">
                  Design, mecânica e narrativa exclusivos para sua operação se diferenciar e elevar a experiência dos
                  seus jogadores.
                </p>
              </motion.div>

              <motion.div
                className="grid grid-cols-1 sm:grid-cols-2 gap-6"
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                viewport={{ once: true }}
              >
                {customFeatures.map((feature, index) => (
                  <div key={index} className="flex items-start gap-4">
                    <div className="p-2 rounded-lg bg-purple-500/10 flex-shrink-0">
                      <feature.icon className="h-5 w-5 text-purple-400" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-neutral-100 mb-1">{feature.title}</h3>
                      <p className="text-sm text-neutral-400">{feature.description}</p>
                    </div>
                  </div>
                ))}
              </motion.div>

              <motion.div
                className="flex flex-col sm:flex-row gap-4"
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: 0.4 }}
                viewport={{ once: true }}
              >
                <Button size="xl" variant="cta" asChild>
                  <Link href="/contato" className="group">
                    Criar Meu Jogo Exclusivo
                    <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
                  </Link>
                </Button>
                <Button size="xl" variant="outline" asChild>
                  <Link href="/agendar-demo">Ver Exemplos</Link>
                </Button>
              </motion.div>
            </div>
          </ScrollAnimation>

          {/* Right Column - Visual */}
          <ScrollAnimation animation="slide-left">
            <div className="relative">
              <motion.div
                className="relative"
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8 }}
                viewport={{ once: true }}
              >
                {/* Main showcase card */}
                <Card className="bg-dark-800/50 border-purple-500/20 overflow-hidden">
                  <CardContent className="p-0">
                    <div className="relative h-[300px] bg-gradient-to-br from-purple-900/20 to-green-900/20">
                      <div className="absolute inset-0 bg-[url('/placeholder.svg?height=300&width=400')] bg-cover bg-center opacity-20"></div>

                      {/* Game preview overlay */}
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="text-center space-y-4">
                          <div className="w-16 h-16 bg-purple-500/20 rounded-full flex items-center justify-center mx-auto">
                            <Sparkles className="h-8 w-8 text-purple-400" />
                          </div>
                          <h3 className="text-xl font-bold text-neutral-100">Seu Jogo Exclusivo</h3>
                          <p className="text-sm text-neutral-400">Personalizado com sua marca</p>
                        </div>
                      </div>

                      {/* Floating badges */}
                      <div className="absolute top-4 left-4">
                        <Badge className="bg-green-500/20 text-green-300 border-green-500/30">EXCLUSIVO</Badge>
                      </div>
                      <div className="absolute top-4 right-4">
                        <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30">SUA MARCA</Badge>
                      </div>
                    </div>

                    <div className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <h4 className="font-bold text-neutral-100">Game Personalizado</h4>
                        <div className="flex items-center gap-1">
                          {[...Array(5)].map((_, i) => (
                            <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                          ))}
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-4 text-center">
                        <div>
                          <div className="text-lg font-bold text-gradient-green">98%</div>
                          <div className="text-xs text-neutral-400">RTP</div>
                        </div>
                        <div>
                          <div className="text-lg font-bold text-gradient-purple">High</div>
                          <div className="text-xs text-neutral-400">Volatility</div>
                        </div>
                        <div>
                          <div className="text-lg font-bold text-gradient-green">5000x</div>
                          <div className="text-xs text-neutral-400">Max Win</div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Floating elements */}
                <div className="absolute -top-4 -right-4 w-20 h-20 bg-purple-500/10 rounded-full blur-xl animate-pulse-glow"></div>
                <div
                  className="absolute -bottom-4 -left-4 w-16 h-16 bg-green-500/10 rounded-full blur-lg animate-pulse-glow"
                  style={{ animationDelay: "-2s" }}
                ></div>
              </motion.div>

              {/* Stats overlay */}
              <motion.div
                className="absolute -bottom-8 -left-8 bg-dark-800/80 backdrop-blur-sm border border-purple-500/20 rounded-xl p-4"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.6 }}
                viewport={{ once: true }}
              >
                <div className="flex items-center gap-3">
                  <TrendingUp className="h-5 w-5 text-green-400" />
                  <div>
                    <div className="text-sm font-semibold text-neutral-100">+300% Engajamento</div>
                    <div className="text-xs text-neutral-400">vs. jogos padrão</div>
                  </div>
                </div>
              </motion.div>
            </div>
          </ScrollAnimation>
        </div>
      </div>
    </section>
  )
}
