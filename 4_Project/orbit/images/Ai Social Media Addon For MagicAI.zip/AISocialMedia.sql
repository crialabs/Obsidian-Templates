SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


CREATE TABLE `automations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `custom` longtext NOT NULL,
  `value` longtext NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `automations` (`id`, `custom`, `value`, `created_at`, `updated_at`) VALUES
(1, 'automation_active', '1', '2024-07-26 03:44:07', '2024-07-26 03:44:07');

CREATE TABLE `automation_campaigns` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `target_audience` text DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `linkedin_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `access_token` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `twitter_settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `consumer_key` text DEFAULT NULL,
  `consumer_secret` text DEFAULT NULL,
  `access_token` text DEFAULT NULL,
  `access_token_secret` text DEFAULT NULL,
  `bearer_token` text DEFAULT NULL,
  `account_id` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `scheduled_posts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `command_running` tinyint(1) NOT NULL DEFAULT 0,
  `last_run_date` date DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `company_id` bigint(20) DEFAULT NULL,
  `platform` varchar(191) DEFAULT NULL,
  `products` text DEFAULT NULL,
  `campaign_name` varchar(191) DEFAULT NULL,
  `campaign_target` longtext DEFAULT NULL,
  `topics` longtext DEFAULT NULL,
  `is_seo` tinyint(1) NOT NULL DEFAULT 0,
  `tone` varchar(191) DEFAULT NULL,
  `length` varchar(191) DEFAULT NULL,
  `is_email` tinyint(1) NOT NULL DEFAULT 0,
  `is_repeated` tinyint(1) NOT NULL DEFAULT 0,
  `repeat_period` varchar(191) DEFAULT NULL,
  `repeat_start_date` date DEFAULT NULL,
  `repeat_time` time DEFAULT NULL,
  `visual_format` varchar(191) DEFAULT NULL,
  `visual_ratio` varchar(191) DEFAULT NULL,
  `posted_at` varchar(191) DEFAULT NULL,
  `prompt` longtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `scheduled_posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `command_running_last_run_date_index` (`command_running`,`last_run_date`,`repeat_period`,`repeat_time`);

ALTER TABLE `automations`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `linkedin_tokens`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `twitter_settings`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `automations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `linkedin_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `twitter_settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
  
ALTER TABLE `scheduled_posts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
