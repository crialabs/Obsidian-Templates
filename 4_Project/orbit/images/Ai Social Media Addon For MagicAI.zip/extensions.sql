-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 13, 2025 at 01:00 PM
-- Server version: 10.6.20-MariaDB
-- PHP Version: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `threadpo_mysite`
--

-- --------------------------------------------------------

--
-- Table structure for table `extensions`
--

CREATE TABLE IF NOT EXISTS `extensions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `version` varchar(191) DEFAULT NULL,
  `slug` varchar(191) DEFAULT NULL,
  `installed` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_theme` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `extensions`
--

INSERT INTO `extensions` (`id`, `version`, `slug`, `installed`, `created_at`, `updated_at`, `is_theme`) VALUES
(1, '1.2', 'ai-avatar-pro', 1, '2025-01-09 20:27:11', '2025-01-09 20:27:11', 0),
(2, '1.3', 'ai-fall-video', 1, '2025-01-09 20:27:11', '2025-01-09 20:27:11', 0),
(3, '1.2', 'chatbot', 1, '2025-01-09 20:27:11', '2025-01-09 20:27:11', 0),
(4, '2.0', 'chat-share', 1, '2025-01-09 20:27:11', '2025-01-09 20:30:05', 0),
(5, '2.0', 'focus-mode', 1, '2025-01-09 20:27:11', '2025-01-09 20:27:11', 0),
(6, '2.0', 'introductions', 1, '2025-01-09 20:27:11', '2025-01-09 20:29:55', 0),
(7, '2.0', 'flux-pro', 1, '2025-01-09 20:27:11', '2025-01-09 20:29:44', 0),
(8, '2.0', 'voice-isolator', 1, '2025-01-09 20:27:11', '2025-01-09 20:29:30', 0),
(9, '2.0', 'hubspot', 1, '2025-01-09 20:27:11', '2025-01-09 20:29:16', 0),
(10, '2.0', 'mailchimp-newsletter', 1, '2025-01-09 20:27:11', '2025-01-09 20:29:05', 0),
(11, '2.0', 'ai-product-shot', 1, '2025-01-09 20:27:11', '2025-01-09 20:27:11', 0),
(12, '2.0', 'ai-avatar', 1, '2025-01-09 20:27:11', '2025-01-09 20:27:11', 0),
(13, '2.0', 'maintenance', 1, '2025-01-09 20:27:11', '2025-01-09 20:28:53', 0),
(14, '2.0', 'menu', 1, '2025-01-09 20:27:11', '2025-01-09 20:27:11', 0),
(15, '2.0', 'ai-writer-templates', 1, '2025-01-09 20:27:11', '2025-01-09 20:28:41', 0),
(16, '3.0', 'photo-studio', 1, '2025-01-09 20:27:11', '2025-01-09 20:28:28', 0),
(17, '3.0', 'seo-tool', 1, '2025-01-09 20:27:11', '2025-01-09 20:27:11', 0),
(18, '2.0', 'azure-tts', 1, '2025-01-09 20:27:11', '2025-01-09 20:28:15', 0),
(19, '3.0', 'cryptomus', 1, '2025-01-09 20:27:11', '2025-01-09 20:27:11', 0),
(20, '3.0', 'ai-social-media', 1, '2025-01-09 20:27:11', '2025-01-09 20:27:11', 0),
(21, '3.0', 'wordpress', 1, '2025-01-09 20:27:11', '2025-01-09 20:27:11', 0),
(22, '3.0', 'cloudflare-r2', 1, '2025-01-09 20:27:11', '2025-01-09 20:27:11', 0),
(23, '3.0', 'chat-setting', 1, '2025-01-09 20:27:11', '2025-01-09 20:28:03', 0),
(24, '2.0', 'webchat', 1, '2025-01-09 20:27:11', '2025-01-09 20:27:49', 0),
(25, '2', 'plagiarism', 1, '2025-01-09 20:27:11', '2025-01-09 20:27:36', 0),
(26, '2.0', 'newsletter', 1, '2025-01-09 20:27:11', '2025-01-09 20:27:26', 0),
(27, '4.2', 'bolt', 1, '2025-01-09 20:34:50', '2025-01-09 20:34:50', 1),
(28, '4.1', 'modern', 1, '2025-01-09 20:34:50', '2025-01-09 20:34:50', 1),
(29, '4.1', 'dark', 1, '2025-01-09 20:34:50', '2025-01-09 20:34:50', 1),
(30, '4.1', 'classic', 1, '2025-01-09 20:34:50', '2025-01-09 20:34:50', 1),
(31, '4.1', 'creative', 1, '2025-01-09 20:34:50', '2025-01-09 20:34:50', 1),
(32, '4.1', 'sleek', 1, '2025-01-09 20:34:50', '2025-01-09 20:34:50', 1),
(33, '1', 'default', 1, '2025-01-09 20:34:50', '2025-01-09 20:34:50', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `extensions`
--
ALTER TABLE `extensions`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `extensions`
--
ALTER TABLE `extensions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
